package com.capitalone.api.nsb.business.identity.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.capitalone.api.nsb.business.identity.domain.cache.BusinessStatus;
import com.capitalone.api.nsb.business.identity.service.CacheService;

@RunWith(MockitoJUnitRunner.class)
public class BusinessStatusCacheHandlerTest {

    private BusinessStatusCacheHandler businessStatusCacheHandler;

    @Mock
    private Cache<Integer, String> businessStatusCache;

    @Mock
    private CacheService cacheService;

    @Mock
    private BusinessIdentityCacheManager cacheManager;

    @Before
    public void setUp() throws Exception {
        businessStatusCacheHandler = new BusinessStatusCacheHandler();
        ReflectionTestUtils.setField(businessStatusCacheHandler, "businessStatusCache", businessStatusCache);
        ReflectionTestUtils.setField(businessStatusCacheHandler, "cacheService", cacheService);
        ReflectionTestUtils.setField(businessStatusCacheHandler, "cacheManager", cacheManager);
    }

    @Test
    public void testGetBusinessStatusDesc() {
        int businessStatusCode = 1;
        when(businessStatusCache.iterator()).thenReturn(getCacheIterator());
        when(businessStatusCache.get(businessStatusCode)).thenReturn("CLIENT");
        String actual = businessStatusCacheHandler.getBusinessStatusDesc(businessStatusCode);
        assertEquals("CLIENT", actual);
    }

    @Test
    public void testGetBusinessStatusDesc_refresh() {
        int businessStatusCode = 1;

        List<BusinessStatus> businessStatusList = new ArrayList<BusinessStatus>();
        businessStatusList.add(new BusinessStatus());
        businessStatusList.add(null);
        when(cacheService.getBusinessStatuses()).thenReturn(businessStatusList);

        when(businessStatusCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(businessStatusCache.get(businessStatusCode)).thenReturn("CLIENT");
        String actual = businessStatusCacheHandler.getBusinessStatusDesc(businessStatusCode);
        assertEquals("CLIENT", actual);
    }

    @Test
    public void testGetBusinessStatusDesc_initialize() {

        ReflectionTestUtils.setField(businessStatusCacheHandler, "businessStatusCache", null);

        int businessStatusCode = 1;

        when(cacheManager.initializeCache("businessStatusCache", Integer.class, String.class)).thenReturn(businessStatusCache);
        when(businessStatusCache.get(businessStatusCode)).thenReturn("CLIENT");
        String actual = businessStatusCacheHandler.getBusinessStatusDesc(businessStatusCode);
        assertEquals("CLIENT", actual);
    }

    @Test
    public void testGetBusinessStatusDesc_with_empty_map() {

        int businessStatusCode = 1;

        when(businessStatusCache.iterator()).thenReturn(getCacheIterator());
        when(businessStatusCache.get(businessStatusCode)).thenReturn("CLIENT");

        List<BusinessStatus> businessStatusList = new ArrayList<BusinessStatus>();
        when(cacheService.getBusinessStatuses()).thenReturn(businessStatusList);
        String actual = businessStatusCacheHandler.getBusinessStatusDesc(businessStatusCode);
        assertEquals("CLIENT", actual);
    }

    @Test
    public void testGetBusinessStatusDesc_cache_not_initialized() {
        int businessStatusCode = 1;

        when(businessStatusCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(businessStatusCache.get(businessStatusCode)).thenReturn("CLIENT");
        String actual = businessStatusCacheHandler.getBusinessStatusDesc(businessStatusCode);
        assertEquals("CLIENT", actual);
    }

    @Test
    public void testGetBusinessStatusCode() {

        when(businessStatusCache.iterator()).thenReturn(getCacheIterator());

        int actual = businessStatusCacheHandler.getBusinessStatusCode("CLIENT");
        assertEquals(1, actual);
    }

    @Test
    public void testGetBusinessStatusCode_refresh() {

        when(businessStatusCache.iterator()).thenReturn(getEmptyCacheIterator());

        int actual = businessStatusCacheHandler.getBusinessStatusCode("CLIENT");
        assertEquals(0, actual);
    }

    @Test
    public void testGetBusinessStatusCode_no_match() {

        when(businessStatusCache.iterator()).thenReturn(getCacheIterator_no_match());

        int actual = businessStatusCacheHandler.getBusinessStatusCode("XYZ");
        assertNotEquals(1, actual);
    }

    @Test
    public void testGetBusinessStatusCode_with_no_match() {
        when(businessStatusCache.iterator()).thenReturn(getCacheIterator_no_match());
        int actual = businessStatusCacheHandler.getBusinessStatusCode("XYZ");
        assertEquals(0, actual);
    }

    @Test
    public void testGetBusinessStatusCode_with_blank_Address_Type_Name() {
        when(businessStatusCache.iterator()).thenReturn(getCacheIterator());
        int actual = businessStatusCacheHandler.getBusinessStatusCode("");
        assertEquals(0, actual);
    }

    private Iterator<Entry<Integer, String>> getCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 1;
                    }

                    @Override
                    public String getValue() {
                        return "CLIENT";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getEmptyCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            @Override
            public Entry<Integer, String> next() {
                return null;
            }

            @Override
            public boolean hasNext() {
                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getCacheIterator_no_match() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 2;
                    }

                    @Override
                    public String getValue() {
                        return "CLIENT";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
