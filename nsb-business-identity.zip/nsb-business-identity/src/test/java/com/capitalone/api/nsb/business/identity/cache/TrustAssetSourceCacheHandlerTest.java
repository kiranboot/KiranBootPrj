package com.capitalone.api.nsb.business.identity.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.capitalone.api.nsb.business.identity.domain.cache.TrustAssetSource;
import com.capitalone.api.nsb.business.identity.service.CacheService;

@RunWith(MockitoJUnitRunner.class)
public class TrustAssetSourceCacheHandlerTest {

    private TrustAssetSourceCacheHandler trustAssetSourceCacheHandler;

    @Mock
    private Cache<Integer, String> trustAssetSourceCache;

    @Mock
    private CacheService cacheService;

    @Mock
    private BusinessIdentityCacheManager cacheManager;

    @Before
    public void setUp() throws Exception {

        trustAssetSourceCacheHandler = new TrustAssetSourceCacheHandler();

        ReflectionTestUtils.setField(trustAssetSourceCacheHandler, "trustAssetSourceCache", trustAssetSourceCache);
        ReflectionTestUtils.setField(trustAssetSourceCacheHandler, "cacheService", cacheService);
        ReflectionTestUtils.setField(trustAssetSourceCacheHandler, "cacheManager", cacheManager);
    }

    @Test
    public void testGetTrustAssetSourceDesc() {
        int trustAssetSourceId = 1;
        when(trustAssetSourceCache.iterator()).thenReturn(getCacheIterator());
        when(trustAssetSourceCache.get(trustAssetSourceId)).thenReturn("Sale of Property/Investments/Company");
        String actual = trustAssetSourceCacheHandler.getTrustAssetSourceDesc(trustAssetSourceId);
        assertEquals("Sale of Property/Investments/Company", actual);
    }

    @Test
    public void testGetTrustAssetSourceDesc_refresh() {
        int trustAssetSourceId = 1;

        List<TrustAssetSource> trustAssetSourceList = new ArrayList<TrustAssetSource>();
        trustAssetSourceList.add(new TrustAssetSource());
        trustAssetSourceList.add(null);
        when(cacheService.getTrustAssetSources()).thenReturn(trustAssetSourceList);

        when(trustAssetSourceCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(trustAssetSourceCache.get(trustAssetSourceId)).thenReturn("Sale of Property/Investments/Company");
        String actual = trustAssetSourceCacheHandler.getTrustAssetSourceDesc(trustAssetSourceId);
        assertEquals("Sale of Property/Investments/Company", actual);
    }

    @Test
    public void testGetTrustAssetSourceDesc_initialize() {

        ReflectionTestUtils.setField(trustAssetSourceCacheHandler, "trustAssetSourceCache", null);

        int trustAssetSourceId = 1;

        when(cacheManager.initializeCache("trustAssetSourceCache", Integer.class, String.class)).thenReturn(trustAssetSourceCache);
        when(trustAssetSourceCache.get(trustAssetSourceId)).thenReturn("Sale of Property/Investments/Company");
        String actual = trustAssetSourceCacheHandler.getTrustAssetSourceDesc(trustAssetSourceId);
        assertEquals("Sale of Property/Investments/Company", actual);
    }

    @Test
    public void testGetTrustAssetSourceDesc_with_empty_map() {

        int trustAssetSourceId = 1;

        when(trustAssetSourceCache.iterator()).thenReturn(getCacheIterator());
        when(trustAssetSourceCache.get(trustAssetSourceId)).thenReturn("Sale of Property/Investments/Company");

        List<TrustAssetSource> trustAssetSourceList = new ArrayList<TrustAssetSource>();
        when(cacheService.getTrustAssetSources()).thenReturn(trustAssetSourceList);
        String actual = trustAssetSourceCacheHandler.getTrustAssetSourceDesc(1);
        assertEquals("Sale of Property/Investments/Company", actual);
    }

    @Test
    public void testGetTrustAssetSourceDesc_cache_not_initialized() {
        int trustAssetSourceId = 1;

        when(trustAssetSourceCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(trustAssetSourceCache.get(trustAssetSourceId)).thenReturn("Sale of Property/Investments/Company");
        String actual = trustAssetSourceCacheHandler.getTrustAssetSourceDesc(trustAssetSourceId);
        assertEquals("Sale of Property/Investments/Company", actual);
    }

    @Test
    public void testGetTrustAssetSourceId() {

        when(trustAssetSourceCache.iterator()).thenReturn(getCacheIterator());

        int actual = trustAssetSourceCacheHandler.getTrustAssetSourceId("Sale of Property/Investments/Company");
        assertEquals(1, actual);
    }

    @Test
    public void testGetTrustAssetSourceId_refresh() {

        when(trustAssetSourceCache.iterator()).thenReturn(getEmptyCacheIterator());

        int actual = trustAssetSourceCacheHandler.getTrustAssetSourceId("Sale of Property/Investments/Company");
        assertEquals(0, actual);
    }

    @Test
    public void testGetTrustAssetSourceId_no_match() {

        when(trustAssetSourceCache.iterator()).thenReturn(getCacheIterator_no_match());

        int actual = trustAssetSourceCacheHandler.getTrustAssetSourceId("XYZ");
        assertNotEquals(1, actual);
    }

    @Test
    public void testGetTrustAssetSourceId_with_no_match() {
        when(trustAssetSourceCache.iterator()).thenReturn(getCacheIterator_no_match());
        int actual = trustAssetSourceCacheHandler.getTrustAssetSourceId("XYZ");
        assertEquals(0, actual);
    }

    @Test
    public void testGetTrustAssetSourceId_with_blank_trustAssetSource_Type_Desc() {
        when(trustAssetSourceCache.iterator()).thenReturn(getCacheIterator());
        int actual = trustAssetSourceCacheHandler.getTrustAssetSourceId("");
        assertEquals(0, actual);
    }

    private Iterator<Entry<Integer, String>> getCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 1;
                    }

                    @Override
                    public String getValue() {
                        return "Sale of Property/Investments/Company";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getEmptyCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            @Override
            public Entry<Integer, String> next() {
                return null;
            }

            @Override
            public boolean hasNext() {
                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getCacheIterator_no_match() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 2;
                    }

                    @Override
                    public String getValue() {
                        return "Sale of Property/Investments/Company";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
