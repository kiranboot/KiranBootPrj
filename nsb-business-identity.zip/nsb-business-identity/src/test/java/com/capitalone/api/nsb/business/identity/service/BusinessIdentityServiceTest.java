package com.capitalone.api.nsb.business.identity.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.capitalone.api.nsb.business.identity.converter.BusinessIdentityConverter;
import com.capitalone.api.nsb.business.identity.cso.CreateBusinessDetailsRequest;
import com.capitalone.api.nsb.business.identity.cso.Header;
import com.capitalone.api.nsb.business.identity.cso.HighRiskIndustryCSO;
import com.capitalone.api.nsb.business.identity.cso.RetrieveBusinessDetailsResponse;
import com.capitalone.api.nsb.business.identity.cso.TrustInfoCSO;
import com.capitalone.api.nsb.business.identity.cso.UpdateBusinessDetailsRequest;
import com.capitalone.api.nsb.business.identity.domain.Business;
import com.capitalone.api.nsb.business.identity.exception.ResourceNotFoundException;
import com.capitalone.api.nsb.business.identity.repository.BusinessRepository;
import com.capitalone.api.nsb.business.identity.validator.RequestValidator;

@RunWith(MockitoJUnitRunner.class)
public class BusinessIdentityServiceTest {

    private BusinessIdentityService businessIdentityService;

    @Mock
    private BusinessRepository businessRepository;

    @Mock
    BusinessIdentityConverter businessIdentityConverter;

    @Mock
    private RequestValidator requestValidator;

    @Before
    public void setUp() throws Exception {
        businessIdentityService = new BusinessIdentityService();
        ReflectionTestUtils.setField(businessIdentityService, "businessRepository", businessRepository);
        ReflectionTestUtils.setField(businessIdentityService, "businessIdentityConverter", businessIdentityConverter);
        ReflectionTestUtils.setField(businessIdentityService, "requestValidator", requestValidator);
    }

    @Test
    public void testAddBusiness() {
        Header header = new Header();
        header.setApiKey("xyz");
        header.setUserId("NSB");
        CreateBusinessDetailsRequest createBusinessDetailsRequest = new CreateBusinessDetailsRequest();
        populateCreateBusinessDetailsRequest(createBusinessDetailsRequest);
        Business businessReq = new Business();
        Business businessRes = new Business();
        businessRes.setBusinessReferenceId(new BigInteger("12"));
        when(businessIdentityConverter.mapCreateBusiness(createBusinessDetailsRequest, header)).thenReturn(businessReq);
        when(businessRepository.save(businessReq)).thenReturn(businessRes);
        businessIdentityService.addBusiness(createBusinessDetailsRequest, header);
        assertNotNull(businessRes);
        assertNotNull(businessRes.getBusinessReferenceId());
    }

    @Test
    public void testGetBusiness() {
        Business businessRes = new Business();
        RetrieveBusinessDetailsResponse expectedResp = new RetrieveBusinessDetailsResponse();
        RetrieveBusinessDetailsResponse retrieveBusinessDetailsResponse = new RetrieveBusinessDetailsResponse();
        populateRetreiveBusDetailRes(retrieveBusinessDetailsResponse);
        when(businessRepository.findOne(new BigInteger("12"))).thenReturn(businessRes);
        when(businessIdentityConverter.mapRetreiveBusinessResponse(businessRes))
                .thenReturn(retrieveBusinessDetailsResponse);
        expectedResp = businessIdentityService.getBusiness(new BigInteger("12"));
        assertEquals(expectedResp.getBusinessReferenceId(), "12");
        assertEquals(expectedResp.getBusinessName(), "Xyz Company");
    }

    @Test(expected = ResourceNotFoundException.class)
    public void testGetBusiness_with_null_Business() {
        Business businessRes = null;
        RetrieveBusinessDetailsResponse retrieveBusinessDetailsResponse = new RetrieveBusinessDetailsResponse();
        populateRetreiveBusDetailRes(retrieveBusinessDetailsResponse);
        when(businessRepository.findOne(new BigInteger("12"))).thenReturn(businessRes);
        when(businessIdentityConverter.mapRetreiveBusinessResponse(businessRes))
                .thenReturn(retrieveBusinessDetailsResponse);
        businessIdentityService.getBusiness(new BigInteger("12"));
    }

    @Test
    public void testUpdateBusiness() {
        Header header = new Header();
        header.setApiKey("xyz");
        header.setUserId("NSB");
        Business businessRes = new Business();
        UpdateBusinessDetailsRequest updateBusinessDetailsRequest = new UpdateBusinessDetailsRequest();
        when(businessRepository.findOne(new BigInteger("12"))).thenReturn(businessRes);
        businessIdentityService.updateBusiness(updateBusinessDetailsRequest, new BigInteger("12"), header);
        verify(businessRepository).findOne(new BigInteger("12"));

    }

    @Test(expected = ResourceNotFoundException.class)
    public void testUpdateBusiness_with_null_Business() {
        Header header = new Header();
        header.setApiKey("xyz");
        header.setUserId("NSB");
        UpdateBusinessDetailsRequest updateBusinessDetailsRequest = new UpdateBusinessDetailsRequest();
        businessIdentityService.updateBusiness(updateBusinessDetailsRequest, new BigInteger("12"), header);
    }

    private void populateRetreiveBusDetailRes(RetrieveBusinessDetailsResponse retrieveBusinessDetailsResponse) {
        retrieveBusinessDetailsResponse.setBusinessReferenceId("12");
        retrieveBusinessDetailsResponse.setBusinessName("Xyz Company");
    }

    private void populateCreateBusinessDetailsRequest(CreateBusinessDetailsRequest createBusinessIdentityRequest) {

        List<HighRiskIndustryCSO> highRiskIndustriesObjList = getHighRiskIndustryCSOList();
        createBusinessIdentityRequest.setAssociatedHighRiskIndustyCodes(highRiskIndustriesObjList);

        createBusinessIdentityRequest.setLegalEntityType("1");
        createBusinessIdentityRequest.setBusinessName("XYZ Corp");
        createBusinessIdentityRequest.setTaxIdType("1");
        createBusinessIdentityRequest.setTaxIdToken("123456789");
        createBusinessIdentityRequest.setIndustryCode("111998");
        createBusinessIdentityRequest.setOwnershipStructureType("1");
        createBusinessIdentityRequest.setDoingBusinessAs("DBA-1");
        createBusinessIdentityRequest.setWebsiteAddress("mywebsite.com");
        createBusinessIdentityRequest.setTaxIdIssuingCountry("USA");
        createBusinessIdentityRequest.setCountryOfHeadquarters("USA");
        createBusinessIdentityRequest.setCountryOfLegalFormation("USA");
        createBusinessIdentityRequest.setCountryOfPrimaryOperations("USA");
        createBusinessIdentityRequest.setAnnualRevenue("1");
        createBusinessIdentityRequest.setPurposeOfOrganization("Y");
        createBusinessIdentityRequest.setHasRepeatedInternationalActivity(false);
        createBusinessIdentityRequest.setTaxStatus("Yes");
        createBusinessIdentityRequest.setBusinessCustomerStatus("5");
        createBusinessIdentityRequest.setBusinessCustomerStatusSubtype("123");
        createBusinessIdentityRequest.setBusinessCustomerSince("2017-05-25 17:36:07.072708");
        createBusinessIdentityRequest.setCharitableOrganization(true);

        TrustInfoCSO trustInfo = new TrustInfoCSO();
        trustInfo.setIsTrustFundedFromOffshore(false);
        trustInfo.setDoesTrustBenefitCharitableOrganizations(false);

        createBusinessIdentityRequest.setTrustInfo(trustInfo);

    }

    private List<HighRiskIndustryCSO> getHighRiskIndustryCSOList() {

        List<HighRiskIndustryCSO> highRiskIndustriesObjList = new ArrayList<HighRiskIndustryCSO>();
        HighRiskIndustryCSO highRiskIndustry1 = new HighRiskIndustryCSO();
        highRiskIndustry1.setHighRiskIndustryCode(952000);
        HighRiskIndustryCSO highRiskIndustry2 = new HighRiskIndustryCSO();
        highRiskIndustry2.setHighRiskIndustryCode(950000);
        HighRiskIndustryCSO highRiskIndustry3 = new HighRiskIndustryCSO();
        highRiskIndustry3.setHighRiskIndustryCode(952000);
        highRiskIndustriesObjList.add(highRiskIndustry1);
        highRiskIndustriesObjList.add(highRiskIndustry2);
        highRiskIndustriesObjList.add(highRiskIndustry3);

        return highRiskIndustriesObjList;
    }

}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
