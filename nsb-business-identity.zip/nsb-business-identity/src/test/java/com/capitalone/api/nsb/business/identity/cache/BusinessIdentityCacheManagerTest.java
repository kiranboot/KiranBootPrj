package com.capitalone.api.nsb.business.identity.cache;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.ehcache.Cache;
import org.ehcache.CacheManager;
import org.ehcache.config.CacheRuntimeConfiguration;
import org.ehcache.spi.loaderwriter.BulkCacheLoadingException;
import org.ehcache.spi.loaderwriter.BulkCacheWritingException;
import org.ehcache.spi.loaderwriter.CacheLoadingException;
import org.ehcache.spi.loaderwriter.CacheWritingException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

@RunWith(MockitoJUnitRunner.class)
public class BusinessIdentityCacheManagerTest {

    private BusinessIdentityCacheManager businessIdentityCacheManager;

    @Mock
    private CacheManager cacheManager;

    @Before
    public void setUp() throws Exception {
        Constructor<BusinessIdentityCacheManager> constructor = BusinessIdentityCacheManager.class
                .getDeclaredConstructor(new Class[0]);
        constructor.setAccessible(true);
        businessIdentityCacheManager = constructor.newInstance(new Object[0]);
        ReflectionTestUtils.setField(businessIdentityCacheManager, "cacheManager", cacheManager);
    }

    @Test
    public void testInitializeCache() {
        when(cacheManager.getCache("addressTypeCache", Integer.class, String.class)).thenReturn(getCache());
        Cache<Integer, String> actual = businessIdentityCacheManager.initializeCache("addressTypeCache", Integer.class,
                String.class);
        assertNotNull(actual);
    }

    @Test
    public void testCloseCache() throws NoSuchMethodException, SecurityException, IllegalAccessException,
            IllegalArgumentException, InvocationTargetException {

        @SuppressWarnings("rawtypes")
        Class[] paramTypes = {};
        Method closeCacheMethod = BusinessIdentityCacheManager.class.getDeclaredMethod("closeCache", paramTypes);

        closeCacheMethod.setAccessible(true);

        Object[] paramValues = {};
        closeCacheMethod.invoke(businessIdentityCacheManager, paramValues);

    }

    @Test
    public void testCloseCache_nullCacheManager() throws NoSuchMethodException, SecurityException,
            IllegalAccessException, IllegalArgumentException, InvocationTargetException {

        ReflectionTestUtils.setField(businessIdentityCacheManager, "cacheManager", null);

        Class[] paramTypes = {};
        Method closeCacheMethod = BusinessIdentityCacheManager.class.getDeclaredMethod("closeCache", paramTypes);

        closeCacheMethod.setAccessible(true);

        Object[] paramValues = {};
        closeCacheMethod.invoke(businessIdentityCacheManager, paramValues);

    }

    private Cache<Integer, String> getCache() {
        return new Cache<Integer, String>() {

            @Override
            public Iterator<org.ehcache.Cache.Entry<Integer, String>> iterator() {
                // TODO Auto-generated method stub
                return null;
            }

            @Override
            public void clear() {
                // TODO Auto-generated method stub

            }

            @Override
            public boolean containsKey(Integer arg0) {
                // TODO Auto-generated method stub
                return false;
            }

            @Override
            public String get(Integer arg0) throws CacheLoadingException {
                // TODO Auto-generated method stub
                return null;
            }

            @Override
            public Map<Integer, String> getAll(Set<? extends Integer> arg0) throws BulkCacheLoadingException {
                // TODO Auto-generated method stub
                return null;
            }

            @Override
            public CacheRuntimeConfiguration<Integer, String> getRuntimeConfiguration() {
                // TODO Auto-generated method stub
                return null;
            }

            @Override
            public void put(Integer arg0, String arg1) throws CacheWritingException {
                // TODO Auto-generated method stub

            }

            @Override
            public void putAll(Map<? extends Integer, ? extends String> arg0) throws BulkCacheWritingException {
                // TODO Auto-generated method stub

            }

            @Override
            public String putIfAbsent(Integer arg0, String arg1) throws CacheLoadingException, CacheWritingException {
                // TODO Auto-generated method stub
                return null;
            }

            @Override
            public void remove(Integer arg0) throws CacheWritingException {
                // TODO Auto-generated method stub

            }

            @Override
            public boolean remove(Integer arg0, String arg1) throws CacheWritingException {
                // TODO Auto-generated method stub
                return false;
            }

            @Override
            public void removeAll(Set<? extends Integer> arg0) throws BulkCacheWritingException {
                // TODO Auto-generated method stub

            }

            @Override
            public String replace(Integer arg0, String arg1) throws CacheLoadingException, CacheWritingException {
                // TODO Auto-generated method stub
                return null;
            }

            @Override
            public boolean replace(Integer arg0, String arg1, String arg2)
                    throws CacheLoadingException, CacheWritingException {
                // TODO Auto-generated method stub
                return false;
            }
        };
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
