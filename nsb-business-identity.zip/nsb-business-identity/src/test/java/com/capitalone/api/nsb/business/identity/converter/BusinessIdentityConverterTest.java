package com.capitalone.api.nsb.business.identity.converter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.capitalone.api.nsb.business.identity.cache.AddressTypeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.AnnualRevenueRangeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.BusinessStatusCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.BusinessStatusSubtypeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.HighRiskIndustryCodeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.LegalEntityTypeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.OwnershipStructTypeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.PhoneTypeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.TaxIdTypeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.TrustAssetSourceCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.TrustTypeCacheHandler;
import com.capitalone.api.nsb.business.identity.cso.AddressCSO;
import com.capitalone.api.nsb.business.identity.cso.CreateBusinessDetailsRequest;
import com.capitalone.api.nsb.business.identity.cso.Header;
import com.capitalone.api.nsb.business.identity.cso.HighRiskIndustryCSO;
import com.capitalone.api.nsb.business.identity.cso.PhoneCSO;
import com.capitalone.api.nsb.business.identity.cso.RetrieveBusinessDetailsResponse;
import com.capitalone.api.nsb.business.identity.cso.TrustInfoCSO;
import com.capitalone.api.nsb.business.identity.cso.UpdateBusinessDetailsRequest;
import com.capitalone.api.nsb.business.identity.domain.Business;
import com.capitalone.api.nsb.business.identity.domain.BusinessAddress;
import com.capitalone.api.nsb.business.identity.domain.BusinessPhone;
import com.capitalone.api.nsb.business.identity.domain.HighRiskIndustry;
import com.capitalone.api.nsb.business.identity.domain.Trust;
import com.capitalone.api.nsb.business.identity.util.Util;

@RunWith(MockitoJUnitRunner.class)
public class BusinessIdentityConverterTest {

    private BusinessIdentityConverter businessIdentityConverter;

    @Mock
    private AddressTypeCacheHandler addressTypeCacheHandler;

    @Mock
    private AnnualRevenueRangeCacheHandler annualRevenueRangeCacheHandler;

    @Mock
    private BusinessStatusCacheHandler businessStatusCacheHandler;

    @Mock
    private BusinessStatusSubtypeCacheHandler businessStatusSubtypeCacheHandler;

    @Mock
    private HighRiskIndustryCodeCacheHandler highRiskIndustryCodeCacheHandler;

    @Mock
    private LegalEntityTypeCacheHandler legalEntityTypeCacheHandler;

    @Mock
    private OwnershipStructTypeCacheHandler ownershipStructTypeCacheHandler;

    @Mock
    private PhoneTypeCacheHandler phoneTypeCacheHandler;

    @Mock
    private TaxIdTypeCacheHandler taxIdTypeCacheHandler;

    @Mock
    private TrustAssetSourceCacheHandler trustAssetSourceCacheHandler;

    @Mock
    private TrustTypeCacheHandler trustTypeCacheHandler;

    @Mock
    private Util util;

    @Before
    public void setUp() throws Exception {
        businessIdentityConverter = new BusinessIdentityConverter();
        ReflectionTestUtils.setField(businessIdentityConverter, "annualRevenueRangeCacheHandler",
                annualRevenueRangeCacheHandler);
        ReflectionTestUtils.setField(businessIdentityConverter, "addressTypeCacheHandler", addressTypeCacheHandler);
        ReflectionTestUtils.setField(businessIdentityConverter, "businessStatusCacheHandler",
                businessStatusCacheHandler);
        ReflectionTestUtils.setField(businessIdentityConverter, "businessStatusSubtypeCacheHandler",
                businessStatusSubtypeCacheHandler);
        ReflectionTestUtils.setField(businessIdentityConverter, "highRiskIndustryCodeCacheHandler",
                highRiskIndustryCodeCacheHandler);
        ReflectionTestUtils.setField(businessIdentityConverter, "legalEntityTypeCacheHandler",
                legalEntityTypeCacheHandler);
        ReflectionTestUtils.setField(businessIdentityConverter, "ownershipStructTypeCacheHandler",
                ownershipStructTypeCacheHandler);
        ReflectionTestUtils.setField(businessIdentityConverter, "phoneTypeCacheHandler", phoneTypeCacheHandler);
        ReflectionTestUtils.setField(businessIdentityConverter, "taxIdTypeCacheHandler", taxIdTypeCacheHandler);
        ReflectionTestUtils.setField(businessIdentityConverter, "trustAssetSourceCacheHandler",
                trustAssetSourceCacheHandler);
        ReflectionTestUtils.setField(businessIdentityConverter, "trustTypeCacheHandler", trustTypeCacheHandler);
        ReflectionTestUtils.setField(businessIdentityConverter, "util", util);
    }

    @Test
    public void testMapCreateBusiness() {
        CreateBusinessDetailsRequest createBusinessDetailsRequest = new CreateBusinessDetailsRequest();
        populateCreateBusinessDetailsRequest(createBusinessDetailsRequest);
        Header header = new Header();
        header.setApiKey("xyz");
        header.setUserId("NSB");
        Business actual = new Business();
        when(util.isValidCollection(anyListOf(PhoneCSO.class))).thenReturn(true);
        actual = businessIdentityConverter.mapCreateBusiness(createBusinessDetailsRequest, header);
        assertEquals("XYZ Corp", actual.getName());
    }

    @Test
    public void testMapRetreiveBusinessResponse() {
        Business business = new Business();
        populateRetrieveBusinessDetailsResponse(business);
        when(util.isValidCollection(anyListOf(BusinessAddress.class))).thenReturn(true);
        when(util.isValidCollection(anyListOf(BusinessPhone.class))).thenReturn(true);
        when(businessStatusSubtypeCacheHandler.getBusinessStatusSubtypeDesc(1)).thenReturn("TRUE_NAME");
        when(trustTypeCacheHandler.getTrustTypeDesc(1)).thenReturn("Estate");
        when(trustAssetSourceCacheHandler.getTrustAssetSourceDesc(1)).thenReturn("Other");
        RetrieveBusinessDetailsResponse actual = businessIdentityConverter.mapRetreiveBusinessResponse(business);
        assertEquals("DBA-1", actual.getDoingBusinessAs());
    }

    @Test
    public void testMapRetreiveBusinessResponse_with_Business_null() {
        RetrieveBusinessDetailsResponse actual = businessIdentityConverter.mapRetreiveBusinessResponse(null);
        assertNull(actual);
    }

    @Test
    public void testMapUpdateBusiness() {
        Business business = new Business();
        populateRetrieveBusinessDetailsResponse(business);
        UpdateBusinessDetailsRequest updateBusinessDetailsRequest = new UpdateBusinessDetailsRequest();
        populateUpdateBusinessDetailsRequest(updateBusinessDetailsRequest);
        Header header = new Header();
        header.setApiKey("xyz");
        header.setUserId("NSB");
        businessIdentityConverter.mapUpdateBusiness(business, updateBusinessDetailsRequest, header);
        RetrieveBusinessDetailsResponse actual = businessIdentityConverter.mapRetreiveBusinessResponse(business);
        assertEquals("USA", actual.getCountryOfLegalFormation());
    }

    @Test
    public void testMapUpdateBusiness_with_Business_empty() {
        Business business = new Business();
        populateRetrieveBusinessDetailsResponse(business);
        UpdateBusinessDetailsRequest updateBusinessDetailsRequest = new UpdateBusinessDetailsRequest();
        Header header = new Header();
        header.setApiKey("xyz");
        header.setUserId("NSB");
        businessIdentityConverter.mapUpdateBusiness(business, updateBusinessDetailsRequest, header);
        RetrieveBusinessDetailsResponse actual = businessIdentityConverter.mapRetreiveBusinessResponse(business);
        assertEquals("USA", actual.getCountryOfLegalFormation());
    }

    @Test
    public void testMapUpdateBusiness_with_Business_null() {
        UpdateBusinessDetailsRequest updateBusinessDetailsRequest = new UpdateBusinessDetailsRequest();
        populateUpdateBusinessDetailsRequest(updateBusinessDetailsRequest);
        Header header = new Header();
        header.setApiKey("xyz");
        header.setUserId("NSB");
        Business actual = businessIdentityConverter.mapUpdateBusiness(null, updateBusinessDetailsRequest, header);
        assertNull(actual);
    }

    @Test
    public void testMapUpdateBusiness_with_updateBusinessDetailRequest_null() {
        Business business = new Business();
        populateRetrieveBusinessDetailsResponse(business);
        Header header = new Header();
        header.setApiKey("xyz");
        header.setUserId("NSB");
        Business actual = businessIdentityConverter.mapUpdateBusiness(business, null, header);
        assertNotNull(actual);
    }

    private void populateUpdateBusinessDetailsRequest(UpdateBusinessDetailsRequest updateBusinessDetailsRequest) {
        updateBusinessDetailsRequest.setAnnualRevenue("REVENUEUNDER20000");
        updateBusinessDetailsRequest.setBusinessCustomerSince("2017");
        updateBusinessDetailsRequest.setCountryOfHeadquarters("USA");
        updateBusinessDetailsRequest.setCountryOfLegalFormation("USA");
        updateBusinessDetailsRequest.setCountryOfPrimaryOperations("USA");
        updateBusinessDetailsRequest.setDoingBusinessAs("AMZ");
        updateBusinessDetailsRequest.setIndustryCode("111998");
        updateBusinessDetailsRequest.setCharitableOrganization(true);
        updateBusinessDetailsRequest.setLegalEntityType("NONPROFIT");
        updateBusinessDetailsRequest.setBusinessName("XYZ Company");
        updateBusinessDetailsRequest.setPurposeOfOrganization("Marketing");
        updateBusinessDetailsRequest.setBusinessCustomerStatus("Client");
        updateBusinessDetailsRequest.setBusinessCustomerStatusSubtype("IDTheft");
        updateBusinessDetailsRequest.setTaxIdToken("123456789");
        updateBusinessDetailsRequest.setTaxIdIssuingCountry("USA");
        updateBusinessDetailsRequest.setTaxIdType("1");
        updateBusinessDetailsRequest.setTaxStatus("Filed");
        updateBusinessDetailsRequest.setWebsiteAddress("www.google.com");
        updateBusinessDetailsRequest.setOwnershipStructureType("PrivatelyOwended");

        updateBusinessDetailsRequest.setTrustInfo(populateTrustInfo());
    }

    private TrustInfoCSO populateTrustInfo() {

        TrustInfoCSO trustInfo = new TrustInfoCSO();

        trustInfo.setTypeOfTrust("Other");
        trustInfo.setTypeOfTrustOther("Other");
        trustInfo.setWealthTrustAssetSource("Other");
        trustInfo.setWealthTrustAssetSourceOther("Other");
        trustInfo.setIsTrustFundedFromOffshore(true);
        trustInfo.setDoesTrustBenefitCharitableOrganizations(true);

        return trustInfo;
    }

    private void populateRetrieveBusinessDetailsResponse(Business business) {

        List<HighRiskIndustry> highRiskIndustriesObjList = getHighRiskIndustryList();
        business.setHighRiskIndustries(highRiskIndustriesObjList);

        List<BusinessPhone> phoneList = getPhoneList();
        business.setPhoneNumbers(phoneList);

        List<BusinessAddress> addressList = getBusinessAddressList();
        business.setAddresses(addressList);

        Trust trust = getTrust();
        business.setTrust(trust);

        business.setLegalEntityType(new Integer(1));
        business.setName("XYZ Corp");
        business.setTaxIdType(new Integer(1));
        business.setTaxId("123456789");
        // business.setIndustryCode("111998");
        business.setOwnershipStructureType(new Integer(1));
        business.setDoingBusinessAs("DBA-1");
        business.setWebsiteAddress("mywebsite.com");
        business.setTaxIdIssuingCountry("USA");
        business.setCountryOfHeadquarters("USA");
        business.setCountryOfLegalFormation("USA");
        business.setCountryOfPrimaryOperations("USA");
        business.setAnnualRevenue(new Integer(1));
        // business.setDoesTrustBenefitCharitableOrganizations(false);
        business.setPurposeOfOrganization("Y");
        // business.setRepeatedInternationalActivity(false);
        business.setTaxStatus("Yes");
        business.setStatus(new Integer(5));
        business.setStatusSubtype(new Integer(1));
        // business.setBusinessSince("2017-05-25 17:36:07.072708");
        // business.setTrustFundedFromOffshore(false);
        // business.setCharitableOrganization(true);

    }

    private Trust getTrust() {
        Trust trust = new Trust();
        trust.setTrustTypeId(new Integer(1));
        trust.setTrustAssetSourceId(new Integer(1));
        return trust;
    }

    private List<BusinessAddress> getBusinessAddressList() {

        List<BusinessAddress> addressList = new ArrayList<BusinessAddress>();
        BusinessAddress businessAddressCSO1 = new BusinessAddress();
        BusinessAddress businessAddressCSO2 = new BusinessAddress();
        BusinessAddress businessAddressCSO3 = new BusinessAddress();
        addressList.add(businessAddressCSO1);
        addressList.add(businessAddressCSO2);
        addressList.add(businessAddressCSO3);

        return addressList;
    }

    private List<BusinessPhone> getPhoneList() {

        List<BusinessPhone> phoneList = new ArrayList<BusinessPhone>();
        BusinessPhone businessPhone1 = new BusinessPhone();
        BusinessPhone businessPhone2 = new BusinessPhone();
        BusinessPhone businessPhone3 = new BusinessPhone();
        phoneList.add(businessPhone1);
        phoneList.add(businessPhone2);
        phoneList.add(businessPhone3);

        return phoneList;
    }

    private List<HighRiskIndustry> getHighRiskIndustryList() {

        List<HighRiskIndustry> highRiskIndustriesObjList = new ArrayList<HighRiskIndustry>();
        HighRiskIndustry highRiskIndustry1 = new HighRiskIndustry();
        highRiskIndustry1.setHighRiskIndustryCode(952000);
        HighRiskIndustry highRiskIndustry2 = new HighRiskIndustry();
        highRiskIndustry2.setHighRiskIndustryCode(950000);
        HighRiskIndustry highRiskIndustry3 = new HighRiskIndustry();
        highRiskIndustry3.setHighRiskIndustryCode(952000);
        highRiskIndustriesObjList.add(highRiskIndustry1);
        highRiskIndustriesObjList.add(highRiskIndustry2);
        highRiskIndustriesObjList.add(highRiskIndustry3);

        return highRiskIndustriesObjList;
    }

    private void populateCreateBusinessDetailsRequest(CreateBusinessDetailsRequest createBusinessIdentityRequest) {

        List<HighRiskIndustryCSO> highRiskIndustriesObjList = getHighRiskIndustryCSOList();
        createBusinessIdentityRequest.setAssociatedHighRiskIndustyCodes(highRiskIndustriesObjList);

        List<PhoneCSO> phoneList = getPhoneCSOList();
        createBusinessIdentityRequest.setPhoneNumbers(phoneList);

        List<AddressCSO> addressList = getAddressCSOList();
        createBusinessIdentityRequest.setAddresses(addressList);

        createBusinessIdentityRequest.setLegalEntityType("1");
        createBusinessIdentityRequest.setBusinessName("XYZ Corp");
        createBusinessIdentityRequest.setTaxIdType("1");
        createBusinessIdentityRequest.setTaxIdToken("123456789");
        createBusinessIdentityRequest.setIndustryCode("111998");
        createBusinessIdentityRequest.setOwnershipStructureType("1");
        createBusinessIdentityRequest.setDoingBusinessAs("DBA-1");
        createBusinessIdentityRequest.setWebsiteAddress("mywebsite.com");
        createBusinessIdentityRequest.setTaxIdIssuingCountry("USA");
        createBusinessIdentityRequest.setCountryOfHeadquarters("USA");
        createBusinessIdentityRequest.setCountryOfLegalFormation("USA");
        createBusinessIdentityRequest.setCountryOfPrimaryOperations("USA");
        createBusinessIdentityRequest.setAnnualRevenue("1");
        createBusinessIdentityRequest.setPurposeOfOrganization("Y");
        createBusinessIdentityRequest.setHasRepeatedInternationalActivity(false);
        createBusinessIdentityRequest.setTaxStatus("Yes");
        createBusinessIdentityRequest.setBusinessCustomerStatus("5");
        createBusinessIdentityRequest.setBusinessCustomerStatusSubtype("123");
        createBusinessIdentityRequest.setBusinessCustomerSince("2017-05-25 17:36:07.072708");
        createBusinessIdentityRequest.setCharitableOrganization(true);

        TrustInfoCSO trustInfo = new TrustInfoCSO();
        trustInfo.setIsTrustFundedFromOffshore(false);
        trustInfo.setDoesTrustBenefitCharitableOrganizations(false);

        createBusinessIdentityRequest.setTrustInfo(trustInfo);

    }

    private List<PhoneCSO> getPhoneCSOList() {

        List<PhoneCSO> phoneList = new ArrayList<PhoneCSO>();
        PhoneCSO phoneCSO1 = new PhoneCSO();
        PhoneCSO phoneCSO2 = new PhoneCSO();
        PhoneCSO phoneCSO3 = new PhoneCSO();
        phoneList.add(phoneCSO1);
        phoneList.add(phoneCSO2);
        phoneList.add(phoneCSO3);

        return phoneList;
    }

    private List<AddressCSO> getAddressCSOList() {

        List<AddressCSO> addressList = new ArrayList<AddressCSO>();
        AddressCSO addressCSO1 = new AddressCSO();
        AddressCSO addressCSO2 = new AddressCSO();
        AddressCSO addressCSO3 = new AddressCSO();
        addressList.add(addressCSO1);
        addressList.add(addressCSO2);
        addressList.add(addressCSO3);

        return addressList;
    }

    private List<HighRiskIndustryCSO> getHighRiskIndustryCSOList() {

        List<HighRiskIndustryCSO> highRiskIndustriesObjList = new ArrayList<HighRiskIndustryCSO>();
        HighRiskIndustryCSO highRiskIndustry1 = new HighRiskIndustryCSO();
        highRiskIndustry1.setHighRiskIndustryCode(952000);
        HighRiskIndustryCSO highRiskIndustry2 = new HighRiskIndustryCSO();
        highRiskIndustry2.setHighRiskIndustryCode(950000);
        HighRiskIndustryCSO highRiskIndustry3 = new HighRiskIndustryCSO();
        highRiskIndustry3.setHighRiskIndustryCode(952000);
        highRiskIndustriesObjList.add(highRiskIndustry1);
        highRiskIndustriesObjList.add(highRiskIndustry2);
        highRiskIndustriesObjList.add(highRiskIndustry3);

        return highRiskIndustriesObjList;
    }

}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
