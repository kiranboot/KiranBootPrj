package com.capitalone.api.nsb.business.identity.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.capitalone.api.nsb.business.identity.domain.cache.AnnualRevenueRange;
import com.capitalone.api.nsb.business.identity.service.CacheService;

@RunWith(MockitoJUnitRunner.class)
public class AnnualRevenueRangeCacheHandlerTest {
    private AnnualRevenueRangeCacheHandler annualRevenueRangeCacheHandler;

    @Mock
    private Cache<Integer, String> annualRevenueRangeCache;

    @Mock
    private CacheService cacheService;

    @Mock
    private BusinessIdentityCacheManager cacheManager;

    @Before
    public void setUp() throws Exception {
        annualRevenueRangeCacheHandler = new AnnualRevenueRangeCacheHandler();
        ReflectionTestUtils.setField(annualRevenueRangeCacheHandler, "annualRevenueRangeCache", annualRevenueRangeCache);
        ReflectionTestUtils.setField(annualRevenueRangeCacheHandler, "cacheService", cacheService);
        ReflectionTestUtils.setField(annualRevenueRangeCacheHandler, "cacheManager", cacheManager);
    }

    @Test
    public void testGetAnnualRevenueRangeDesc() {
        int annualRevenueRangeId = 1;
        when(annualRevenueRangeCache.iterator()).thenReturn(getCacheIterator());
        when(annualRevenueRangeCache.get(annualRevenueRangeId)).thenReturn("Under $20,000");
        String actual = annualRevenueRangeCacheHandler.getAnnualRevenueRangeDesc(annualRevenueRangeId);
        assertEquals("Under $20,000", actual);
    }

    @Test
    public void testGetAnnualRevenueRangeDesc_refresh() {
        int annualRevenueRangeId = 1;

        List<AnnualRevenueRange> annualRevenueRangeList = new ArrayList<AnnualRevenueRange>();
        annualRevenueRangeList.add(new AnnualRevenueRange());
        annualRevenueRangeList.add(null);
        when(cacheService.getAnnualRevenueRange()).thenReturn(annualRevenueRangeList);

        when(annualRevenueRangeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(annualRevenueRangeCache.get(annualRevenueRangeId)).thenReturn("Under $20,000");
        String actual = annualRevenueRangeCacheHandler.getAnnualRevenueRangeDesc(annualRevenueRangeId);
        assertEquals("Under $20,000", actual);
    }

    @Test
    public void testGetAnnualRevenueRangeDesc_initialize() {

        ReflectionTestUtils.setField(annualRevenueRangeCacheHandler, "annualRevenueRangeCache", null);

        int annualRevenueRangeId = 1;

        when(cacheManager.initializeCache("annualRevenueRangeCache", Integer.class, String.class)).thenReturn(annualRevenueRangeCache);
        when(annualRevenueRangeCache.get(annualRevenueRangeId)).thenReturn("Under $20,000");
        String actual = annualRevenueRangeCacheHandler.getAnnualRevenueRangeDesc(annualRevenueRangeId);
        assertEquals("Under $20,000", actual);
    }

    @Test
    public void testGetAnnualRevenueRangeDesc_with_empty_map() {

        int annualRevenueRangeId = 1;

        when(annualRevenueRangeCache.iterator()).thenReturn(getCacheIterator());
        when(annualRevenueRangeCache.get(annualRevenueRangeId)).thenReturn("Under $20,000");

        List<AnnualRevenueRange> annualRevenueRangeList = new ArrayList<AnnualRevenueRange>();
        when(cacheService.getAnnualRevenueRange()).thenReturn(annualRevenueRangeList);
        String actual = annualRevenueRangeCacheHandler.getAnnualRevenueRangeDesc(annualRevenueRangeId);
        assertEquals("Under $20,000", actual);
    }

    @Test
    public void testGetAnnualRevenueRangeDesc_cache_not_initialized() {
        int annualRevenueRangeId = 1;

        when(annualRevenueRangeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(annualRevenueRangeCache.get(annualRevenueRangeId)).thenReturn("Under $20,000");
        String actual = annualRevenueRangeCacheHandler.getAnnualRevenueRangeDesc(annualRevenueRangeId);
        assertEquals("Under $20,000", actual);
    }

    @Test
    public void testGetAnnualRevenueRangeId() {

        when(annualRevenueRangeCache.iterator()).thenReturn(getCacheIterator());

        int actual = annualRevenueRangeCacheHandler.getAnnualRevenueRangeId("Under $20,000");
        assertEquals(1, actual);
    }

    @Test
    public void testGetAnnualRevenueRangeId_refresh() {

        when(annualRevenueRangeCache.iterator()).thenReturn(getEmptyCacheIterator());

        int actual = annualRevenueRangeCacheHandler.getAnnualRevenueRangeId("Under $20,000");
        assertEquals(0, actual);
    }

    @Test
    public void testGetAnnualRevenueRangeId_no_match() {

        when(annualRevenueRangeCache.iterator()).thenReturn(getCacheIterator_no_match());

        int actual = annualRevenueRangeCacheHandler.getAnnualRevenueRangeId("XYZ");
        assertNotEquals(1, actual);
    }

    @Test
    public void testGetAnnualRevenueRangeId_with_no_match() {
        when(annualRevenueRangeCache.iterator()).thenReturn(getCacheIterator_no_match());
        int actual = annualRevenueRangeCacheHandler.getAnnualRevenueRangeId("XYZ");
        assertEquals(0, actual);
    }

    @Test
    public void testGetAnnualRevenueRangeId_with_blank_Address_Type_Name() {
        when(annualRevenueRangeCache.iterator()).thenReturn(getCacheIterator());
        int actual = annualRevenueRangeCacheHandler.getAnnualRevenueRangeId("");
        assertEquals(0, actual);
    }

    private Iterator<Entry<Integer, String>> getCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 1;
                    }

                    @Override
                    public String getValue() {
                        return "Under $20,000";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getEmptyCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            @Override
            public Entry<Integer, String> next() {
                return null;
            }

            @Override
            public boolean hasNext() {
                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getCacheIterator_no_match() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 2;
                    }

                    @Override
                    public String getValue() {
                        return "Under $20,000";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
