package com.capitalone.api.nsb.business.identity;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.capitalone.api.nsb.business.identity.cso.CreateBusinessDetailsRequest;
import com.capitalone.api.nsb.business.identity.cso.HighRiskIndustryCSO;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
public class BusinessIdentityApplicationTestsIT {

	String retrieveBusinessIdentityEndPoint = "{businessReferenceId}";
	String createBusinessDetailRequest = "";
	@LocalServerPort
	int port;
	
	{
		RestAssured.basePath = "/small-business/businesses"; 
	}
	
	
	public CreateBusinessDetailsRequest getBusinessDetailObj(){
		CreateBusinessDetailsRequest businessDetailObj = new CreateBusinessDetailsRequest();
		List<HighRiskIndustryCSO> highRiskIndustriesObjList = new ArrayList<HighRiskIndustryCSO>();
		HighRiskIndustryCSO highRiskIndustry1 = new HighRiskIndustryCSO();
		highRiskIndustry1.setHighRiskIndustryCode(952000);
		HighRiskIndustryCSO highRiskIndustry2 = new HighRiskIndustryCSO();
		highRiskIndustry2.setHighRiskIndustryCode(950000);
		HighRiskIndustryCSO highRiskIndustry3 = new HighRiskIndustryCSO();
		highRiskIndustry3.setHighRiskIndustryCode(952000);
		highRiskIndustriesObjList.add(highRiskIndustry1);
		highRiskIndustriesObjList.add(highRiskIndustry2);
		highRiskIndustriesObjList.add(highRiskIndustry3);
		
		businessDetailObj.setLegalEntityType("1");
		businessDetailObj.setBusinessName("XYZ Corp");
		businessDetailObj.setTaxIdType("1");
		businessDetailObj.setTaxIdToken("123456789");
		businessDetailObj.setIndustryCode("111998");
		businessDetailObj.setOwnershipStructureType("1");
		businessDetailObj.setDoingBusinessAs("DBA-1");
		businessDetailObj.setWebsiteAddress("mywebsite.com");
		businessDetailObj.setTaxIdIssuingCountry("USA");
		businessDetailObj.setCountryOfHeadquarters("USA");
		businessDetailObj.setCountryOfLegalFormation("USA");
		businessDetailObj.setCountryOfPrimaryOperations("USA");
		businessDetailObj.setAnnualRevenue("1");
//		businessDetailObj.setDoesTrustBenefitCharitableOrganizations(false);
		businessDetailObj.setPurposeOfOrganization("Y");
		businessDetailObj.setHasRepeatedInternationalActivity(false);
		businessDetailObj.setTaxStatus("Yes");
		businessDetailObj.setBusinessCustomerStatus("5");
		businessDetailObj.setBusinessCustomerStatusSubtype("123");
		businessDetailObj.setBusinessCustomerSince("2017-05-25 17:36:07.072708");
//		businessDetailObj.setTrustFundedFromOffshore(false);
		businessDetailObj.setCharitableOrganization(true);
		
		businessDetailObj.setAssociatedHighRiskIndustyCodes(highRiskIndustriesObjList);
		return businessDetailObj;
	}
	

	@Test
	public void createBusinessIdentityTest()
    {
		
        given().
        	port(port).
        	header("User-Id", "User-Id").
        	header("Api-Key", "Api-Key").
        	contentType("application/json").
            body(getBusinessDetailObj()).
        when().
            post().
        then().
        	contentType(ContentType.JSON).
        	statusCode(200).log().all();
    }
	
	@Test
	public void retrieveBusinessIdentityTest()
    {
        given().
        	port(port).
        	pathParam("businessReferenceId", "12").
        	header("User-Id", "User-Id").
        	header("Api-Key", "Api-Key").
        when().
            get(retrieveBusinessIdentityEndPoint).
        then().
        	contentType(ContentType.JSON).
        	statusCode(200).
        	body("businessReferenceId", equalTo("12")).log().all();
    }
}
