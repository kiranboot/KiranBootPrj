package com.capitalone.api.nsb.business.identity.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.capitalone.api.nsb.business.identity.cso.CreateBusinessDetailsRequest;
import com.capitalone.api.nsb.business.identity.cso.CreateBusinessDetailsResponse;
import com.capitalone.api.nsb.business.identity.cso.Header;
import com.capitalone.api.nsb.business.identity.cso.HighRiskIndustryCSO;
import com.capitalone.api.nsb.business.identity.cso.RetrieveBusinessDetailsResponse;
import com.capitalone.api.nsb.business.identity.cso.TrustInfoCSO;
import com.capitalone.api.nsb.business.identity.cso.UpdateBusinessDetailsRequest;
import com.capitalone.api.nsb.business.identity.exception.RequestValidationException;
import com.capitalone.api.nsb.business.identity.service.BusinessIdentityService;

@RunWith(MockitoJUnitRunner.class)
public class BusinessIdentityResourceControllerTest {

    private BusinessIdentityResourceController businessIdentityResourceController;

    @Mock
    private BusinessIdentityService businessIdentityService;

    @Before
    public void setUp() throws Exception {
        businessIdentityResourceController = new BusinessIdentityResourceController();
        ReflectionTestUtils.setField(businessIdentityResourceController, "businessIdentityService",
                businessIdentityService);
    }

    @Test
    public void testCreateBusinessDetails() {
        Header header = new Header();
        header.setApiKey("xyz");
        header.setUserId("NSB");
        CreateBusinessDetailsRequest createBusinessDetailsRequest = new CreateBusinessDetailsRequest();
        populateCreateBusinessDetailsRequest(createBusinessDetailsRequest);
        CreateBusinessDetailsResponse expected = new CreateBusinessDetailsResponse();
        when(businessIdentityService.addBusiness(createBusinessDetailsRequest, header)).thenReturn(expected);
        businessIdentityResourceController.createBusinessDetails(createBusinessDetailsRequest, "NSB", "NSB");
        assertNotNull(expected);
    }

    private void populateCreateBusinessDetailsRequest(CreateBusinessDetailsRequest createBusinessIdentityRequest) {

        List<HighRiskIndustryCSO> highRiskIndustriesObjList = getHighRiskIndustryCSOList();
        createBusinessIdentityRequest.setAssociatedHighRiskIndustyCodes(highRiskIndustriesObjList);

        createBusinessIdentityRequest.setLegalEntityType("1");
        createBusinessIdentityRequest.setBusinessName("XYZ Corp");
        createBusinessIdentityRequest.setTaxIdType("1");
        createBusinessIdentityRequest.setTaxIdToken("123456789");
        createBusinessIdentityRequest.setIndustryCode("111998");
        createBusinessIdentityRequest.setOwnershipStructureType("1");
        createBusinessIdentityRequest.setDoingBusinessAs("DBA-1");
        createBusinessIdentityRequest.setWebsiteAddress("mywebsite.com");
        createBusinessIdentityRequest.setTaxIdIssuingCountry("USA");
        createBusinessIdentityRequest.setCountryOfHeadquarters("USA");
        createBusinessIdentityRequest.setCountryOfLegalFormation("USA");
        createBusinessIdentityRequest.setCountryOfPrimaryOperations("USA");
        createBusinessIdentityRequest.setAnnualRevenue("1");
        createBusinessIdentityRequest.setPurposeOfOrganization("Y");
        createBusinessIdentityRequest.setHasRepeatedInternationalActivity(false);
        createBusinessIdentityRequest.setTaxStatus("Yes");
        createBusinessIdentityRequest.setBusinessCustomerStatus("5");
        createBusinessIdentityRequest.setBusinessCustomerStatusSubtype("123");
        createBusinessIdentityRequest.setBusinessCustomerSince("2017-05-25 17:36:07.072708");
        createBusinessIdentityRequest.setCharitableOrganization(true);

        TrustInfoCSO trustInfo = new TrustInfoCSO();
        trustInfo.setIsTrustFundedFromOffshore(false);
        trustInfo.setDoesTrustBenefitCharitableOrganizations(false);

        createBusinessIdentityRequest.setTrustInfo(trustInfo);

    }

    private List<HighRiskIndustryCSO> getHighRiskIndustryCSOList() {

        List<HighRiskIndustryCSO> highRiskIndustriesObjList = new ArrayList<HighRiskIndustryCSO>();
        HighRiskIndustryCSO highRiskIndustry1 = new HighRiskIndustryCSO();
        highRiskIndustry1.setHighRiskIndustryCode(952000);
        HighRiskIndustryCSO highRiskIndustry2 = new HighRiskIndustryCSO();
        highRiskIndustry2.setHighRiskIndustryCode(950000);
        HighRiskIndustryCSO highRiskIndustry3 = new HighRiskIndustryCSO();
        highRiskIndustry3.setHighRiskIndustryCode(952000);
        highRiskIndustriesObjList.add(highRiskIndustry1);
        highRiskIndustriesObjList.add(highRiskIndustry2);
        highRiskIndustriesObjList.add(highRiskIndustry3);

        return highRiskIndustriesObjList;
    }

    @Test
    public void testGetBusinessDetails() {
        String businessReferenceId = "12";
        RetrieveBusinessDetailsResponse retrieveBusinessDetailsResponse = new RetrieveBusinessDetailsResponse();
        populateRetrieveBusinessDetailsResponse(retrieveBusinessDetailsResponse);
        when(businessIdentityService.getBusiness(new BigInteger(businessReferenceId)))
                .thenReturn(retrieveBusinessDetailsResponse);
        businessIdentityResourceController.getBusinessDetails(businessReferenceId, "NSB", "NSB");
        assertEquals("XYZ Corp", retrieveBusinessDetailsResponse.getBusinessName());
    }

    private void populateRetrieveBusinessDetailsResponse(
            RetrieveBusinessDetailsResponse retrieveBusinessDetailsResponse) {
        List<HighRiskIndustryCSO> highRiskIndustriesObjList = getHighRiskIndustryCSOList();
        retrieveBusinessDetailsResponse.setAssociatedHighRiskIndustyCodes(highRiskIndustriesObjList);

        retrieveBusinessDetailsResponse.setLegalEntityType("1");
        retrieveBusinessDetailsResponse.setBusinessName("XYZ Corp");
        retrieveBusinessDetailsResponse.setTaxIdType("1");
        retrieveBusinessDetailsResponse.setTaxIdToken("123456789");
        retrieveBusinessDetailsResponse.setIndustryCode("111998");
        retrieveBusinessDetailsResponse.setOwnershipStructureType("1");
        retrieveBusinessDetailsResponse.setDoingBusinessAs("DBA-1");
        retrieveBusinessDetailsResponse.setWebsiteAddress("mywebsite.com");
        retrieveBusinessDetailsResponse.setTaxIdIssuingCountry("USA");
        retrieveBusinessDetailsResponse.setCountryOfHeadquarters("USA");
        retrieveBusinessDetailsResponse.setCountryOfLegalFormation("USA");
        retrieveBusinessDetailsResponse.setCountryOfPrimaryOperations("USA");
        retrieveBusinessDetailsResponse.setAnnualRevenue("1");
        retrieveBusinessDetailsResponse.setPurposeOfOrganization("Y");
        retrieveBusinessDetailsResponse.setHasRepeatedInternationalActivity(false);
        retrieveBusinessDetailsResponse.setTaxStatus("Yes");
        retrieveBusinessDetailsResponse.setBusinessCustomerStatus("5");
        retrieveBusinessDetailsResponse.setBusinessCustomerStatusSubtype("123");
        retrieveBusinessDetailsResponse.setBusinessCustomerSince("2017-05-25 17:36:07.072708");
        retrieveBusinessDetailsResponse.setCharitableOrganization(true);

        TrustInfoCSO trustInfo = new TrustInfoCSO();
        trustInfo.setIsTrustFundedFromOffshore(true);
        trustInfo.setDoesTrustBenefitCharitableOrganizations(true);

        retrieveBusinessDetailsResponse.setTrustInfo(trustInfo);

    }

    @Test(expected = RequestValidationException.class)
    public void testGetBusinessDetails_with_null_bif() {
        String businessReferenceId = null;
        businessIdentityResourceController.getBusinessDetails(businessReferenceId, "NSB", "NSB");
    }

    @Test
    public void testUpdateBusinessDetails() {
        String businessReferenceId = "12";
        UpdateBusinessDetailsRequest updateBusinessDetailsRequest = new UpdateBusinessDetailsRequest();
        businessIdentityResourceController.updateBusinessDetails(businessReferenceId, updateBusinessDetailsRequest,
                "NSB", "NSB");
    }

    @Test(expected = RequestValidationException.class)
    public void testUpdateBusinessDetails_with_null_bif() {
        String businessReferenceId = null;
        UpdateBusinessDetailsRequest updateBusinessDetailsRequest = new UpdateBusinessDetailsRequest();
        businessIdentityResourceController.updateBusinessDetails(businessReferenceId, updateBusinessDetailsRequest,
                "NSB", "NSB");
    }

}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
