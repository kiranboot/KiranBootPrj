package com.capitalone.api.nsb.business.identity.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.capitalone.api.nsb.business.identity.domain.cache.TrustType;
import com.capitalone.api.nsb.business.identity.service.CacheService;

@RunWith(MockitoJUnitRunner.class)
public class TrustTypeCacheHandlerTest {

    private TrustTypeCacheHandler trustTypeCacheHandler;

    @Mock
    private Cache<Integer, String> trustTypeCache;

    @Mock
    private CacheService cacheService;

    @Mock
    private BusinessIdentityCacheManager cacheManager;

    @Before
    public void setUp() throws Exception {
        trustTypeCacheHandler = new TrustTypeCacheHandler();
        ReflectionTestUtils.setField(trustTypeCacheHandler, "trustTypeCache", trustTypeCache);
        ReflectionTestUtils.setField(trustTypeCacheHandler, "cacheService", cacheService);
        ReflectionTestUtils.setField(trustTypeCacheHandler, "cacheManager", cacheManager);
    }

    @Test
    public void testGetTrustTypeDesc() {
        int trustTypeId = 1;
        when(trustTypeCache.iterator()).thenReturn(getCacheIterator());
        when(trustTypeCache.get(trustTypeId)).thenReturn("Estate");
        String actual = trustTypeCacheHandler.getTrustTypeDesc(trustTypeId);
        assertEquals("Estate", actual);
    }

    @Test
    public void testGetTrustTypeDesc_refresh() {
        int trustTypeId = 1;

        List<TrustType> trustList = new ArrayList<TrustType>();
        trustList.add(new TrustType());
        trustList.add(null);
        when(cacheService.getTrustTypes()).thenReturn(trustList);

        when(trustTypeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(trustTypeCache.get(trustTypeId)).thenReturn("Estate");
        String actual = trustTypeCacheHandler.getTrustTypeDesc(trustTypeId);
        assertEquals("Estate", actual);
    }

    @Test
    public void testGetTrustTypeDesc_initialize() {

        ReflectionTestUtils.setField(trustTypeCacheHandler, "trustTypeCache", null);

        int trustTypeId = 1;

        when(cacheManager.initializeCache("trustTypeCache", Integer.class, String.class)).thenReturn(trustTypeCache);
        when(trustTypeCache.get(trustTypeId)).thenReturn("Estate");
        String actual = trustTypeCacheHandler.getTrustTypeDesc(trustTypeId);
        assertEquals("Estate", actual);
    }

    @Test
    public void testGetTrustTypeDesc_with_empty_map() {

        int trustTypeId = 1;

        when(trustTypeCache.iterator()).thenReturn(getCacheIterator());
        when(trustTypeCache.get(trustTypeId)).thenReturn("Estate");

        List<TrustType> trustTypeList = new ArrayList<TrustType>();
        when(cacheService.getTrustTypes()).thenReturn(trustTypeList);
        String actual = trustTypeCacheHandler.getTrustTypeDesc(1);
        assertEquals("Estate", actual);
    }

    @Test
    public void testGetTrustTypeDesc_cache_not_initialized() {
        int trustTypeId = 1;

        when(trustTypeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(trustTypeCache.get(trustTypeId)).thenReturn("Estate");
        String actual = trustTypeCacheHandler.getTrustTypeDesc(trustTypeId);
        assertEquals("Estate", actual);
    }

    @Test
    public void testGetTrustTypeId() {

        when(trustTypeCache.iterator()).thenReturn(getCacheIterator());

        int actual = trustTypeCacheHandler.getTrustTypeId("Estate");
        assertEquals(1, actual);
    }

    @Test
    public void testGetTrustTypeId_refresh() {

        when(trustTypeCache.iterator()).thenReturn(getEmptyCacheIterator());

        int actual = trustTypeCacheHandler.getTrustTypeId("Estate");
        assertEquals(0, actual);
    }

    @Test
    public void testGetTrustTypeId_no_match() {

        when(trustTypeCache.iterator()).thenReturn(getCacheIterator_no_match());

        int actual = trustTypeCacheHandler.getTrustTypeId("XYZ");
        assertNotEquals(1, actual);
    }

    @Test
    public void testGetTrustTypeId_with_no_match() {
        when(trustTypeCache.iterator()).thenReturn(getCacheIterator_no_match());
        int actual = trustTypeCacheHandler.getTrustTypeId("XYZ");
        assertEquals(0, actual);
    }

    @Test
    public void testGetTrustTypeId_with_blank_trust_Type_Desc() {
        when(trustTypeCache.iterator()).thenReturn(getCacheIterator());
        int actual = trustTypeCacheHandler.getTrustTypeId("");
        assertEquals(0, actual);
    }

    private Iterator<Entry<Integer, String>> getCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 1;
                    }

                    @Override
                    public String getValue() {
                        return "Estate";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getEmptyCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            @Override
            public Entry<Integer, String> next() {
                return null;
            }

            @Override
            public boolean hasNext() {
                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getCacheIterator_no_match() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 2;
                    }

                    @Override
                    public String getValue() {
                        return "Estate";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
