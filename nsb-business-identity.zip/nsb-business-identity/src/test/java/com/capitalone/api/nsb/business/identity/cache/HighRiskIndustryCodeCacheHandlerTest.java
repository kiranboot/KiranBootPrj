package com.capitalone.api.nsb.business.identity.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.capitalone.api.nsb.business.identity.domain.cache.HighRiskIndustryCode;
import com.capitalone.api.nsb.business.identity.service.CacheService;

@RunWith(MockitoJUnitRunner.class)
public class HighRiskIndustryCodeCacheHandlerTest {

    private HighRiskIndustryCodeCacheHandler highRiskIndustryCodeCacheHandler;

    @Mock
    private Cache<Integer, String> highRiskIndustryCodeCache;

    @Mock
    private CacheService cacheService;

    @Mock
    private BusinessIdentityCacheManager cacheManager;

    @Before
    public void setUp() throws Exception {
        highRiskIndustryCodeCacheHandler = new HighRiskIndustryCodeCacheHandler();
        ReflectionTestUtils.setField(highRiskIndustryCodeCacheHandler, "highRiskIndustryCodeCache", highRiskIndustryCodeCache);
        ReflectionTestUtils.setField(highRiskIndustryCodeCacheHandler, "cacheService", cacheService);
        ReflectionTestUtils.setField(highRiskIndustryCodeCacheHandler, "cacheManager", cacheManager);
    }

    @Test
    public void testGetHighRiskIndustryCodeDesc() {
        int highRiskIndustryCode = 1;
        when(highRiskIndustryCodeCache.iterator()).thenReturn(getCacheIterator());
        when(highRiskIndustryCodeCache.get(highRiskIndustryCode)).thenReturn("Money Order Issuance Services");
        String actual = highRiskIndustryCodeCacheHandler.getHighRiskIndustryCodeDesc(highRiskIndustryCode);
        assertEquals("Money Order Issuance Services", actual);
    }

    @Test
    public void testGetHighRiskIndustryCodeDesc_refresh() {
        int highRiskIndustryCode = 1;

        List<HighRiskIndustryCode> highRiskIndustryCodeList = new ArrayList<HighRiskIndustryCode>();
        highRiskIndustryCodeList.add(new HighRiskIndustryCode());
        highRiskIndustryCodeList.add(null);
        when(cacheService.getHighRiskIndustryCodes()).thenReturn(highRiskIndustryCodeList);

        when(highRiskIndustryCodeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(highRiskIndustryCodeCache.get(highRiskIndustryCode)).thenReturn("Money Order Issuance Services");
        String actual = highRiskIndustryCodeCacheHandler.getHighRiskIndustryCodeDesc(highRiskIndustryCode);
        assertEquals("Money Order Issuance Services", actual);
    }

    @Test
    public void testGetHighRiskIndustryCodeDesc_initialize() {

        ReflectionTestUtils.setField(highRiskIndustryCodeCacheHandler, "highRiskIndustryCodeCache", null);

        int highRiskIndustryCode = 1;

        when(cacheManager.initializeCache("highRiskIndustryCodeCache", Integer.class, String.class)).thenReturn(highRiskIndustryCodeCache);
        when(highRiskIndustryCodeCache.get(highRiskIndustryCode)).thenReturn("Money Order Issuance Services");
        String actual = highRiskIndustryCodeCacheHandler.getHighRiskIndustryCodeDesc(highRiskIndustryCode);
        assertEquals("Money Order Issuance Services", actual);
    }

    @Test
    public void testGetHighRiskIndustryCodeDesc_with_empty_map() {

        int highRiskIndustryCode = 1;

        when(highRiskIndustryCodeCache.iterator()).thenReturn(getCacheIterator());
        when(highRiskIndustryCodeCache.get(highRiskIndustryCode)).thenReturn("Money Order Issuance Services");

        List<HighRiskIndustryCode> highRiskIndustryCodeList = new ArrayList<HighRiskIndustryCode>();
        when(cacheService.getHighRiskIndustryCodes()).thenReturn(highRiskIndustryCodeList);
        String actual = highRiskIndustryCodeCacheHandler.getHighRiskIndustryCodeDesc(1);
        assertEquals("Money Order Issuance Services", actual);
    }

    @Test
    public void testGetHighRiskIndustryCodeDesc_cache_not_initialized() {
        int highRiskIndustryCode = 1;

        when(highRiskIndustryCodeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(highRiskIndustryCodeCache.get(highRiskIndustryCode)).thenReturn("Money Order Issuance Services");
        String actual = highRiskIndustryCodeCacheHandler.getHighRiskIndustryCodeDesc(highRiskIndustryCode);
        assertEquals("Money Order Issuance Services", actual);
    }

    @Test
    public void testGetHighRiskIndustryCode() {

        when(highRiskIndustryCodeCache.iterator()).thenReturn(getCacheIterator());

        int actual = highRiskIndustryCodeCacheHandler.getHighRiskIndustryCode("Money Order Issuance Services");
        assertEquals(1, actual);
    }

    @Test
    public void testGetHighRiskIndustryCode_refresh() {

        when(highRiskIndustryCodeCache.iterator()).thenReturn(getEmptyCacheIterator());

        int actual = highRiskIndustryCodeCacheHandler.getHighRiskIndustryCode("Money Order Issuance Services");
        assertEquals(0, actual);
    }

    @Test
    public void testGetHighRiskIndustryCode_no_match() {

        when(highRiskIndustryCodeCache.iterator()).thenReturn(getCacheIterator_no_match());

        int actual = highRiskIndustryCodeCacheHandler.getHighRiskIndustryCode("XYZ");
        assertNotEquals(1, actual);
    }

    @Test
    public void testGetHighRiskIndustryCode_with_no_match() {
        when(highRiskIndustryCodeCache.iterator()).thenReturn(getCacheIterator_no_match());
        int actual = highRiskIndustryCodeCacheHandler.getHighRiskIndustryCode("XYZ");
        assertEquals(0, actual);
    }

    @Test
    public void testGetHighRiskIndustryCode_with_blank_Address_Type_Name() {
        when(highRiskIndustryCodeCache.iterator()).thenReturn(getCacheIterator());
        int actual = highRiskIndustryCodeCacheHandler.getHighRiskIndustryCode("");
        assertEquals(0, actual);
    }

    private Iterator<Entry<Integer, String>> getCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 1;
                    }

                    @Override
                    public String getValue() {
                        return "Money Order Issuance Services";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getEmptyCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            @Override
            public Entry<Integer, String> next() {
                return null;
            }

            @Override
            public boolean hasNext() {
                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getCacheIterator_no_match() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 2;
                    }

                    @Override
                    public String getValue() {
                        return "Money Order Issuance Services";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
