package com.capitalone.api.nsb.business.identity.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.capitalone.api.nsb.business.identity.domain.cache.OwnershipStructType;
import com.capitalone.api.nsb.business.identity.service.CacheService;

@RunWith(MockitoJUnitRunner.class)
public class OwnershipStructTypeCacheHandlerTest {

    private OwnershipStructTypeCacheHandler ownershipStructTypeCacheHandler;

    @Mock
    private Cache<Integer, String> ownershipStructTypeCache;

    @Mock
    private CacheService cacheService;

    @Mock
    private BusinessIdentityCacheManager cacheManager;

    @Before
    public void setUp() throws Exception {

        ownershipStructTypeCacheHandler = new OwnershipStructTypeCacheHandler();

        ReflectionTestUtils.setField(ownershipStructTypeCacheHandler, "ownershipStructTypeCache", ownershipStructTypeCache);
        ReflectionTestUtils.setField(ownershipStructTypeCacheHandler, "cacheService", cacheService);
        ReflectionTestUtils.setField(ownershipStructTypeCacheHandler, "cacheManager", cacheManager);
    }

    @Test
    public void testGetOwnershipStructTypeDesc() {
        int ownershipStructTypeId = 1;
        when(ownershipStructTypeCache.iterator()).thenReturn(getCacheIterator());
        when(ownershipStructTypeCache.get(ownershipStructTypeId)).thenReturn("Government Owned");
        String actual = ownershipStructTypeCacheHandler.getOwnershipStructTypeDesc(ownershipStructTypeId);
        assertEquals("Government Owned", actual);
    }

    @Test
    public void testGetOwnershipStructTypeDesc_refresh() {
        int ownershipStructTypeId = 1;

        List<OwnershipStructType> ownershipStructList = new ArrayList<OwnershipStructType>();
        ownershipStructList.add(new OwnershipStructType());
        ownershipStructList.add(null);
        when(cacheService.getOwnershipStructTypes()).thenReturn(ownershipStructList);

        when(ownershipStructTypeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(ownershipStructTypeCache.get(ownershipStructTypeId)).thenReturn("Government Owned");
        String actual = ownershipStructTypeCacheHandler.getOwnershipStructTypeDesc(ownershipStructTypeId);
        assertEquals("Government Owned", actual);
    }

    @Test
    public void testGetOwnershipStructTypeDesc_initialize() {

        ReflectionTestUtils.setField(ownershipStructTypeCacheHandler, "ownershipStructTypeCache", null);

        int ownershipStructTypeId = 1;

        when(cacheManager.initializeCache("ownershipStructTypeCache", Integer.class, String.class)).thenReturn(ownershipStructTypeCache);
        when(ownershipStructTypeCache.get(ownershipStructTypeId)).thenReturn("Government Owned");
        String actual = ownershipStructTypeCacheHandler.getOwnershipStructTypeDesc(ownershipStructTypeId);
        assertEquals("Government Owned", actual);
    }

    @Test
    public void testGetOwnershipStructTypeDesc_with_empty_map() {

        int ownershipStructTypeId = 1;

        when(ownershipStructTypeCache.iterator()).thenReturn(getCacheIterator());
        when(ownershipStructTypeCache.get(ownershipStructTypeId)).thenReturn("Government Owned");

        List<OwnershipStructType> ownershipStructTypeList = new ArrayList<OwnershipStructType>();
        when(cacheService.getOwnershipStructTypes()).thenReturn(ownershipStructTypeList);
        String actual = ownershipStructTypeCacheHandler.getOwnershipStructTypeDesc(1);
        assertEquals("Government Owned", actual);
    }

    @Test
    public void testGetOwnershipStructTypeDesc_cache_not_initialized() {
        int ownershipStructTypeId = 1;

        when(ownershipStructTypeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(ownershipStructTypeCache.get(ownershipStructTypeId)).thenReturn("Government Owned");
        String actual = ownershipStructTypeCacheHandler.getOwnershipStructTypeDesc(ownershipStructTypeId);
        assertEquals("Government Owned", actual);
    }

    @Test
    public void testGetOwnershipStructTypeId() {

        when(ownershipStructTypeCache.iterator()).thenReturn(getCacheIterator());

        int actual = ownershipStructTypeCacheHandler.getOwnershipStructTypeId("Government Owned");
        assertEquals(1, actual);
    }

    @Test
    public void testGetOwnershipStructTypeId_refresh() {

        when(ownershipStructTypeCache.iterator()).thenReturn(getEmptyCacheIterator());

        int actual = ownershipStructTypeCacheHandler.getOwnershipStructTypeId("Government Owned");
        assertEquals(0, actual);
    }

    @Test
    public void testGetOwnershipStructTypeId_no_match() {

        when(ownershipStructTypeCache.iterator()).thenReturn(getCacheIterator_no_match());

        int actual = ownershipStructTypeCacheHandler.getOwnershipStructTypeId("XYZ");
        assertNotEquals(1, actual);
    }

    @Test
    public void testGetOwnershipStructTypeId_with_no_match() {
        when(ownershipStructTypeCache.iterator()).thenReturn(getCacheIterator_no_match());
        int actual = ownershipStructTypeCacheHandler.getOwnershipStructTypeId("XYZ");
        assertEquals(0, actual);
    }

    @Test
    public void testGetOwnershipStructTypeId_with_blank_ownershipStruct_Type_Desc() {
        when(ownershipStructTypeCache.iterator()).thenReturn(getCacheIterator());
        int actual = ownershipStructTypeCacheHandler.getOwnershipStructTypeId("");
        assertEquals(0, actual);
    }

    private Iterator<Entry<Integer, String>> getCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 1;
                    }

                    @Override
                    public String getValue() {
                        return "Government Owned";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getEmptyCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            @Override
            public Entry<Integer, String> next() {
                return null;
            }

            @Override
            public boolean hasNext() {
                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getCacheIterator_no_match() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 2;
                    }

                    @Override
                    public String getValue() {
                        return "Government Owned";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
