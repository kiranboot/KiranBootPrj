package com.capitalone.api.nsb.business.identity.validator;

import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyString;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capitalone.api.nsb.business.identity.cso.CreateBusinessDetailsRequest;
import com.capitalone.api.nsb.business.identity.cso.PhoneCSO;
import com.capitalone.api.nsb.business.identity.exception.RequestValidationException;

public class RequestValidatorTest {

    @Mock
    private PhoneValidator phoneValidator;

    @InjectMocks
    RequestValidator validator;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);

    }

    @Test(expected = RequestValidationException.class)
    public void testValidateCreateBusinessDetailsRequest() {
        CreateBusinessDetailsRequest createBusinessDetailsRequest = new CreateBusinessDetailsRequest();
        List<PhoneCSO> phoneNumbersList = new ArrayList<PhoneCSO>();
        PhoneCSO ph = new PhoneCSO();
        ph.setCountryCode("1");
        ph.setTelephoneNumber("3027845634");
        phoneNumbersList.add(ph);
        Mockito.when(phoneValidator.isValid(anyString())).thenReturn(anyBoolean());
        createBusinessDetailsRequest.setPhoneNumbers(phoneNumbersList);
        validator.validateCreateBusinessDetailsRequest(createBusinessDetailsRequest);
    }

}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
