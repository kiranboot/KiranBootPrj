package com.capitalone.api.nsb.business.identity.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.capitalone.api.nsb.business.identity.domain.cache.TaxIdType;
import com.capitalone.api.nsb.business.identity.service.CacheService;

@RunWith(MockitoJUnitRunner.class)
public class TaxIdTypeCacheHandlerTest {

    private TaxIdTypeCacheHandler taxIdTypeCacheHandler;

    @Mock
    private Cache<Integer, String> taxIdTypeCache;

    @Mock
    private CacheService cacheService;

    @Mock
    private BusinessIdentityCacheManager cacheManager;

    @Before
    public void setUp() throws Exception {
        taxIdTypeCacheHandler = new TaxIdTypeCacheHandler();
        ReflectionTestUtils.setField(taxIdTypeCacheHandler, "taxIdTypeCache", taxIdTypeCache);
        ReflectionTestUtils.setField(taxIdTypeCacheHandler, "cacheService", cacheService);
        ReflectionTestUtils.setField(taxIdTypeCacheHandler, "cacheManager", cacheManager);
    }

    @Test
    public void testGetTaxIdTypeShortDesc() {
        int taxIdTypeId = 1;
        when(taxIdTypeCache.iterator()).thenReturn(getCacheIterator());
        when(taxIdTypeCache.get(taxIdTypeId)).thenReturn("SSN");
        String actual = taxIdTypeCacheHandler.getTaxIdTypeShortDesc(taxIdTypeId);
        assertEquals("SSN", actual);
    }

    @Test
    public void testGetTaxIdTypeShortDesc_refresh() {
        int taxIdTypeId = 1;

        List<TaxIdType> taxIdList = new ArrayList<TaxIdType>();
        taxIdList.add(new TaxIdType());
        taxIdList.add(null);
        when(cacheService.getTaxIdTypes()).thenReturn(taxIdList);

        when(taxIdTypeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(taxIdTypeCache.get(taxIdTypeId)).thenReturn("SSN");
        String actual = taxIdTypeCacheHandler.getTaxIdTypeShortDesc(taxIdTypeId);
        assertEquals("SSN", actual);
    }

    @Test
    public void testGetTaxIdTypeShortDesc_initialize() {

        ReflectionTestUtils.setField(taxIdTypeCacheHandler, "taxIdTypeCache", null);

        int taxIdTypeId = 1;

        when(cacheManager.initializeCache("taxIdTypeCache", Integer.class, String.class)).thenReturn(taxIdTypeCache);
        when(taxIdTypeCache.get(taxIdTypeId)).thenReturn("SSN");
        String actual = taxIdTypeCacheHandler.getTaxIdTypeShortDesc(taxIdTypeId);
        assertEquals("SSN", actual);
    }

    @Test
    public void testGetTaxIdTypeShortDesc_with_empty_map() {

        int taxIdTypeId = 1;

        when(taxIdTypeCache.iterator()).thenReturn(getCacheIterator());
        when(taxIdTypeCache.get(taxIdTypeId)).thenReturn("SSN");

        List<TaxIdType> taxIdTypeList = new ArrayList<TaxIdType>();
        when(cacheService.getTaxIdTypes()).thenReturn(taxIdTypeList);
        String actual = taxIdTypeCacheHandler.getTaxIdTypeShortDesc(1);
        assertEquals("SSN", actual);
    }

    @Test
    public void testGetTaxIdTypeShortDesc_cache_not_initialized() {
        int taxIdTypeId = 1;

        when(taxIdTypeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(taxIdTypeCache.get(taxIdTypeId)).thenReturn("SSN");
        String actual = taxIdTypeCacheHandler.getTaxIdTypeShortDesc(taxIdTypeId);
        assertEquals("SSN", actual);
    }

    @Test
    public void testGetTaxIdTypeId() {

        when(taxIdTypeCache.iterator()).thenReturn(getCacheIterator());

        int actual = taxIdTypeCacheHandler.getTaxIdTypeId("SSN");
        assertEquals(1, actual);
    }

    @Test
    public void testGetTaxIdTypeId_refresh() {

        when(taxIdTypeCache.iterator()).thenReturn(getEmptyCacheIterator());

        int actual = taxIdTypeCacheHandler.getTaxIdTypeId("SSN");
        assertEquals(0, actual);
    }

    @Test
    public void testGetTaxIdTypeId_no_match() {

        when(taxIdTypeCache.iterator()).thenReturn(getCacheIterator_no_match());

        int actual = taxIdTypeCacheHandler.getTaxIdTypeId("XYZ");
        assertNotEquals(1, actual);
    }

    @Test
    public void testGetTaxIdTypeId_with_no_match() {
        when(taxIdTypeCache.iterator()).thenReturn(getCacheIterator_no_match());
        int actual = taxIdTypeCacheHandler.getTaxIdTypeId("XYZ");
        assertEquals(0, actual);
    }

    @Test
    public void testGetTaxIdTypeId_with_blank_taxId_Type_ShortDesc() {
        when(taxIdTypeCache.iterator()).thenReturn(getCacheIterator());
        int actual = taxIdTypeCacheHandler.getTaxIdTypeId("");
        assertEquals(0, actual);
    }

    private Iterator<Entry<Integer, String>> getCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 1;
                    }

                    @Override
                    public String getValue() {
                        return "SSN";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getEmptyCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            @Override
            public Entry<Integer, String> next() {
                return null;
            }

            @Override
            public boolean hasNext() {
                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getCacheIterator_no_match() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 2;
                    }

                    @Override
                    public String getValue() {
                        return "SSN";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
