package com.capitalone.api.nsb.business.identity.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.capitalone.api.nsb.business.identity.domain.cache.AddressType;
import com.capitalone.api.nsb.business.identity.service.CacheService;

@RunWith(MockitoJUnitRunner.class)
public class AddressTypeCacheHandlerTest {

    private AddressTypeCacheHandler addressTypeCacheHandler;

    @Mock
    private Cache<Integer, String> addressTypeCache;

    @Mock
    private CacheService cacheService;

    @Mock
    private BusinessIdentityCacheManager cacheManager;

    @Before
    public void setUp() throws Exception {
        addressTypeCacheHandler = new AddressTypeCacheHandler();
        ReflectionTestUtils.setField(addressTypeCacheHandler, "addressTypeCache", addressTypeCache);
        ReflectionTestUtils.setField(addressTypeCacheHandler, "cacheService", cacheService);
        ReflectionTestUtils.setField(addressTypeCacheHandler, "cacheManager", cacheManager);
    }

    @Test
    public void testGetAddressTypeName() {
        int addressTypeId = 1;
        when(addressTypeCache.iterator()).thenReturn(getCacheIterator());
        when(addressTypeCache.get(addressTypeId)).thenReturn("Work");
        String actual = addressTypeCacheHandler.getAddressTypeName(addressTypeId);
        assertEquals("Work", actual);
    }

    @Test
    public void testGetAddressTypeName_refresh() {
        int addressTypeId = 1;

        List<AddressType> addressList = new ArrayList<AddressType>();
        addressList.add(new AddressType());
        addressList.add(null);
        when(cacheService.getAddressTypes()).thenReturn(addressList);

        when(addressTypeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(addressTypeCache.get(addressTypeId)).thenReturn("Work");
        String actual = addressTypeCacheHandler.getAddressTypeName(addressTypeId);
        assertEquals("Work", actual);
    }

    @Test
    public void testGetAddressTypeName_initialize() {

        ReflectionTestUtils.setField(addressTypeCacheHandler, "addressTypeCache", null);

        int addressTypeId = 1;

        when(cacheManager.initializeCache("addressTypeCache", Integer.class, String.class)).thenReturn(addressTypeCache);
        when(addressTypeCache.get(addressTypeId)).thenReturn("Work");
        String actual = addressTypeCacheHandler.getAddressTypeName(addressTypeId);
        assertEquals("Work", actual);
    }

    @Test
    public void testGetAddressTypeName_with_empty_map() {

        int addressTypeId = 1;

        when(addressTypeCache.iterator()).thenReturn(getCacheIterator());
        when(addressTypeCache.get(addressTypeId)).thenReturn("Work");

        List<AddressType> addressTypeList = new ArrayList<AddressType>();
        when(cacheService.getAddressTypes()).thenReturn(addressTypeList);
        String actual = addressTypeCacheHandler.getAddressTypeName(1);
        assertEquals("Work", actual);
    }

    @Test
    public void testGetAddressTypeName_cache_not_initialized() {
        int addressTypeId = 1;

        when(addressTypeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(addressTypeCache.get(addressTypeId)).thenReturn("Work");
        String actual = addressTypeCacheHandler.getAddressTypeName(addressTypeId);
        assertEquals("Work", actual);
    }

    @Test
    public void testGetAddressTypeId() {

        when(addressTypeCache.iterator()).thenReturn(getCacheIterator());

        int actual = addressTypeCacheHandler.getAddressTypeId("Work");
        assertEquals(1, actual);
    }

    @Test
    public void testGetAddressTypeId_refresh() {

        when(addressTypeCache.iterator()).thenReturn(getEmptyCacheIterator());

        int actual = addressTypeCacheHandler.getAddressTypeId("Work");
        assertEquals(0, actual);
    }

    @Test
    public void testGetAddressTypeId_no_match() {

        when(addressTypeCache.iterator()).thenReturn(getCacheIterator_no_match());

        int actual = addressTypeCacheHandler.getAddressTypeId("XYZ");
        assertNotEquals(1, actual);
    }

    @Test
    public void testGetAddressTypeId_with_no_match() {
        when(addressTypeCache.iterator()).thenReturn(getCacheIterator_no_match());
        int actual = addressTypeCacheHandler.getAddressTypeId("XYZ");
        assertEquals(0, actual);
    }

    @Test
    public void testGetAddressTypeId_with_blank_Address_Type_Name() {
        when(addressTypeCache.iterator()).thenReturn(getCacheIterator());
        int actual = addressTypeCacheHandler.getAddressTypeId("");
        assertEquals(0, actual);
    }

    private Iterator<Entry<Integer, String>> getCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 1;
                    }

                    @Override
                    public String getValue() {
                        return "Work";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getEmptyCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            @Override
            public Entry<Integer, String> next() {
                return null;
            }

            @Override
            public boolean hasNext() {
                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getCacheIterator_no_match() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 2;
                    }

                    @Override
                    public String getValue() {
                        return "Work";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
