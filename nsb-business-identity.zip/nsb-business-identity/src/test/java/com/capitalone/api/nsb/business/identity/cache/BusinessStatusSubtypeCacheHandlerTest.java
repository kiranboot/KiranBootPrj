package com.capitalone.api.nsb.business.identity.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.capitalone.api.nsb.business.identity.domain.cache.BusinessStatusSubtype;
import com.capitalone.api.nsb.business.identity.service.CacheService;

@RunWith(MockitoJUnitRunner.class)
public class BusinessStatusSubtypeCacheHandlerTest {

    private BusinessStatusSubtypeCacheHandler businessStatusSubtypeCacheHandler;

    @Mock
    private Cache<Integer, String> businessStatusSubtypeCache;

    @Mock
    private CacheService cacheService;

    @Mock
    private BusinessIdentityCacheManager cacheManager;

    @Before
    public void setUp() throws Exception {
        businessStatusSubtypeCacheHandler = new BusinessStatusSubtypeCacheHandler();
        ReflectionTestUtils.setField(businessStatusSubtypeCacheHandler, "businessStatusSubtypeCache", businessStatusSubtypeCache);
        ReflectionTestUtils.setField(businessStatusSubtypeCacheHandler, "cacheService", cacheService);
        ReflectionTestUtils.setField(businessStatusSubtypeCacheHandler, "cacheManager", cacheManager);
    }

    @Test
    public void testGetBusinessStatusSubtypeDesc() {
        int businessStatusSubtypeCode = 1;
        when(businessStatusSubtypeCache.iterator()).thenReturn(getCacheIterator());
        when(businessStatusSubtypeCache.get(businessStatusSubtypeCode)).thenReturn("ID_THEFT");
        String actual = businessStatusSubtypeCacheHandler.getBusinessStatusSubtypeDesc(businessStatusSubtypeCode);
        assertEquals("ID_THEFT", actual);
    }

    @Test
    public void testGetBusinessStatusSubtypeDesc_refresh() {
        int businessStatusSubtypeCode = 1;

        List<BusinessStatusSubtype> businessStatusSubtypeList = new ArrayList<BusinessStatusSubtype>();
        businessStatusSubtypeList.add(new BusinessStatusSubtype());
        businessStatusSubtypeList.add(null);
        when(cacheService.getBusinessStatusSubtypes()).thenReturn(businessStatusSubtypeList);

        when(businessStatusSubtypeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(businessStatusSubtypeCache.get(businessStatusSubtypeCode)).thenReturn("ID_THEFT");
        String actual = businessStatusSubtypeCacheHandler.getBusinessStatusSubtypeDesc(businessStatusSubtypeCode);
        assertEquals("ID_THEFT", actual);
    }

    @Test
    public void testGetBusinessStatusSubtypeDesc_initialize() {

        ReflectionTestUtils.setField(businessStatusSubtypeCacheHandler, "businessStatusSubtypeCache", null);

        int businessStatusSubtypeCode = 1;

        when(cacheManager.initializeCache("businessStatusSubtypeCache", Integer.class, String.class)).thenReturn(businessStatusSubtypeCache);
        when(businessStatusSubtypeCache.get(businessStatusSubtypeCode)).thenReturn("ID_THEFT");
        String actual = businessStatusSubtypeCacheHandler.getBusinessStatusSubtypeDesc(businessStatusSubtypeCode);
        assertEquals("ID_THEFT", actual);
    }

    @Test
    public void testGetBusinessStatusSubtypeDesc_with_empty_map() {

        int businessStatusSubtypeCode = 1;

        when(businessStatusSubtypeCache.iterator()).thenReturn(getCacheIterator());
        when(businessStatusSubtypeCache.get(businessStatusSubtypeCode)).thenReturn("ID_THEFT");

        List<BusinessStatusSubtype> businessStatusSubtype = new ArrayList<BusinessStatusSubtype>();
        when(cacheService.getBusinessStatusSubtypes()).thenReturn(businessStatusSubtype);
        String actual = businessStatusSubtypeCacheHandler.getBusinessStatusSubtypeDesc(1);
        assertEquals("ID_THEFT", actual);
    }

    @Test
    public void testgGetBusinessStatusSubtypeDesc_cache_not_initialized() {
        int businessStatusSubtypeCode = 1;

        when(businessStatusSubtypeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(businessStatusSubtypeCache.get(businessStatusSubtypeCode)).thenReturn("ID_THEFT");
        String actual = businessStatusSubtypeCacheHandler.getBusinessStatusSubtypeDesc(businessStatusSubtypeCode);
        assertEquals("ID_THEFT", actual);
    }

    @Test
    public void testGetBusinessStatusSubtypeCode() {

        when(businessStatusSubtypeCache.iterator()).thenReturn(getCacheIterator());

        int actual = businessStatusSubtypeCacheHandler.getBusinessStatusSubtypeCode("ID_THEFT");
        assertEquals(1, actual);
    }

    @Test
    public void testGetBusinessStatusSubtypeCode_refresh() {

        when(businessStatusSubtypeCache.iterator()).thenReturn(getEmptyCacheIterator());

        int actual = businessStatusSubtypeCacheHandler.getBusinessStatusSubtypeCode("ID_THEFT");
        assertEquals(0, actual);
    }

    @Test
    public void testGetBusinessStatusSubtypeCode_no_match() {

        when(businessStatusSubtypeCache.iterator()).thenReturn(getCacheIterator_no_match());

        int actual = businessStatusSubtypeCacheHandler.getBusinessStatusSubtypeCode("XYZ");
        assertNotEquals(1, actual);
    }

    @Test
    public void testGetBusinessStatusSubtypeCode_with_no_match() {
        when(businessStatusSubtypeCache.iterator()).thenReturn(getCacheIterator_no_match());
        int actual = businessStatusSubtypeCacheHandler.getBusinessStatusSubtypeCode("XYZ");
        assertEquals(0, actual);
    }

    @Test
    public void testGetBusinessStatusSubtypeCode_with_blank_Address_Type_Name() {
        when(businessStatusSubtypeCache.iterator()).thenReturn(getCacheIterator());
        int actual = businessStatusSubtypeCacheHandler.getBusinessStatusSubtypeCode("");
        assertEquals(0, actual);
    }

    private Iterator<Entry<Integer, String>> getCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 1;
                    }

                    @Override
                    public String getValue() {
                        return "ID_THEFT";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getEmptyCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            @Override
            public Entry<Integer, String> next() {
                return null;
            }

            @Override
            public boolean hasNext() {
                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getCacheIterator_no_match() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 2;
                    }

                    @Override
                    public String getValue() {
                        return "ID_THEFT";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
