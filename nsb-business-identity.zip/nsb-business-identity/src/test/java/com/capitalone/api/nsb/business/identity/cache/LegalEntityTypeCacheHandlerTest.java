package com.capitalone.api.nsb.business.identity.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.capitalone.api.nsb.business.identity.domain.cache.LegalEntityType;
import com.capitalone.api.nsb.business.identity.service.CacheService;

@RunWith(MockitoJUnitRunner.class)
public class LegalEntityTypeCacheHandlerTest {

    private LegalEntityTypeCacheHandler legalEntityTypeCacheHandler;

    @Mock
    private Cache<Integer, String> legalEntityTypeCache;

    @Mock
    private CacheService cacheService;

    @Mock
    private BusinessIdentityCacheManager cacheManager;

    @Before
    public void setUp() throws Exception {

        legalEntityTypeCacheHandler = new LegalEntityTypeCacheHandler();

        ReflectionTestUtils.setField(legalEntityTypeCacheHandler, "legalEntityTypeCache", legalEntityTypeCache);
        ReflectionTestUtils.setField(legalEntityTypeCacheHandler, "cacheService", cacheService);
        ReflectionTestUtils.setField(legalEntityTypeCacheHandler, "cacheManager", cacheManager);
    }

    @Test
    public void testGetLegalEntityTypeDesc() {
        int legalEntityTypeId = 1;
        when(legalEntityTypeCache.iterator()).thenReturn(getCacheIterator());
        when(legalEntityTypeCache.get(legalEntityTypeId)).thenReturn("Non-Profit");
        String actual = legalEntityTypeCacheHandler.getLegalEntityTypeDesc(legalEntityTypeId);
        assertEquals("Non-Profit", actual);
    }

    @Test
    public void testGetLegalEntityTypeDesc_refresh() {
        int legalEntityTypeId = 1;

        List<LegalEntityType> legalEntityList = new ArrayList<LegalEntityType>();
        legalEntityList.add(new LegalEntityType());
        legalEntityList.add(null);
        when(cacheService.getLegalEntityTypes()).thenReturn(legalEntityList);

        when(legalEntityTypeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(legalEntityTypeCache.get(legalEntityTypeId)).thenReturn("Non-Profit");
        String actual = legalEntityTypeCacheHandler.getLegalEntityTypeDesc(legalEntityTypeId);
        assertEquals("Non-Profit", actual);
    }

    @Test
    public void testGetLegalEntityTypeDesc_initialize() {

        ReflectionTestUtils.setField(legalEntityTypeCacheHandler, "legalEntityTypeCache", null);

        int legalEntityTypeId = 1;

        when(cacheManager.initializeCache("legalEntityTypeCache", Integer.class, String.class)).thenReturn(legalEntityTypeCache);
        when(legalEntityTypeCache.get(legalEntityTypeId)).thenReturn("Non-Profit");
        String actual = legalEntityTypeCacheHandler.getLegalEntityTypeDesc(legalEntityTypeId);
        assertEquals("Non-Profit", actual);
    }

    @Test
    public void testGetLegalEntityTypeDesc_with_empty_map() {

        int legalEntityTypeId = 1;

        when(legalEntityTypeCache.iterator()).thenReturn(getCacheIterator());
        when(legalEntityTypeCache.get(legalEntityTypeId)).thenReturn("Non-Profit");

        List<LegalEntityType> legalEntityTypeList = new ArrayList<LegalEntityType>();
        when(cacheService.getLegalEntityTypes()).thenReturn(legalEntityTypeList);
        String actual = legalEntityTypeCacheHandler.getLegalEntityTypeDesc(1);
        assertEquals("Non-Profit", actual);
    }

    @Test
    public void testGetLegalEntityTypeDesc_cache_not_initialized() {
        int legalEntityTypeId = 1;

        when(legalEntityTypeCache.iterator()).thenReturn(getEmptyCacheIterator());
        when(legalEntityTypeCache.get(legalEntityTypeId)).thenReturn("Non-Profit");
        String actual = legalEntityTypeCacheHandler.getLegalEntityTypeDesc(legalEntityTypeId);
        assertEquals("Non-Profit", actual);
    }

    @Test
    public void testGetLegalEntityTypeId() {

        when(legalEntityTypeCache.iterator()).thenReturn(getCacheIterator());

        int actual = legalEntityTypeCacheHandler.getLegalEntityTypeId("Non-Profit");
        assertEquals(1, actual);
    }

    @Test
    public void testGetLegalEntityTypeId_refresh() {

        when(legalEntityTypeCache.iterator()).thenReturn(getEmptyCacheIterator());

        int actual = legalEntityTypeCacheHandler.getLegalEntityTypeId("Non-Profit");
        assertEquals(0, actual);
    }

    @Test
    public void testGetLegalEntityTypeId_no_match() {

        when(legalEntityTypeCache.iterator()).thenReturn(getCacheIterator_no_match());

        int actual = legalEntityTypeCacheHandler.getLegalEntityTypeId("XYZ");
        assertNotEquals(1, actual);
    }

    @Test
    public void testGetLegalEntityTypeId_with_no_match() {
        when(legalEntityTypeCache.iterator()).thenReturn(getCacheIterator_no_match());
        int actual = legalEntityTypeCacheHandler.getLegalEntityTypeId("XYZ");
        assertEquals(0, actual);
    }

    @Test
    public void testGetLegalEntityTypeId_with_blank_legalEntity_Type_Desc() {
        when(legalEntityTypeCache.iterator()).thenReturn(getCacheIterator());
        int actual = legalEntityTypeCacheHandler.getLegalEntityTypeId("");
        assertEquals(0, actual);
    }

    private Iterator<Entry<Integer, String>> getCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 1;
                    }

                    @Override
                    public String getValue() {
                        return "Non-Profit";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getEmptyCacheIterator() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            @Override
            public Entry<Integer, String> next() {
                return null;
            }

            @Override
            public boolean hasNext() {
                return false;
            }
        };
    }

    private Iterator<Entry<Integer, String>> getCacheIterator_no_match() {
        return new Iterator<Cache.Entry<Integer, String>>() {

            int numOfEntries = 2;

            @Override
            public Entry<Integer, String> next() {
                return new Entry<Integer, String>() {

                    @Override
                    public Integer getKey() {
                        return 2;
                    }

                    @Override
                    public String getValue() {
                        return "Non-Profit";
                    }
                };
            }

            @Override
            public boolean hasNext() {

                if (0 != numOfEntries) {
                    numOfEntries--;
                    return true;
                }

                return false;
            }
        };
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
