package com.capitalone.api.nsb.business.identity.repository;

import java.math.BigInteger;

import org.springframework.data.repository.CrudRepository;

import com.capitalone.api.nsb.business.identity.domain.BusinessAddress;

public interface BusinessAddressRepository extends CrudRepository<BusinessAddress, BigInteger> {

}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
