package com.capitalone.api.nsb.business.identity.exception;

public class BusinessServiceException extends RuntimeException {

    private static final long serialVersionUID = -1951631924246427897L;

    private int errorCode;

    public BusinessServiceException(ServiceErrorCode serviceErrorCode, String message, Throwable originalException) {

        super(message, originalException);

        this.errorCode = serviceErrorCode.getReferenceNumber();
    }

    public int getErrorCode() {
        return errorCode;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
