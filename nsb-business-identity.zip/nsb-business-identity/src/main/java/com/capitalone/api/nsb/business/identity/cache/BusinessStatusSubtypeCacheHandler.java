package com.capitalone.api.nsb.business.identity.cache;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capitalone.api.nsb.business.identity.domain.cache.BusinessStatusSubtype;
import com.capitalone.api.nsb.business.identity.service.CacheService;
import com.capitalone.api.nsb.business.identity.util.Util;

@Component
public class BusinessStatusSubtypeCacheHandler {

    private Cache<Integer, String> businessStatusSubtypeCache;

    @Autowired
    private BusinessIdentityCacheManager cacheManager;

    @Autowired
    private CacheService cacheService;

    private void initializeCache() {
        businessStatusSubtypeCache = cacheManager.initializeCache("businessStatusSubtypeCache", Integer.class, String.class);
    }

    private void refreshCache() {

        if (null == businessStatusSubtypeCache) {
            initializeCache();
        }

        businessStatusSubtypeCache.clear();

        List<BusinessStatusSubtype> businessStatusSubtypeList = cacheService.getBusinessStatusSubtypes();

        businessStatusSubtypeList.forEach(businessStatusSubtype -> {
            if (null != businessStatusSubtype) {
                businessStatusSubtypeCache.put(businessStatusSubtype.getStatusSubtypeCode(), businessStatusSubtype.getDescription());
            }
        });
    }

    public String getBusinessStatusSubtypeDesc(int businessStatusSubtypeCode) {

        if (!Util.isCacheLoaded(businessStatusSubtypeCache)) {
            refreshCache();
        }

        return businessStatusSubtypeCache.get(businessStatusSubtypeCode);
    }

    public int getBusinessStatusSubtypeCode(String businessStatusSubtypeDesc) {

        int businessStatusSubtypeCode = 0;

        if (StringUtils.isNotBlank(businessStatusSubtypeDesc)) {

            if (!Util.isCacheLoaded(businessStatusSubtypeCache)) {
                refreshCache();
            }

            for (Entry<Integer, String> businessStatusSubtype : businessStatusSubtypeCache) {

                if (businessStatusSubtypeDesc.equalsIgnoreCase(businessStatusSubtype.getValue())) {

                    businessStatusSubtypeCode = businessStatusSubtype.getKey();
                    break;
                }
            }
        }

        if (0 != businessStatusSubtypeCode) {
            return businessStatusSubtypeCode;
        }
        else {
            // TODO: Do NOT return anything. Throw exception here.
            return 0;
        }
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
