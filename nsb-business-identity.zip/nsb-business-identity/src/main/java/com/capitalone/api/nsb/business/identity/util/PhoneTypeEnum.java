package com.capitalone.api.nsb.business.identity.util;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

public enum PhoneTypeEnum {

    Work("Work");

    private static final Map<String, String> PHONETYPE = new HashMap<String, String>();

    static {
        for (PhoneTypeEnum phoneType : EnumSet.allOf(PhoneTypeEnum.class)) {
            PHONETYPE.put(StringUtils.upperCase(phoneType.name()), phoneType.getPhoneTypeStr());
        }
    }

    private String phoneTypeStr;

    private PhoneTypeEnum(String phoneTypeStr) {
        this.phoneTypeStr = phoneTypeStr;
    }

    public String getPhoneTypeStr() {
        return phoneTypeStr;
    }

    public static String get(String phoneTypeStr) {
        return PHONETYPE.get(phoneTypeStr.toUpperCase());
    }

    public static String fromString(String value) {
        for (Entry<String, String> entry : PHONETYPE.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(value)) {
                return entry.getKey();
            }
        }
        return null;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
