package com.capitalone.api.nsb.business.identity.cache;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capitalone.api.nsb.business.identity.domain.cache.PhoneType;
import com.capitalone.api.nsb.business.identity.service.CacheService;
import com.capitalone.api.nsb.business.identity.util.Util;

@Component
public class PhoneTypeCacheHandler {

    private Cache<Integer, String> phoneTypeCache;

    @Autowired
    private BusinessIdentityCacheManager cacheManager;

    @Autowired
    private CacheService cacheService;

    private void initializeCache() {
        phoneTypeCache = cacheManager.initializeCache("phoneTypeCache", Integer.class, String.class);
    }

    private void refreshCache() {

        if (null == phoneTypeCache) {
            initializeCache();
        }

        phoneTypeCache.clear();

        List<PhoneType> phoneTypeList = cacheService.getPhoneTypes();

        phoneTypeList.forEach(phoneType -> {
            if (null != phoneType) {
                phoneTypeCache.put(phoneType.getPhoneTypeId(), phoneType.getName());
            }
        });
    }

    public String getPhoneTypeName(int phoneTypeId) {

        if (!Util.isCacheLoaded(phoneTypeCache)) {
            refreshCache();
        }

        return phoneTypeCache.get(phoneTypeId);
    }

    public int getPhoneTypeId(String phoneTypeName) {

        int phoneTypeId = 0;

        if (StringUtils.isNotBlank(phoneTypeName)) {

            if (!Util.isCacheLoaded(phoneTypeCache)) {
                refreshCache();
            }

            for (Entry<Integer, String> phoneType : phoneTypeCache) {

                if (phoneTypeName.equalsIgnoreCase(phoneType.getValue())) {

                    phoneTypeId = phoneType.getKey();
                    break;
                }
            }
        }

        if (0 != phoneTypeId) {
            return phoneTypeId;
        }
        else {
            // TODO: Do NOT return anything. Throw exception here.
            return 0;
        }
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
