package com.capitalone.api.nsb.business.identity.domain.cache;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "business.legal_entity_type")
public class LegalEntityType {

    @Id
    @Column(name = "legal_entity_type_id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer legalEntityTypeId;

    @Column(name = "legal_entity_type_description")
    private String legalEntityTypeDescription;

    public Integer getLegalEntityTypeId() {
        return legalEntityTypeId;
    }

    public void setLegalEntityTypeId(Integer legalEntityTypeId) {
        this.legalEntityTypeId = legalEntityTypeId;
    }

    public String getLegalEntityTypeDescription() {
        return legalEntityTypeDescription;
    }

    public void setLegalEntityTypeDescription(String legalEntityTypeDescription) {
        this.legalEntityTypeDescription = legalEntityTypeDescription;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
