package com.capitalone.api.nsb.business.identity.cache;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capitalone.api.nsb.business.identity.domain.cache.BusinessStatus;
import com.capitalone.api.nsb.business.identity.service.CacheService;
import com.capitalone.api.nsb.business.identity.util.Util;

@Component
public class BusinessStatusCacheHandler {

    private Cache<Integer, String> businessStatusCache;

    @Autowired
    private BusinessIdentityCacheManager cacheManager;

    @Autowired
    private CacheService cacheService;

    private void initializeCache() {
        businessStatusCache = cacheManager.initializeCache("businessStatusCache", Integer.class, String.class);
    }

    private void refreshCache() {

        if (null == businessStatusCache) {
            initializeCache();
        }

        businessStatusCache.clear();

        List<BusinessStatus> businessStatusList = cacheService.getBusinessStatuses();

        businessStatusList.forEach(businessStatus -> {
            if (null != businessStatus) {
                businessStatusCache.put(businessStatus.getStatusCode(), businessStatus.getDescription());
            }
        });
    }

    public String getBusinessStatusDesc(int businessStatusCode) {

        if (!Util.isCacheLoaded(businessStatusCache)) {
            refreshCache();
        }

        return businessStatusCache.get(businessStatusCode);
    }

    public int getBusinessStatusCode(String businessStatusDesc) {

        int businessStatusCode = 0;

        if (StringUtils.isNotBlank(businessStatusDesc)) {

            if (!Util.isCacheLoaded(businessStatusCache)) {
                refreshCache();
            }

            for (Entry<Integer, String> businessStatus : businessStatusCache) {

                if (businessStatusDesc.equalsIgnoreCase(businessStatus.getValue())) {

                    businessStatusCode = businessStatus.getKey();
                    break;
                }
            }
        }

        if (0 != businessStatusCode) {
            return businessStatusCode;
        }
        else {
            // TODO: Do NOT return anything. Throw exception here.
            return 0;
        }
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
