package com.capitalone.api.nsb.business.identity.cache;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capitalone.api.nsb.business.identity.domain.cache.TrustAssetSource;
import com.capitalone.api.nsb.business.identity.service.CacheService;
import com.capitalone.api.nsb.business.identity.util.Util;

@Component
public class TrustAssetSourceCacheHandler {

    private Cache<Integer, String> trustAssetSourceCache;

    @Autowired
    private BusinessIdentityCacheManager cacheManager;

    @Autowired
    private CacheService cacheService;

    private void initializeCache() {
        trustAssetSourceCache = cacheManager.initializeCache("trustAssetSourceCache", Integer.class, String.class);
    }

    private void refreshCache() {

        if (null == trustAssetSourceCache) {
            initializeCache();
        }

        trustAssetSourceCache.clear();

        List<TrustAssetSource> trustAssetSourceList = cacheService.getTrustAssetSources();

        trustAssetSourceList.forEach(trustAssetSource -> {
            if (null != trustAssetSource) {
                trustAssetSourceCache.put(trustAssetSource.getTrustAssetSourceId(), trustAssetSource.getTrustAssetSourceDescription());
            }
        });
    }

    public String getTrustAssetSourceDesc(int trustAssetSourceId) {

        if (!Util.isCacheLoaded(trustAssetSourceCache)) {
            refreshCache();
        }

        return trustAssetSourceCache.get(trustAssetSourceId);
    }

    public int getTrustAssetSourceId(String trustAssetSourceDesc) {

        int trustAssetSourceId = 0;

        if (StringUtils.isNotBlank(trustAssetSourceDesc)) {

            if (!Util.isCacheLoaded(trustAssetSourceCache)) {
                refreshCache();
            }

            for (Entry<Integer, String> trustAssetSource : trustAssetSourceCache) {

                if (trustAssetSourceDesc.equalsIgnoreCase(trustAssetSource.getValue())) {

                    trustAssetSourceId = trustAssetSource.getKey();
                    break;
                }
            }
        }

        if (0 != trustAssetSourceId) {
            return trustAssetSourceId;
        }
        else {
            // TODO: Do NOT return anything. Throw exception here.
            return 0;
        }
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
