package com.capitalone.api.nsb.business.identity.cache;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capitalone.api.nsb.business.identity.domain.cache.OwnershipStructType;
import com.capitalone.api.nsb.business.identity.service.CacheService;
import com.capitalone.api.nsb.business.identity.util.Util;

@Component
public class OwnershipStructTypeCacheHandler {

    private Cache<Integer, String> ownershipStructTypeCache;

    @Autowired
    private BusinessIdentityCacheManager cacheManager;

    @Autowired
    private CacheService cacheService;

    private void initializeCache() {
        ownershipStructTypeCache = cacheManager.initializeCache("ownershipStructTypeCache", Integer.class, String.class);
    }

    private void refreshCache() {

        if (null == ownershipStructTypeCache) {
            initializeCache();
        }

        ownershipStructTypeCache.clear();

        List<OwnershipStructType> ownershipStructTypeList = cacheService.getOwnershipStructTypes();

        ownershipStructTypeList.forEach(ownershipStructType -> {
            if (ownershipStructType != null) {
                ownershipStructTypeCache.put(ownershipStructType.getOwnershipStructTypeId(), ownershipStructType.getOwnershipStructTypeDescription());
            }
        });
    }

    public String getOwnershipStructTypeDesc(int ownershipStructTypeId) {

        if (!Util.isCacheLoaded(ownershipStructTypeCache)) {
            refreshCache();
        }

        return ownershipStructTypeCache.get(ownershipStructTypeId);
    }

    public int getOwnershipStructTypeId(String ownershipStructTypeDesc) {

        int ownershipStructTypeId = 0;

        if (StringUtils.isNotBlank(ownershipStructTypeDesc)) {

            if (!Util.isCacheLoaded(ownershipStructTypeCache)) {
                refreshCache();
            }

            for (Entry<Integer, String> ownershipStructType : ownershipStructTypeCache) {

                if (ownershipStructTypeDesc.equalsIgnoreCase(ownershipStructType.getValue())) {

                    ownershipStructTypeId = ownershipStructType.getKey();
                    break;
                }
            }
        }

        if (0 != ownershipStructTypeId) {
            return ownershipStructTypeId;
        }
        else {
            // TODO: Do NOT return anything. Throw exception here.
            return 0;
        }
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
