package com.capitalone.api.nsb.business.identity.domain;

import java.math.BigInteger;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

// TODO: Should trust_id be primary key instead of business_id? We can have UNIQUE constraint on business_id
@Entity
@Table(name = "business.trust")
@DynamicUpdate
public class Trust {

    @Id
    @Column(name = "trust_id", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "trust_trust_id_seq")
    @SequenceGenerator(sequenceName = "business.trust_trust_id_seq", allocationSize = 1, name = "trust_trust_id_seq")
    private BigInteger trustId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "business_id")
    private Business business;

    @Column(name = "trust_type_id")
    private Integer trustTypeId;

    @Column(name = "trust_type_other_desc")
    private String trustTypeOtherDesc;

    @Column(name = "trust_asset_source_id")
    private Integer trustAssetSourceId;

    @Column(name = "trust_asset_source_other_desc")
    private String trustAssetSourceOtherDesc;

    @Column(name = "offshore_funded_ind")
    private char offshoreFundedInd;

    @Column(name = "benefits_charity_org_ind")
    private char benefitsCharityOrgInd;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_date")
    private Timestamp createdDate;

    @Column(name = "modified_by")
    private String modifiedBy;

    @Column(name = "modified_date")
    private Timestamp modifiedDate;

    public BigInteger getTrustId() {
        return trustId;
    }

    public void setTrustId(BigInteger trustId) {
        this.trustId = trustId;
    }

    public Business getBusiness() {
        return business;
    }

    public void setBusiness(Business business) {
        this.business = business;
    }

    public Integer getTrustTypeId() {
        return trustTypeId;
    }

    public void setTrustTypeId(Integer trustTypeId) {
        this.trustTypeId = trustTypeId;
    }

    public String getTrustTypeOtherDesc() {
        return trustTypeOtherDesc;
    }

    public void setTrustTypeOtherDesc(String trustTypeOtherDesc) {
        this.trustTypeOtherDesc = trustTypeOtherDesc;
    }

    public Integer getTrustAssetSourceId() {
        return trustAssetSourceId;
    }

    public void setTrustAssetSourceId(Integer trustAssetSourceId) {
        this.trustAssetSourceId = trustAssetSourceId;
    }

    public String getTrustAssetSourceOtherDesc() {
        return trustAssetSourceOtherDesc;
    }

    public void setTrustAssetSourceOtherDesc(String trustAssetSourceOtherDesc) {
        this.trustAssetSourceOtherDesc = trustAssetSourceOtherDesc;
    }

    public char getOffshoreFundedInd() {
        return offshoreFundedInd;
    }

    public void setOffshoreFundedInd(char offshoreFundedInd) {
        this.offshoreFundedInd = offshoreFundedInd;
    }

    public char getBenefitsCharityOrgInd() {
        return benefitsCharityOrgInd;
    }

    public void setBenefitsCharityOrgInd(char benefitsCharityOrgInd) {
        this.benefitsCharityOrgInd = benefitsCharityOrgInd;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Timestamp getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Timestamp modifiedDate) {
        this.modifiedDate = modifiedDate;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
