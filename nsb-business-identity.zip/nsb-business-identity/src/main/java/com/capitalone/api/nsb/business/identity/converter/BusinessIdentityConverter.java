package com.capitalone.api.nsb.business.identity.converter;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capitalone.api.nsb.business.identity.cache.AddressTypeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.AnnualRevenueRangeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.BusinessStatusCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.BusinessStatusSubtypeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.HighRiskIndustryCodeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.LegalEntityTypeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.OwnershipStructTypeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.PhoneTypeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.TaxIdTypeCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.TrustAssetSourceCacheHandler;
import com.capitalone.api.nsb.business.identity.cache.TrustTypeCacheHandler;
import com.capitalone.api.nsb.business.identity.constants.Constants;
import com.capitalone.api.nsb.business.identity.cso.AddressCSO;
import com.capitalone.api.nsb.business.identity.cso.CreateBusinessDetailsRequest;
import com.capitalone.api.nsb.business.identity.cso.Header;
import com.capitalone.api.nsb.business.identity.cso.HighRiskIndustryCSO;
import com.capitalone.api.nsb.business.identity.cso.PhoneCSO;
import com.capitalone.api.nsb.business.identity.cso.RetrieveBusinessDetailsResponse;
import com.capitalone.api.nsb.business.identity.cso.TrustInfoCSO;
import com.capitalone.api.nsb.business.identity.cso.UpdateBusinessDetailsRequest;
import com.capitalone.api.nsb.business.identity.domain.Business;
import com.capitalone.api.nsb.business.identity.domain.BusinessAddress;
import com.capitalone.api.nsb.business.identity.domain.BusinessPhone;
import com.capitalone.api.nsb.business.identity.domain.HighRiskIndustry;
import com.capitalone.api.nsb.business.identity.domain.Trust;
import com.capitalone.api.nsb.business.identity.util.AnnualRevenueEnum;
import com.capitalone.api.nsb.business.identity.util.LegalEntityTypeEnum;
import com.capitalone.api.nsb.business.identity.util.OwnershipStructureTypeEnum;
import com.capitalone.api.nsb.business.identity.util.StatusEnum;
import com.capitalone.api.nsb.business.identity.util.StatusSubtypeEnum;
import com.capitalone.api.nsb.business.identity.util.TaxIdTypeEnum;
import com.capitalone.api.nsb.business.identity.util.TaxStatusEnum;
import com.capitalone.api.nsb.business.identity.util.TypeOfTrustEnum;
import com.capitalone.api.nsb.business.identity.util.Util;
import com.capitalone.api.nsb.business.identity.util.WealthTrustAssetSourceEnum;

@Component
public class BusinessIdentityConverter {

    @Autowired
    private AddressTypeCacheHandler addressTypeCacheHandler;

    @Autowired
    private AnnualRevenueRangeCacheHandler annualRevenueRangeCacheHandler;

    @Autowired
    private BusinessStatusCacheHandler businessStatusCacheHandler;

    @Autowired
    private BusinessStatusSubtypeCacheHandler businessStatusSubtypeCacheHandler;

    @Autowired
    private HighRiskIndustryCodeCacheHandler highRiskIndustryCodeCacheHandler;

    @Autowired
    private LegalEntityTypeCacheHandler legalEntityTypeCacheHandler;

    @Autowired
    private OwnershipStructTypeCacheHandler ownershipStructTypeCacheHandler;

    @Autowired
    private PhoneTypeCacheHandler phoneTypeCacheHandler;

    @Autowired
    private TaxIdTypeCacheHandler taxIdTypeCacheHandler;

    @Autowired
    private TrustAssetSourceCacheHandler trustAssetSourceCacheHandler;

    @Autowired
    private Util util;

    @Autowired
    private TrustTypeCacheHandler trustTypeCacheHandler;

    public Business mapCreateBusiness(CreateBusinessDetailsRequest createBusinessDetailsRequest, Header header) {
        Business business = new Business();

        int annualRevenue = annualRevenueRangeCacheHandler
                .getAnnualRevenueRangeId(AnnualRevenueEnum.get(createBusinessDetailsRequest.getAnnualRevenue()));
        business.setAnnualRevenue(annualRevenue);

        business.setBusinessSince(
                util.getSqlTimestampFromString(createBusinessDetailsRequest.getBusinessCustomerSince()));
        business.setCountryOfHeadquarters(createBusinessDetailsRequest.getCountryOfHeadquarters());
        business.setCountryOfLegalFormation(createBusinessDetailsRequest.getCountryOfHeadquarters());
        business.setStateOfFormation(createBusinessDetailsRequest.getStateOfFormation());
        business.setCountryOfPrimaryOperations(createBusinessDetailsRequest.getCountryOfPrimaryOperations());
        business.setDoingBusinessAs(createBusinessDetailsRequest.getDoingBusinessAs());
        business.setIndustryCode(new Integer(createBusinessDetailsRequest.getIndustryCode()));
        business.setIsCharitableOrganization(
                util.getCharFromBoolean(createBusinessDetailsRequest.isCharitableOrganization()));

        int legalEntityType = legalEntityTypeCacheHandler
                .getLegalEntityTypeId(LegalEntityTypeEnum.get(createBusinessDetailsRequest.getLegalEntityType()));
        business.setLegalEntityType(legalEntityType);

        business.setName(createBusinessDetailsRequest.getBusinessName());

        int ownershipStructureType = ownershipStructTypeCacheHandler.getOwnershipStructTypeId(
                OwnershipStructureTypeEnum.get(createBusinessDetailsRequest.getOwnershipStructureType()));
        business.setOwnershipStructureType(ownershipStructureType);

        business.setPurposeOfOrganization(createBusinessDetailsRequest.getPurposeOfOrganization());

        business.setRepeatedInternationalActivity(
                util.getCharFromBoolean(createBusinessDetailsRequest.isHasRepeatedInternationalActivity()));

        int status = businessStatusCacheHandler
                .getBusinessStatusCode(StatusEnum.get(createBusinessDetailsRequest.getBusinessCustomerStatus()));
        business.setStatus(status);

        int statusSubType = businessStatusSubtypeCacheHandler.getBusinessStatusSubtypeCode(
                StatusSubtypeEnum.get(createBusinessDetailsRequest.getBusinessCustomerStatusSubtype()));
        business.setStatusSubtype(statusSubType);

        business.setTaxId(createBusinessDetailsRequest.getTaxIdToken());
        business.setTaxIdIssuingCountry(createBusinessDetailsRequest.getTaxIdIssuingCountry());

        int taxIdType = taxIdTypeCacheHandler
                .getTaxIdTypeId(TaxIdTypeEnum.get(createBusinessDetailsRequest.getTaxIdType()));
        business.setTaxIdType(taxIdType);

        business.setTaxStatus(TaxStatusEnum.get(createBusinessDetailsRequest.getTaxStatus()));

        business.setWebsiteAddress(createBusinessDetailsRequest.getWebsiteAddress());
        business.setCreatedBy(header.getUserId());
        business.setCreatedDate(util.getCurrentDateTime());
        business.setModifiedBy(header.getUserId());
        business.setModifiedDate(util.getCurrentDateTime());

        business.setPhoneNumbers(mapBusinessPhone(createBusinessDetailsRequest.getPhoneNumbers(), header));
        business.setAddresses(mapBusinessAddress(createBusinessDetailsRequest.getAddresses(), header));

        business.setHighRiskIndustries(
                mapCreateHighRiskIndustry(createBusinessDetailsRequest.getAssociatedHighRiskIndustyCodes(), header));

        business.setTrust(mapTrustInfo(createBusinessDetailsRequest.getTrustInfo(), header));

        return business;
    }

    private Trust mapTrustInfo(TrustInfoCSO trustInfoCSO, Header header) {

        Trust trust = new Trust();

        int trustTypeId = trustTypeCacheHandler.getTrustTypeId(TypeOfTrustEnum.get(trustInfoCSO.getTypeOfTrust()));
        trust.setTrustTypeId(trustTypeId);

        trust.setTrustTypeOtherDesc(trustInfoCSO.getTypeOfTrustOther());

        int trustAssetSourceId = trustAssetSourceCacheHandler
                .getTrustAssetSourceId(WealthTrustAssetSourceEnum.get(trustInfoCSO.getWealthTrustAssetSource()));
        trust.setTrustAssetSourceId(trustAssetSourceId);

        trust.setTrustAssetSourceOtherDesc(trustInfoCSO.getWealthTrustAssetSourceOther());

        trust.setOffshoreFundedInd(util.getCharFromBoolean(trustInfoCSO.getIsTrustFundedFromOffshore()));
        trust.setBenefitsCharityOrgInd(
                util.getCharFromBoolean(trustInfoCSO.getDoesTrustBenefitCharitableOrganizations()));

        trust.setCreatedBy(header.getUserId());
        trust.setCreatedDate(util.getCurrentDateTime());

        trust.setModifiedBy(header.getUserId());
        trust.setModifiedDate(util.getCurrentDateTime());

        return trust;
    }

    private List<HighRiskIndustry> mapCreateHighRiskIndustry(List<HighRiskIndustryCSO> highRiskIndustriesCSOList,
            Header header) {
        List<HighRiskIndustry> highRiskIndustryList = new ArrayList<HighRiskIndustry>();

        if (util.isValidCollection(highRiskIndustriesCSOList)) {
            for (HighRiskIndustryCSO highRiskIndustriesCSO : highRiskIndustriesCSOList) {
                HighRiskIndustry highRiskIndustry = new HighRiskIndustry();
                highRiskIndustry.setHighRiskIndustryCode(highRiskIndustriesCSO.getHighRiskIndustryCode());
                // TODO
                highRiskIndustry.setCreatedBy(header.getUserId());
                highRiskIndustry.setCreatedDate(util.getCurrentDateTime());
                // TODO
                highRiskIndustry.setModifiedBy(header.getUserId());
                highRiskIndustry.setModifiedDate(util.getCurrentDateTime());
                highRiskIndustryList.add(highRiskIndustry);
            }
        }

        return highRiskIndustryList;

    }

    private List<BusinessPhone> mapBusinessPhone(List<PhoneCSO> phoneCSOList, Header header) {
        List<BusinessPhone> businessPhoneList = null;

        if (util.isValidCollection(phoneCSOList)) {
            businessPhoneList = new ArrayList<BusinessPhone>();
            for (PhoneCSO phoneCSO : phoneCSOList) {
                BusinessPhone businessPhone = new BusinessPhone();
                // TODO - Hard coded this as of now during create operation
                businessPhone.setActiveIndicator(Constants.YES);
                businessPhone.setCountryCode(phoneCSO.getCountryCode());
                businessPhone.setExtensionNumber(phoneCSO.getExtensionNumber());

                if (null != phoneCSO.getPhoneType()) {
                    int phoneType = phoneTypeCacheHandler.getPhoneTypeId(phoneCSO.getPhoneType());
                    businessPhone.setPhoneTypeId(phoneType);
                }

                businessPhone.setTelephoneNumber(phoneCSO.getTelephoneNumber());
                // TODO
                businessPhone.setCreatedBy(header.getUserId());
                businessPhone.setCreatedDate(util.getCurrentDateTime());
                // TODO
                businessPhone.setModifiedBy(header.getUserId());
                businessPhone.setModifiedDate(util.getCurrentDateTime());
                businessPhoneList.add(businessPhone);

            }
        }

        return businessPhoneList;
    }

    private List<BusinessAddress> mapBusinessAddress(List<AddressCSO> addressesCSOList, Header header) {
        List<BusinessAddress> businessAddressList = null;

        if (util.isValidCollection(addressesCSOList)) {
            businessAddressList = new ArrayList<BusinessAddress>();
            for (AddressCSO addressCSO : addressesCSOList) {
                BusinessAddress businessAddress = new BusinessAddress();
                // TODO - Hard coded this as of now during create operation
                businessAddress.setActiveIndicator(Constants.YES);
                businessAddress.setAddressLine1(addressCSO.getAddressLine1());
                businessAddress.setAddressLine2(addressCSO.getAddressLine2());
                businessAddress.setAddressLine3(addressCSO.getAddressLine3());
                businessAddress.setAddressLine4(addressCSO.getAddressLine4());

                if (null != addressCSO.getAddressType()) {
                    int addressType = addressTypeCacheHandler.getAddressTypeId(addressCSO.getAddressType());
                    businessAddress.setAddressTypeId(addressType);
                }

                businessAddress.setCity(addressCSO.getCity());
                businessAddress.setCountryCode(addressCSO.getCountryCode());
                businessAddress.setPostalCode(addressCSO.getPostalCode());
                businessAddress.setStateCode(addressCSO.getStateCode());
                // TODO
                businessAddress.setCreatedBy(header.getUserId());
                businessAddress.setCreatedDate(util.getCurrentDateTime());
                // TODO
                businessAddress.setModifiedBy(header.getUserId());
                businessAddress.setModifiedDate(util.getCurrentDateTime());
                businessAddressList.add(businessAddress);
            }
        }
        return businessAddressList;
    }

    public RetrieveBusinessDetailsResponse mapRetreiveBusinessResponse(Business business) {
        RetrieveBusinessDetailsResponse retrieveBusinessDetailsResponse = null;

        if (null != business) {

            retrieveBusinessDetailsResponse = new RetrieveBusinessDetailsResponse();

            List<BusinessAddress> businessAddressList = business.getAddresses();

            if (util.isValidCollection(businessAddressList)) {

                List<AddressCSO> addressCSOList = new ArrayList<AddressCSO>();

                for (BusinessAddress businessAddress : businessAddressList) {

                    if (null != businessAddress && util.getBooleanFromChar(businessAddress.getActiveIndicator())) {

                        AddressCSO addressCSO = new AddressCSO();
                        BeanUtils.copyProperties(businessAddress, addressCSO);

                        String addressType = addressTypeCacheHandler
                                .getAddressTypeName(businessAddress.getAddressTypeId());
                        addressCSO.setAddressType(addressType);
                        addressCSOList.add(addressCSO);
                    }
                }

                retrieveBusinessDetailsResponse.setAddresses(addressCSOList);
            }

            String annualRevenue = annualRevenueRangeCacheHandler
                    .getAnnualRevenueRangeDesc(business.getAnnualRevenue());
            retrieveBusinessDetailsResponse.setAnnualRevenue(AnnualRevenueEnum.fromString(annualRevenue));

            retrieveBusinessDetailsResponse.setBusinessReferenceId(String.valueOf(business.getBusinessReferenceId()));

            retrieveBusinessDetailsResponse
                    .setBusinessCustomerSince(util.getStringFromSqlTimestamp(business.getBusinessSince()));

            retrieveBusinessDetailsResponse
                    .setCharitableOrganization(util.getBooleanFromChar(business.getIsCharitableOrganization()));

            retrieveBusinessDetailsResponse.setCountryOfHeadquarters(business.getCountryOfHeadquarters());

            retrieveBusinessDetailsResponse.setCountryOfLegalFormation(business.getCountryOfLegalFormation());

            retrieveBusinessDetailsResponse.setStateOfFormation(business.getStateOfFormation());

            retrieveBusinessDetailsResponse.setCountryOfPrimaryOperations(business.getCountryOfPrimaryOperations());

            retrieveBusinessDetailsResponse.setDoingBusinessAs(business.getDoingBusinessAs());

            List<HighRiskIndustry> highRiskIndustryList = business.getHighRiskIndustries();

            if (util.isValidCollection(highRiskIndustryList)) {

                List<HighRiskIndustryCSO> highRiskIndustryCSOList = new ArrayList<HighRiskIndustryCSO>();

                for (HighRiskIndustry highRiskIndustry : highRiskIndustryList) {

                    HighRiskIndustryCSO highRiskIndustryCSO = new HighRiskIndustryCSO();
                    highRiskIndustryCSO.setHighRiskIndustryCode(highRiskIndustry.getHighRiskIndustryCode());
                    highRiskIndustryCSO.setDescription(highRiskIndustryCodeCacheHandler
                            .getHighRiskIndustryCodeDesc(highRiskIndustry.getHighRiskIndustryCode()));

                    highRiskIndustryCSOList.add(highRiskIndustryCSO);
                }

                retrieveBusinessDetailsResponse.setAssociatedHighRiskIndustyCodes(highRiskIndustryCSOList);
            }

            retrieveBusinessDetailsResponse.setIndustryCode(String.valueOf(business.getIndustryCode()));

            String legalEntityTypeDesc = legalEntityTypeCacheHandler
                    .getLegalEntityTypeDesc(business.getLegalEntityType());
            retrieveBusinessDetailsResponse.setLegalEntityType(LegalEntityTypeEnum.fromString(legalEntityTypeDesc));
            retrieveBusinessDetailsResponse.setLegalEntityTypeDescription(legalEntityTypeDesc);

            retrieveBusinessDetailsResponse.setBusinessName(business.getName());

            // TODO - Add in DB schema
            retrieveBusinessDetailsResponse.setOwnerControlType(null);

            String ownershipStructureType = ownershipStructTypeCacheHandler
                    .getOwnershipStructTypeDesc(business.getOwnershipStructureType());
            retrieveBusinessDetailsResponse
                    .setOwnershipStructureType(OwnershipStructureTypeEnum.fromString(ownershipStructureType));

            List<BusinessPhone> businessPhoneList = business.getPhoneNumbers();

            if (util.isValidCollection(businessPhoneList)) {

                List<PhoneCSO> phoneCSOList = new ArrayList<PhoneCSO>();

                for (BusinessPhone businessPhone : businessPhoneList) {

                    if (null != businessPhone && util.getBooleanFromChar(businessPhone.getActiveIndicator())) {

                        PhoneCSO phoneCSO = new PhoneCSO();
                        BeanUtils.copyProperties(businessPhone, phoneCSO);

                        String phoneType = phoneTypeCacheHandler.getPhoneTypeName(businessPhone.getPhoneTypeId());
                        phoneCSO.setPhoneType(phoneType);
                        phoneCSOList.add(phoneCSO);
                    }
                }

                retrieveBusinessDetailsResponse.setPhoneNumbers(phoneCSOList);
            }

            retrieveBusinessDetailsResponse.setPurposeOfOrganization(business.getPurposeOfOrganization());

            // TODO: Map based on PurposeOfOrganization
            retrieveBusinessDetailsResponse.setPurposeOfOrganizationOther(null);

            retrieveBusinessDetailsResponse.setHasRepeatedInternationalActivity(
                    util.getBooleanFromChar(business.getRepeatedInternationalActivity()));

            String status = businessStatusCacheHandler.getBusinessStatusDesc(business.getStatus());
            retrieveBusinessDetailsResponse.setBusinessCustomerStatus(StatusEnum.fromString(status));

            String statusSubtype = businessStatusSubtypeCacheHandler
                    .getBusinessStatusSubtypeDesc(business.getStatusSubtype());
            retrieveBusinessDetailsResponse
                    .setBusinessCustomerStatusSubtype(StatusSubtypeEnum.fromString(statusSubtype));

            retrieveBusinessDetailsResponse.setTaxIdToken(business.getTaxId());

            String taxyIdType = taxIdTypeCacheHandler.getTaxIdTypeShortDesc(business.getTaxIdType());
            retrieveBusinessDetailsResponse.setTaxIdType(TaxIdTypeEnum.fromString(taxyIdType));

            retrieveBusinessDetailsResponse.setTaxIdIssuingCountry(business.getTaxIdIssuingCountry());

            retrieveBusinessDetailsResponse.setTaxStatus(TaxStatusEnum.fromString(business.getTaxStatus()));

            Trust trust = business.getTrust();

            if (null != trust) {

                TrustInfoCSO trustInfo = new TrustInfoCSO();

                String typeOfTrust = trustTypeCacheHandler.getTrustTypeDesc(trust.getTrustTypeId());
                trustInfo.setTypeOfTrust(TypeOfTrustEnum.fromString(typeOfTrust));

                trustInfo.setTypeOfTrustOther(trust.getTrustTypeOtherDesc());

                String wealthTrustAssetSource = trustAssetSourceCacheHandler
                        .getTrustAssetSourceDesc(trust.getTrustAssetSourceId());
                trustInfo.setWealthTrustAssetSource(WealthTrustAssetSourceEnum.fromString(wealthTrustAssetSource));

                trustInfo.setWealthTrustAssetSourceOther(trust.getTrustAssetSourceOtherDesc());

                trustInfo.setIsTrustFundedFromOffshore(util.getBooleanFromChar(trust.getOffshoreFundedInd()));

                trustInfo.setDoesTrustBenefitCharitableOrganizations(
                        util.getBooleanFromChar(trust.getBenefitsCharityOrgInd()));

                retrieveBusinessDetailsResponse.setTrustInfo(trustInfo);
            }

            retrieveBusinessDetailsResponse.setWebsiteAddress(business.getWebsiteAddress());
        }

        return retrieveBusinessDetailsResponse;
    }

    public Business mapUpdateBusiness(Business business, UpdateBusinessDetailsRequest updateBusinessDetailsRequest,
            Header header) {

        if (null != updateBusinessDetailsRequest && null != business) {

            boolean updateInfo = false;

            String annualRevenue = updateBusinessDetailsRequest.getAnnualRevenue();
            if (StringUtils.isNotEmpty(annualRevenue)) {
                int annualRevenueInt = annualRevenueRangeCacheHandler
                        .getAnnualRevenueRangeId(AnnualRevenueEnum.get(annualRevenue));
                business.setAnnualRevenue(annualRevenueInt);
                updateInfo = true;
            }

            String businessSince = updateBusinessDetailsRequest.getBusinessCustomerSince();
            if (StringUtils.isNotEmpty(businessSince)) {
                business.setBusinessSince(util.getSqlTimestampFromString(businessSince));
                updateInfo = true;
            }

            String countryOfHeadquarters = updateBusinessDetailsRequest.getCountryOfHeadquarters();
            if (StringUtils.isNotEmpty(countryOfHeadquarters)) {
                business.setCountryOfHeadquarters(countryOfHeadquarters);
                updateInfo = true;
            }

            String countryOfLegalFormation = updateBusinessDetailsRequest.getCountryOfLegalFormation();
            if (StringUtils.isNotEmpty(countryOfLegalFormation)) {
                business.setCountryOfLegalFormation(countryOfLegalFormation);
                updateInfo = true;
            }

            String stateOfFormation = updateBusinessDetailsRequest.getStateOfFormation();
            if (StringUtils.isNotEmpty(stateOfFormation)) {
                business.setStateOfFormation(stateOfFormation);
                updateInfo = true;
            }

            String countryOfPrimaryOperations = updateBusinessDetailsRequest.getCountryOfPrimaryOperations();
            if (StringUtils.isNotEmpty(countryOfPrimaryOperations)) {
                business.setCountryOfPrimaryOperations(countryOfPrimaryOperations);
                updateInfo = true;
            }

            String doingBusinessAs = updateBusinessDetailsRequest.getDoingBusinessAs();
            if (StringUtils.isNotEmpty(doingBusinessAs)) {
                business.setDoingBusinessAs(doingBusinessAs);
                updateInfo = true;
            }

            String industryCode = updateBusinessDetailsRequest.getIndustryCode();
            if (StringUtils.isNotEmpty(industryCode)) {
                business.setIndustryCode(new Integer(industryCode));
                updateInfo = true;
            }

            Boolean charitableOrganization = updateBusinessDetailsRequest.isCharitableOrganization();
            if (null != charitableOrganization) {
                business.setIsCharitableOrganization(util.getCharFromBoolean(charitableOrganization));
                updateInfo = true;
            }

            String legalEntityType = updateBusinessDetailsRequest.getLegalEntityType();
            if (StringUtils.isNotEmpty(legalEntityType)) {
                int legalEntityTypeint = legalEntityTypeCacheHandler
                        .getLegalEntityTypeId(LegalEntityTypeEnum.get(legalEntityType));
                business.setLegalEntityType(new Integer(legalEntityTypeint));
                updateInfo = true;
            }

            String name = updateBusinessDetailsRequest.getBusinessName();
            if (StringUtils.isNotEmpty(name)) {
                business.setName(name);
                updateInfo = true;
            }

            String purposeOfOrganization = updateBusinessDetailsRequest.getPurposeOfOrganization();
            if (StringUtils.isNotEmpty(purposeOfOrganization)) {
                business.setPurposeOfOrganization(purposeOfOrganization);
                updateInfo = true;
            }

            Boolean hasRepeatedInternationalActivity = updateBusinessDetailsRequest
                    .isHasRepeatedInternationalActivity();
            if (null != hasRepeatedInternationalActivity) {
                business.setRepeatedInternationalActivity(util.getCharFromBoolean(hasRepeatedInternationalActivity));
                updateInfo = true;
            }

            String status = updateBusinessDetailsRequest.getBusinessCustomerStatus();
            if (StringUtils.isNotEmpty(status)) {
                int statusInt = businessStatusCacheHandler.getBusinessStatusCode(StatusEnum.get(status));
                business.setStatus(new Integer(statusInt));
                updateInfo = true;
            }

            String statusSubtype = updateBusinessDetailsRequest.getBusinessCustomerStatusSubtype();
            if (StringUtils.isNotEmpty(statusSubtype)) {
                int statusSubTypeInt = businessStatusSubtypeCacheHandler
                        .getBusinessStatusSubtypeCode(StatusSubtypeEnum.get(statusSubtype));
                business.setStatusSubtype(new Integer(statusSubTypeInt));
                updateInfo = true;
            }

            String taxId = updateBusinessDetailsRequest.getTaxIdToken();
            if (StringUtils.isNotEmpty(taxId)) {
                business.setTaxId(taxId);
                updateInfo = true;
            }

            String taxIdIssuingCountry = updateBusinessDetailsRequest.getTaxIdIssuingCountry();
            if (StringUtils.isNotEmpty(taxIdIssuingCountry)) {
                business.setTaxIdIssuingCountry(taxIdIssuingCountry);
                updateInfo = true;
            }

            String taxIdType = updateBusinessDetailsRequest.getTaxIdType();
            if (StringUtils.isNotEmpty(taxIdType)) {
                int taxIdTypeInt = taxIdTypeCacheHandler.getTaxIdTypeId(TaxIdTypeEnum.get(taxIdType));
                business.setTaxIdType(new Integer(taxIdTypeInt));
                updateInfo = true;
            }

            String taxStatus = updateBusinessDetailsRequest.getTaxStatus();
            if (StringUtils.isNotEmpty(taxStatus)) {
                business.setTaxStatus(taxStatus);
                updateInfo = true;
            }

            String websiteAddress = updateBusinessDetailsRequest.getWebsiteAddress();
            if (StringUtils.isNotEmpty(websiteAddress)) {
                business.setWebsiteAddress(websiteAddress);
                updateInfo = true;
            }

            String ownershipStructureType = updateBusinessDetailsRequest.getOwnershipStructureType();
            if (StringUtils.isNotEmpty(ownershipStructureType)) {
                int ownershipStructureTypeInt = ownershipStructTypeCacheHandler
                        .getOwnershipStructTypeId(OwnershipStructureTypeEnum.get(ownershipStructureType));

                business.setOwnershipStructureType(new Integer(ownershipStructureTypeInt));
                updateInfo = true;

            }

            if (updateInfo) {
                business.setModifiedBy(header.getUserId());
                business.setModifiedDate(util.getCurrentDateTime());
                updateInfo = true;
            }

            TrustInfoCSO trustInfoCSO = updateBusinessDetailsRequest.getTrustInfo();
            if (null != trustInfoCSO) {

                Trust trust = business.getTrust();

                trust = mapTrustInfoForUpdate(trust, trustInfoCSO, header);

                business.setTrust(trust);
            }
        }

        return business;
    }

    private Trust mapTrustInfoForUpdate(Trust trust, TrustInfoCSO trustInfoCSO, Header header) {

        boolean updateTrustInfo = false;

        String typeOfTrust = trustInfoCSO.getTypeOfTrust();
        if (StringUtils.isNotEmpty(typeOfTrust)) {
            int trustTypeId = trustTypeCacheHandler.getTrustTypeId(TypeOfTrustEnum.get(typeOfTrust));
            trust.setTrustTypeId(trustTypeId);
            updateTrustInfo = true;
        }

        String typeOfTrustOther = trustInfoCSO.getTypeOfTrustOther();
        if (StringUtils.isNotEmpty(typeOfTrustOther)) {
            trust.setTrustTypeOtherDesc(typeOfTrustOther);
            updateTrustInfo = true;
        }

        String wealthTrustAssetSource = trustInfoCSO.getWealthTrustAssetSource();
        if (StringUtils.isNotEmpty(wealthTrustAssetSource)) {
            int trustAssetSourceId = trustAssetSourceCacheHandler
                    .getTrustAssetSourceId(WealthTrustAssetSourceEnum.get(wealthTrustAssetSource));
            trust.setTrustAssetSourceId(trustAssetSourceId);
            updateTrustInfo = true;
        }

        String wealthTrustAssetSourceOther = trustInfoCSO.getWealthTrustAssetSourceOther();
        if (StringUtils.isNotEmpty(wealthTrustAssetSourceOther)) {
            trust.setTrustAssetSourceOtherDesc(wealthTrustAssetSourceOther);
            updateTrustInfo = true;
        }

        Boolean trustFundedFromOffshore = trustInfoCSO.getIsTrustFundedFromOffshore();
        if (null != trustFundedFromOffshore) {
            trust.setOffshoreFundedInd(util.getCharFromBoolean(trustFundedFromOffshore));
            updateTrustInfo = true;
        }

        Boolean doesTrustBenefitCharitableOrganizations = trustInfoCSO.getDoesTrustBenefitCharitableOrganizations();
        if (null != doesTrustBenefitCharitableOrganizations) {
            trust.setBenefitsCharityOrgInd(util.getCharFromBoolean(doesTrustBenefitCharitableOrganizations));
            updateTrustInfo = true;
        }

        if (updateTrustInfo) {
            trust.setModifiedBy(header.getUserId());
            trust.setModifiedDate(util.getCurrentDateTime());
        }

        return trust;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
