package com.capitalone.api.nsb.business.identity.domain.cache;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "business.trust_asset_source")
public class TrustAssetSource {

    @Id
    @Column(name = "trust_asset_source_id", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer trustAssetSourceId;

    @Column(name = "trust_asset_source_description")
    private String trustAssetSourceDescription;

    public Integer getTrustAssetSourceId() {
        return trustAssetSourceId;
    }

    public void setTrustAssetSourceId(Integer trustAssetSourceId) {
        this.trustAssetSourceId = trustAssetSourceId;
    }

    public String getTrustAssetSourceDescription() {
        return trustAssetSourceDescription;
    }

    public void setTrustAssetSourceDescription(String trustAssetSourceDescription) {
        this.trustAssetSourceDescription = trustAssetSourceDescription;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
