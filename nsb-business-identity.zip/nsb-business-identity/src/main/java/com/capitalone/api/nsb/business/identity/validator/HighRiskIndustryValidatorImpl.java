package com.capitalone.api.nsb.business.identity.validator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.capitalone.api.nsb.business.identity.constants.Constants;

public class HighRiskIndustryValidatorImpl implements ConstraintValidator<HighRiskIndustryValidator, Integer> {

    @Autowired
    private Environment environment;

    private List<String> highRiskIndustryCodes;

    @Override
    public void initialize(HighRiskIndustryValidator constraintAnnotation) {

        highRiskIndustryCodes = new ArrayList<>();

        String hriPropValue = environment.getProperty(Constants.HIGHRISK_INDUSTRY_CODE);

        if (StringUtils.isNotBlank(hriPropValue)) {
            highRiskIndustryCodes.addAll(Arrays.asList(hriPropValue.split("\\s*,\\s*")));
        }
    }

    @Override
    public boolean isValid(Integer value, ConstraintValidatorContext context) {

        if (highRiskIndustryCodes.contains(String.valueOf(value))) {
            return true;
        }

        return false;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */