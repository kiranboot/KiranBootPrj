package com.capitalone.api.nsb.business.identity.domain.cache;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "business.annual_revenue_range")
public class AnnualRevenueRange {

    @Id
    @Column(name = "annual_revenue_range_id", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer annualRevenueRangeId;

    @Column(name = "annual_revenue_range_description")
    private String annualRevenueRangeDescription;

    public Integer getAnnualRevenueRangeId() {
        return annualRevenueRangeId;
    }

    public void setAnnualRevenueRangeId(Integer annualRevenueRangeId) {
        this.annualRevenueRangeId = annualRevenueRangeId;
    }

    public String getAnnualRevenueRangeDescription() {
        return annualRevenueRangeDescription;
    }

    public void setAnnualRevenueRangeDescription(String annualRevenueRangeDescription) {
        this.annualRevenueRangeDescription = annualRevenueRangeDescription;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
