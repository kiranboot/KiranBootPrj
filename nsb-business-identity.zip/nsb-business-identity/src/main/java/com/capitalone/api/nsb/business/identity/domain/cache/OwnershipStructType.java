package com.capitalone.api.nsb.business.identity.domain.cache;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "business.ownership_struct_type")
public class OwnershipStructType {

    @Id
    @Column(name = "ownership_struct_type_id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer ownershipStructTypeId;

    @Column(name = "ownership_struct_type_description")
    private String ownershipStructTypeDescription;

    public Integer getOwnershipStructTypeId() {
        return ownershipStructTypeId;
    }

    public void setOwnershipStructTypeId(Integer ownershipStructTypeId) {
        this.ownershipStructTypeId = ownershipStructTypeId;
    }

    public String getOwnershipStructTypeDescription() {
        return ownershipStructTypeDescription;
    }

    public void setOwnershipStructTypeDescription(String ownershipStructTypeDescription) {
        this.ownershipStructTypeDescription = ownershipStructTypeDescription;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
