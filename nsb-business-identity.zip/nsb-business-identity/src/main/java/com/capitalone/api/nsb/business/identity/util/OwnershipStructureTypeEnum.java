package com.capitalone.api.nsb.business.identity.util;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

public enum OwnershipStructureTypeEnum {

    PubliclyTraded("Publicly Traded"),
    GovernmentOwned("Government Owned"),
    PrivatelyOwned("Privately Owned");
    
    private static final Map<String, String> OWNERSHIPSTRUCTURETYPE = new HashMap<String, String>();

    static {
        for (OwnershipStructureTypeEnum ownershipStructureType : EnumSet.allOf(OwnershipStructureTypeEnum.class)) {
            OWNERSHIPSTRUCTURETYPE.put(StringUtils.upperCase(ownershipStructureType.name()),
                    ownershipStructureType.getOwnershipStructureTypeStr());
        }
    }

    private String ownershipStructureTypeStr;

    private OwnershipStructureTypeEnum(String ownershipStructureTypeStr) {
        this.ownershipStructureTypeStr = ownershipStructureTypeStr;
    }

    public String getOwnershipStructureTypeStr() {
        return ownershipStructureTypeStr;
    }

    public static String get(String ownershipStructureTypeStr) {
        return OWNERSHIPSTRUCTURETYPE.get(ownershipStructureTypeStr.toUpperCase());
    }

    public static String fromString(String value) {
        for (Entry<String, String> entry : OWNERSHIPSTRUCTURETYPE.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(value)) {
                return entry.getKey();
            }
        }
        return null;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
