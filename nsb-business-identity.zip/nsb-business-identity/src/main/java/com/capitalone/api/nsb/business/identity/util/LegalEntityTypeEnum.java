package com.capitalone.api.nsb.business.identity.util;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

public enum LegalEntityTypeEnum {

    InternationalBusinessCorporation("International Business Corporation"),
    LimitedLiabilityCompany("Limited Liability Company"),
    NonProfit("Non-Profit"),
    Partnership("Partnership"),
    SolePropOrAssociation("Sole Proprietorship"),
    PublicFundsOrGovernmentAgency("Public Funds Or Government Agency"),
    PrivateInvestmentCompany("Private Investment Company"),
    CCorporation("C-Corporation"),
    SCorporation("S-Corporation"),
    TrustOrEstate("Trust Or Estate"),
    Corporation("Corporation");

    private static final Map<String, String> LEGALENTITYTYPE = new HashMap<String, String>();

    static {
        for (LegalEntityTypeEnum legalEntityType : EnumSet.allOf(LegalEntityTypeEnum.class)) {
            LEGALENTITYTYPE.put(StringUtils.upperCase(legalEntityType.name()), legalEntityType.getLegalEntityTypeStr());
        }
    }

    private String legalEntityTypeStr;

    private LegalEntityTypeEnum(String legalEntityType) {
        this.legalEntityTypeStr = legalEntityType;
    }

    public String getLegalEntityTypeStr() {
        return legalEntityTypeStr;
    }

    public static String get(String legalEntityTypeStr) {
        return LEGALENTITYTYPE.get(legalEntityTypeStr.toUpperCase());
    }

    public static String fromString(String value) {
        for (Entry<String, String> entry : LEGALENTITYTYPE.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(value)) {
                return entry.getKey();
            }
        }
        return null;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
