package com.capitalone.api.nsb.business.identity.domain.cache;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "commons.tax_id_type")
public class TaxIdType {

    @Id
    @Column(name = "tax_id_type_id", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer taxTypeId;

    @Column(name = "tax_id_type_short_description")
    private String taxTypeShortDesc;

    // TODO add this to cache
    //@Column(name = "tax_id_type_description")

    public Integer getTaxTypeId() {
        return taxTypeId;
    }

    public void setTaxTypeId(Integer taxTypeId) {
        this.taxTypeId = taxTypeId;
    }

    public String getTaxTypeShortDesc() {
        return taxTypeShortDesc;
    }

    public void setTaxTypeShortDesc(String taxTypeShortDesc) {
        this.taxTypeShortDesc = taxTypeShortDesc;
    }


}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
