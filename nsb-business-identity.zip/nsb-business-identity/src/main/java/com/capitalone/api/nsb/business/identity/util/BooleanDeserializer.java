package com.capitalone.api.nsb.business.identity.util;

import java.io.IOException;

import com.capitalone.api.nsb.business.identity.constants.Constants;
import com.capitalone.api.nsb.business.identity.exception.RequestValidationException;
import com.capitalone.api.nsb.business.identity.exception.ServiceErrorCode;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

public class BooleanDeserializer extends JsonDeserializer<Boolean> {

    @Override
    public Boolean deserialize(JsonParser parser, DeserializationContext context)
            throws IOException, JsonProcessingException {

        String inputValue = parser.getText();

        if (Constants.TRUE.equals(inputValue)) {
            return true;
        }
        else if (Constants.FALSE.equals(inputValue)) {
            return false;
        }
        else {
            throw new RequestValidationException(ServiceErrorCode.INPUT_VALIDATION_ERROR, "Invalid input for property "
                    + parser.getCurrentName() + " [" + inputValue + "]. Only true or false is allowed.", null);
        }
    }

    @Override
    public Boolean getNullValue(DeserializationContext context) {
        return null;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
