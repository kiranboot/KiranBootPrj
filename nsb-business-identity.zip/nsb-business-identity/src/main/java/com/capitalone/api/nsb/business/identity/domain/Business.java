package com.capitalone.api.nsb.business.identity.domain;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

@Entity
@Table(name = "business.business")
@DynamicUpdate
public class Business {

    @Id
    @Column(name = "business_id", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "BUSINESS_SEQ")
    @SequenceGenerator(sequenceName = "business.business_business_id_seq", allocationSize = 1, name = "BUSINESS_SEQ")
    private BigInteger businessReferenceId;

    @Column(name = "legal_entity_type_id")
    private Integer legalEntityType;

    @Column(name = "legal_name")
    private String name;

    @Column(name = "tax_id_type_id")
    private Integer taxIdType;

    @Column(name = "tax_id")
    private String taxId;

    // @Column(name = "")
    // private String email;

    @Column(name = "naics_code")
    private Integer industryCode;

    @OneToMany(mappedBy = "business", cascade = CascadeType.ALL)
    private List<HighRiskIndustry> highRiskIndustries;

    // @Column(name = "")
    // private String ownerControlType;

    @Column(name = "ownership_struct_type_id")
    private Integer ownershipStructureType;

    @Column(name = "doing_business_as")
    private String doingBusinessAs;

    @Column(name = "website_url")
    private String websiteAddress;

    @Column(name = "tax_id_issuing_country_code")
    private String taxIdIssuingCountry;

    @Column(name = "hq_country_code")
    private String countryOfHeadquarters;

    @Column(name = "legal_formation_country_code")
    private String countryOfLegalFormation;

    @Column(name = "formation_state")
    private String stateOfFormation;

    @Column(name = "primary_operation_country_code")
    private String countryOfPrimaryOperations;

    @Column(name = "annual_revenue_range_id")
    private Integer annualRevenue;

    @OneToOne(mappedBy = "business", cascade = CascadeType.ALL)
    private Trust trust;

    @Column(name = "charitable_org_ind")
    private Character isCharitableOrganization;

    @Column(name = "business_purpose")
    private String purposeOfOrganization;

    @Column(name = "international_activity_ind")
    private Character repeatedInternationalActivity;

    @OneToMany(mappedBy = "business", cascade = CascadeType.ALL)
    private List<BusinessAddress> addresses;

    @OneToMany(mappedBy = "business", cascade = CascadeType.ALL)
    private List<BusinessPhone> phoneNumbers;

    @Column(name = "tax_status")
    private String taxStatus;

    @Column(name = "status")
    private Integer status;

    @Column(name = "status_subtype")
    private Integer statusSubtype;

    @Column(name = "business_since")
    private Timestamp businessSince;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_date")
    private Timestamp createdDate;

    @Column(name = "modified_by")
    private String modifiedBy;

    @Column(name = "modified_date")
    private Timestamp modifiedDate;

    public BigInteger getBusinessReferenceId() {
        return businessReferenceId;
    }

    public void setBusinessReferenceId(BigInteger businessReferenceId) {
        this.businessReferenceId = businessReferenceId;
    }

    public Integer getLegalEntityType() {
        return legalEntityType;
    }

    public void setLegalEntityType(Integer legalEntityType) {
        this.legalEntityType = legalEntityType;
    }

    public String getName() {
        return name;
    }

    public List<BusinessAddress> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<BusinessAddress> addresses) {
        for (BusinessAddress businessAddress : addresses) {
            if (null != businessAddress && this != businessAddress.getBusiness()) {
                businessAddress.setBusiness(this);
            }
        }

        this.addresses = addresses;
    }

    public List<BusinessPhone> getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(List<BusinessPhone> phoneNumbers) {
        for (BusinessPhone businessPhone : phoneNumbers) {
            if (null != businessPhone && this != businessPhone.getBusiness()) {
                businessPhone.setBusiness(this);
            }
        }

        this.phoneNumbers = phoneNumbers;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getTaxIdType() {
        return taxIdType;
    }

    public void setTaxIdType(Integer taxIdType) {
        this.taxIdType = taxIdType;
    }

    public String getTaxId() {
        return taxId;
    }

    public void setTaxId(String taxId) {
        this.taxId = taxId;
    }

    public Integer getIndustryCode() {
        return industryCode;
    }

    public void setIndustryCode(Integer industryCode) {
        this.industryCode = industryCode;
    }

    public List<HighRiskIndustry> getHighRiskIndustries() {
        return highRiskIndustries;
    }

    public void setHighRiskIndustries(List<HighRiskIndustry> highRiskIndustries) {
        for (HighRiskIndustry highRiskIndustry : highRiskIndustries) {
            if (null != highRiskIndustry && this != highRiskIndustry.getBusiness()) {
                highRiskIndustry.setBusiness(this);
            }
        }

        this.highRiskIndustries = highRiskIndustries;
    }

    public Integer getOwnershipStructureType() {
        return ownershipStructureType;
    }

    public void setOwnershipStructureType(Integer ownershipStructureType) {
        this.ownershipStructureType = ownershipStructureType;
    }

    public String getDoingBusinessAs() {
        return doingBusinessAs;
    }

    public void setDoingBusinessAs(String doingBusinessAs) {
        this.doingBusinessAs = doingBusinessAs;
    }

    public String getWebsiteAddress() {
        return websiteAddress;
    }

    public void setWebsiteAddress(String websiteAddress) {
        this.websiteAddress = websiteAddress;
    }

    public String getTaxIdIssuingCountry() {
        return taxIdIssuingCountry;
    }

    public void setTaxIdIssuingCountry(String taxIdIssuingCountry) {
        this.taxIdIssuingCountry = taxIdIssuingCountry;
    }

    public String getCountryOfHeadquarters() {
        return countryOfHeadquarters;
    }

    public void setCountryOfHeadquarters(String countryOfHeadquarters) {
        this.countryOfHeadquarters = countryOfHeadquarters;
    }

    public String getCountryOfLegalFormation() {
        return countryOfLegalFormation;
    }

    public void setCountryOfLegalFormation(String countryOfLegalFormation) {
        this.countryOfLegalFormation = countryOfLegalFormation;
    }

    public String getStateOfFormation() {
        return stateOfFormation;
    }

    public void setStateOfFormation(String stateOfFormation) {
        this.stateOfFormation = stateOfFormation;
    }

    public String getCountryOfPrimaryOperations() {
        return countryOfPrimaryOperations;
    }

    public void setCountryOfPrimaryOperations(String countryOfPrimaryOperations) {
        this.countryOfPrimaryOperations = countryOfPrimaryOperations;
    }

    public Integer getAnnualRevenue() {
        return annualRevenue;
    }

    public void setAnnualRevenue(Integer annualRevenue) {
        this.annualRevenue = annualRevenue;
    }

    public Trust getTrust() {
        return trust;
    }

    public void setTrust(Trust trust) {
        if (null != trust && this != trust.getBusiness()) {
            trust.setBusiness(this);
        }

        this.trust = trust;
    }

    public Character getIsCharitableOrganization() {
        return isCharitableOrganization;
    }

    public void setIsCharitableOrganization(Character isCharitableOrganization) {
        this.isCharitableOrganization = isCharitableOrganization;
    }

    public String getPurposeOfOrganization() {
        return purposeOfOrganization;
    }

    public void setPurposeOfOrganization(String purposeOfOrganization) {
        this.purposeOfOrganization = purposeOfOrganization;
    }

    public String getTaxStatus() {
        return taxStatus;
    }

    public void setTaxStatus(String taxStatus) {
        this.taxStatus = taxStatus;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getStatusSubtype() {
        return statusSubtype;
    }

    public void setStatusSubtype(Integer statusSubtype) {
        this.statusSubtype = statusSubtype;
    }

    public Timestamp getBusinessSince() {
        return businessSince;
    }

    public void setBusinessSince(Timestamp businessSince) {
        this.businessSince = businessSince;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Timestamp getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Timestamp modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Character getRepeatedInternationalActivity() {
        return repeatedInternationalActivity;
    }

    public void setRepeatedInternationalActivity(Character repeatedInternationalActivity) {
        this.repeatedInternationalActivity = repeatedInternationalActivity;
    }

}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
