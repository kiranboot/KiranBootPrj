package com.capitalone.api.nsb.business.identity.domain.cache;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "business.trust_type")
public class TrustType {

    @Id
    @Column(name = "trust_type_id", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer trustTypeId;

    @Column(name = "trust_type_description")
    private String trustTypeDescription;

    public Integer getTrustTypeId() {
        return trustTypeId;
    }

    public void setTrustTypeId(Integer trustTypeId) {
        this.trustTypeId = trustTypeId;
    }

    public String getTrustTypeDescription() {
        return trustTypeDescription;
    }

    public void setTrustTypeDescription(String trustTypeDescription) {
        this.trustTypeDescription = trustTypeDescription;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
