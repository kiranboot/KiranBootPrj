package com.capitalone.api.nsb.business.identity.cache;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capitalone.api.nsb.business.identity.domain.cache.HighRiskIndustryCode;
import com.capitalone.api.nsb.business.identity.service.CacheService;
import com.capitalone.api.nsb.business.identity.util.Util;

@Component
public class HighRiskIndustryCodeCacheHandler {

    private Cache<Integer, String> highRiskIndustryCodeCache;

    @Autowired
    private BusinessIdentityCacheManager cacheManager;

    @Autowired
    private CacheService cacheService;

    private void initializeCache() {
        highRiskIndustryCodeCache = cacheManager.initializeCache("highRiskIndustryCodeCache", Integer.class, String.class);
    }

    private void refreshCache() {

        if (null == highRiskIndustryCodeCache) {
            initializeCache();
        }

        highRiskIndustryCodeCache.clear();

        List<HighRiskIndustryCode> hriCodeList = cacheService.getHighRiskIndustryCodes();

        hriCodeList.forEach(hriCode -> {
            if (null != hriCode) {
                highRiskIndustryCodeCache.put(hriCode.getHighRiskIndustryCode(), hriCode.getDescription());
            }
        });
    }

    public String getHighRiskIndustryCodeDesc(int highRiskIndustryCode) {

        if (!Util.isCacheLoaded(highRiskIndustryCodeCache)) {
            refreshCache();
        }

        return highRiskIndustryCodeCache.get(highRiskIndustryCode);
    }

    public int getHighRiskIndustryCode(String highRiskIndustryCodeDesc) {

        int highRiskIndustryCode = 0;

        if (StringUtils.isNotBlank(highRiskIndustryCodeDesc)) {

            if (!Util.isCacheLoaded(highRiskIndustryCodeCache)) {
                refreshCache();
            }

            for (Entry<Integer, String> highRiskIndustryCodeEntry : highRiskIndustryCodeCache) {

                if (highRiskIndustryCodeDesc.equalsIgnoreCase(highRiskIndustryCodeEntry.getValue())) {

                    highRiskIndustryCode = highRiskIndustryCodeEntry.getKey();
                    break;
                }
            }
        }

        if (0 != highRiskIndustryCode) {
            return highRiskIndustryCode;
        }
        else {
            // TODO: Do NOT return anything. Throw exception here.
            return 0;
        }
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
