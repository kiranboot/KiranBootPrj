package com.capitalone.api.nsb.business.identity.util;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

public enum StatusEnum {

    Customer("CUSTOMER"),
    Prospect("PROSPECT"),
    Closed("CLOSED"),
    Revoked("REVOKED"),
    Fraud("FRAUD");

    private static final Map<String, String> STATUS = new HashMap<String, String>();

    static {
        for (StatusEnum status : EnumSet.allOf(StatusEnum.class)) {
            STATUS.put(StringUtils.upperCase(status.name()), status.getStatusStr());
        }
    }

    private String statusStr;

    private StatusEnum(String statusStr) {
        this.statusStr = statusStr;
    }

    public String getStatusStr() {
        return statusStr;
    }

    public static String get(String statusStr) {
        return STATUS.get(statusStr.toUpperCase().toUpperCase());
    }

    public static String fromString(String value) {
        for (Entry<String, String> entry : STATUS.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(value)) {
                return entry.getKey();
            }
        }
        return null;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
