package com.capitalone.api.nsb.business.identity.cso;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import com.capitalone.api.nsb.business.identity.util.AnnualRevenueEnum;
import com.capitalone.api.nsb.business.identity.util.LegalEntityTypeEnum;
import com.capitalone.api.nsb.business.identity.util.OwnerControlTypeEnum;
import com.capitalone.api.nsb.business.identity.util.OwnershipStructureTypeEnum;
import com.capitalone.api.nsb.business.identity.util.PurposeOfOrganizationEnum;
import com.capitalone.api.nsb.business.identity.util.StatusEnum;
import com.capitalone.api.nsb.business.identity.util.StatusSubtypeEnum;
import com.capitalone.api.nsb.business.identity.util.TaxIdTypeEnum;
import com.capitalone.api.nsb.business.identity.util.TaxStatusEnum;
import com.capitalone.api.nsb.business.identity.validator.NonRequiredFieldEnumValidator;
import com.capitalone.api.nsb.business.identity.validator.RequiredFieldEnumValidator;

@XmlRootElement(name = "RetrieveBusinessDetailsResponse")
public class RetrieveBusinessDetailsResponse {

    private String businessReferenceId;

    @RequiredFieldEnumValidator(enumClazz = LegalEntityTypeEnum.class)
    private String legalEntityType;

    private String legalEntityTypeDescription;

    private String businessName;

    @RequiredFieldEnumValidator(enumClazz = TaxIdTypeEnum.class)
    private String taxIdType;

    private String taxIdToken;

    private String industryCode;

    private List<HighRiskIndustryCSO> associatedHighRiskIndustyCodes;

    @RequiredFieldEnumValidator(enumClazz = OwnerControlTypeEnum.class)
    private String ownerControlType;

    @RequiredFieldEnumValidator(enumClazz = OwnershipStructureTypeEnum.class)
    private String ownershipStructureType;

    private String doingBusinessAs;

    private String websiteAddress;

    private String taxIdIssuingCountry;

    private String countryOfHeadquarters;

    private String countryOfLegalFormation;

    private String stateOfFormation;

    private String countryOfPrimaryOperations;

    @RequiredFieldEnumValidator(enumClazz = AnnualRevenueEnum.class)
    private String annualRevenue;

    private TrustInfoCSO trustInfo;

    private boolean isCharitableOrganization;

    @RequiredFieldEnumValidator(enumClazz = PurposeOfOrganizationEnum.class)
    private String purposeOfOrganization;

    private String purposeOfOrganizationOther;

    private boolean hasRepeatedInternationalActivity;

    private List<AddressCSO> addresses;

    private List<PhoneCSO> phoneNumbers;

    @RequiredFieldEnumValidator(enumClazz = TaxStatusEnum.class)
    private String taxStatus;

    @RequiredFieldEnumValidator(enumClazz = StatusEnum.class)
    private String businessCustomerStatus;

    @NonRequiredFieldEnumValidator(enumClazz = StatusSubtypeEnum.class)
    private String businessCustomerStatusSubtype;

    private String businessCustomerSince;

    public String getBusinessReferenceId() {
        return businessReferenceId;
    }

    public void setBusinessReferenceId(String businessReferenceId) {
        this.businessReferenceId = businessReferenceId;
    }

    public String getLegalEntityType() {
        return legalEntityType;
    }

    public void setLegalEntityType(String legalEntityType) {
        this.legalEntityType = legalEntityType;
    }

    public String getLegalEntityTypeDescription() {
        return legalEntityTypeDescription;
    }

    public void setLegalEntityTypeDescription(String legalEntityTypeDescription) {
        this.legalEntityTypeDescription = legalEntityTypeDescription;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String name) {
        this.businessName = name;
    }

    public String getTaxIdType() {
        return taxIdType;
    }

    public void setTaxIdType(String taxIdType) {
        this.taxIdType = taxIdType;
    }

    public String getTaxIdToken() {
        return taxIdToken;
    }

    public void setTaxIdToken(String taxIdToken) {
        this.taxIdToken = taxIdToken;
    }

    public String getIndustryCode() {
        return industryCode;
    }

    public void setIndustryCode(String industryCode) {
        this.industryCode = industryCode;
    }

    public List<HighRiskIndustryCSO> getAssociatedHighRiskIndustyCodes() {
        return associatedHighRiskIndustyCodes;
    }

    public void setAssociatedHighRiskIndustyCodes(List<HighRiskIndustryCSO> highRiskIndustryCSOs) {
        this.associatedHighRiskIndustyCodes = highRiskIndustryCSOs;
    }

    public String getOwnerControlType() {
        return ownerControlType;
    }

    public void setOwnerControlType(String ownerControlType) {
        this.ownerControlType = ownerControlType;
    }

    public String getOwnershipStructureType() {
        return ownershipStructureType;
    }

    public void setOwnershipStructureType(String ownershipStructureType) {
        this.ownershipStructureType = ownershipStructureType;
    }

    public String getDoingBusinessAs() {
        return doingBusinessAs;
    }

    public void setDoingBusinessAs(String doingBusinessAs) {
        this.doingBusinessAs = doingBusinessAs;
    }

    public String getWebsiteAddress() {
        return websiteAddress;
    }

    public void setWebsiteAddress(String websiteAddress) {
        this.websiteAddress = websiteAddress;
    }

    public String getTaxIdIssuingCountry() {
        return taxIdIssuingCountry;
    }

    public void setTaxIdIssuingCountry(String taxIdIssuingCountry) {
        this.taxIdIssuingCountry = taxIdIssuingCountry;
    }

    public String getCountryOfHeadquarters() {
        return countryOfHeadquarters;
    }

    public void setCountryOfHeadquarters(String countryOfHeadquarters) {
        this.countryOfHeadquarters = countryOfHeadquarters;
    }

    public String getCountryOfLegalFormation() {
        return countryOfLegalFormation;
    }

    public void setCountryOfLegalFormation(String countryOfLegalFormation) {
        this.countryOfLegalFormation = countryOfLegalFormation;
    }

    public String getStateOfFormation() {
        return stateOfFormation;
    }

    public void setStateOfFormation(String stateOfFormation) {
        this.stateOfFormation = stateOfFormation;
    }

    public String getCountryOfPrimaryOperations() {
        return countryOfPrimaryOperations;
    }

    public void setCountryOfPrimaryOperations(String countryOfPrimaryOperations) {
        this.countryOfPrimaryOperations = countryOfPrimaryOperations;
    }

    public String getAnnualRevenue() {
        return annualRevenue;
    }

    public void setAnnualRevenue(String annualRevenue) {
        this.annualRevenue = annualRevenue;
    }

    public TrustInfoCSO getTrustInfo() {
        return trustInfo;
    }

    public void setTrustInfo(TrustInfoCSO trustInfo) {
        this.trustInfo = trustInfo;
    }

    public boolean isCharitableOrganization() {
        return isCharitableOrganization;
    }

    public void setCharitableOrganization(boolean isCharitableOrganization) {
        this.isCharitableOrganization = isCharitableOrganization;
    }

    public String getPurposeOfOrganization() {
        return purposeOfOrganization;
    }

    public void setPurposeOfOrganization(String purposeOfOrganization) {
        this.purposeOfOrganization = purposeOfOrganization;
    }

    public String getPurposeOfOrganizationOther() {
        return purposeOfOrganizationOther;
    }

    public void setPurposeOfOrganizationOther(String purposeOfOrganizationOther) {
        this.purposeOfOrganizationOther = purposeOfOrganizationOther;
    }

    public boolean isHasRepeatedInternationalActivity() {
        return hasRepeatedInternationalActivity;
    }

    public void setHasRepeatedInternationalActivity(boolean repeatedInternationalActivity) {
        this.hasRepeatedInternationalActivity = repeatedInternationalActivity;
    }

    public List<AddressCSO> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<AddressCSO> addresses) {
        this.addresses = addresses;
    }

    public List<PhoneCSO> getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(List<PhoneCSO> phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }

    public String getTaxStatus() {
        return taxStatus;
    }

    public void setTaxStatus(String taxStatus) {
        this.taxStatus = taxStatus;
    }

    public String getBusinessCustomerStatus() {
        return businessCustomerStatus;
    }

    public void setBusinessCustomerStatus(String status) {
        this.businessCustomerStatus = status;
    }

    public String getBusinessCustomerStatusSubtype() {
        return businessCustomerStatusSubtype;
    }

    public void setBusinessCustomerStatusSubtype(String statusSubtype) {
        this.businessCustomerStatusSubtype = statusSubtype;
    }

    public String getBusinessCustomerSince() {
        return businessCustomerSince;
    }

    public void setBusinessCustomerSince(String businessSince) {
        this.businessCustomerSince = businessSince;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
