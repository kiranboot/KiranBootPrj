package com.capitalone.api.nsb.business.identity.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.exception.DataException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capitalone.api.nsb.business.identity.domain.cache.AddressType;
import com.capitalone.api.nsb.business.identity.domain.cache.AnnualRevenueRange;
import com.capitalone.api.nsb.business.identity.domain.cache.BusinessStatus;
import com.capitalone.api.nsb.business.identity.domain.cache.BusinessStatusSubtype;
import com.capitalone.api.nsb.business.identity.domain.cache.HighRiskIndustryCode;
import com.capitalone.api.nsb.business.identity.domain.cache.LegalEntityType;
import com.capitalone.api.nsb.business.identity.domain.cache.OwnershipStructType;
import com.capitalone.api.nsb.business.identity.domain.cache.PhoneType;
import com.capitalone.api.nsb.business.identity.domain.cache.TaxIdType;
import com.capitalone.api.nsb.business.identity.domain.cache.TrustAssetSource;
import com.capitalone.api.nsb.business.identity.domain.cache.TrustType;
import com.capitalone.api.nsb.business.identity.exception.BusinessServiceException;
import com.capitalone.api.nsb.business.identity.exception.ResourceNotFoundException;
import com.capitalone.api.nsb.business.identity.exception.ServiceErrorCode;
import com.capitalone.api.nsb.business.identity.repository.cache.AddressTypeRepository;
import com.capitalone.api.nsb.business.identity.repository.cache.AnnualRevenueRangeRepository;
import com.capitalone.api.nsb.business.identity.repository.cache.BusinessStatusRepository;
import com.capitalone.api.nsb.business.identity.repository.cache.BusinessStatusSubtypeRepository;
import com.capitalone.api.nsb.business.identity.repository.cache.HighRiskIndustryCodeRepository;
import com.capitalone.api.nsb.business.identity.repository.cache.LegalEntityTypeRepository;
import com.capitalone.api.nsb.business.identity.repository.cache.OwnershipStructTypeRepository;
import com.capitalone.api.nsb.business.identity.repository.cache.PhoneTypeRepository;
import com.capitalone.api.nsb.business.identity.repository.cache.TaxIdTypeRepository;
import com.capitalone.api.nsb.business.identity.repository.cache.TrustAssetSourceRepository;
import com.capitalone.api.nsb.business.identity.repository.cache.TrustTypeRepository;
import com.capitalone.api.nsb.business.identity.util.Util;

@Service
public class CacheService {
    
    @Autowired
    private Util util;

    @Autowired
    private AddressTypeRepository addressTypeRepository;

    @Autowired
    private AnnualRevenueRangeRepository annualRevenueRangeRepository;

    @Autowired
    private BusinessStatusRepository businessStatusRepository;

    @Autowired
    private BusinessStatusSubtypeRepository businessStatusSubtypeRepository;

    @Autowired
    private HighRiskIndustryCodeRepository highRiskIndustryCodeRepository;

    @Autowired
    private LegalEntityTypeRepository legalEntityTypeRepository;

    @Autowired
    private OwnershipStructTypeRepository ownershipStructTypeRepository;

    @Autowired
    private PhoneTypeRepository phoneTypeRepository;

    @Autowired
    private TaxIdTypeRepository taxIdTypeRepository;

    @Autowired
    private TrustAssetSourceRepository trustAssetSourceRepository;

    @Autowired
    private TrustTypeRepository trustTypeRepository;
    

    public List<AddressType> getAddressTypes() {

        try {
            List<AddressType> addressTypeList = new ArrayList<AddressType>();

            addressTypeRepository.findAll().forEach(addressTypeList::add);

            if (util.isValidCollection(addressTypeList)) {
                return addressTypeList;
            }
            else {
                throw new ResourceNotFoundException(ServiceErrorCode.NOT_FOUND, "Unalble to load address types.", null);
            }
        }
        catch (DataException dataException) {

            throw new BusinessServiceException(ServiceErrorCode.DB_ERROR, "Database Connection Error", dataException);
        }
    }

    public List<AnnualRevenueRange> getAnnualRevenueRange() {

        try {
            List<AnnualRevenueRange> annualRevenueRangeTypeList = new ArrayList<AnnualRevenueRange>();

            annualRevenueRangeRepository.findAll().forEach(annualRevenueRangeTypeList::add);

            if (util.isValidCollection(annualRevenueRangeTypeList)) {
                return annualRevenueRangeTypeList;
            }
            else {
                throw new ResourceNotFoundException(ServiceErrorCode.NOT_FOUND,
                        "Unalble to load annual revenue range types.", null);
            }
        }
        catch (DataException dataException) {

            throw new BusinessServiceException(ServiceErrorCode.DB_ERROR, "Database Connection Error", dataException);
        }
    }

    public List<BusinessStatus> getBusinessStatuses() {

        try {
            List<BusinessStatus> businessStatusList = new ArrayList<BusinessStatus>();

            businessStatusRepository.findAll().forEach(businessStatusList::add);

            if (util.isValidCollection(businessStatusList)) {
                return businessStatusList;
            }
            else {
                throw new ResourceNotFoundException(ServiceErrorCode.NOT_FOUND, "Unalble to load business statuses.",
                        null);
            }
        }
        catch (DataException dataException) {

            throw new BusinessServiceException(ServiceErrorCode.DB_ERROR, "Database Connection Error", dataException);
        }
    }

    public List<BusinessStatusSubtype> getBusinessStatusSubtypes() {

        try {
            List<BusinessStatusSubtype> businessStatusSubtypeList = new ArrayList<BusinessStatusSubtype>();

            businessStatusSubtypeRepository.findAll().forEach(businessStatusSubtypeList::add);

            if (util.isValidCollection(businessStatusSubtypeList)) {
                return businessStatusSubtypeList;
            }
            else {
                throw new ResourceNotFoundException(ServiceErrorCode.NOT_FOUND,
                        "Unalble to load business status sub-types.", null);
            }
        }
        catch (DataException dataException) {

            throw new BusinessServiceException(ServiceErrorCode.DB_ERROR, "Database Connection Error", dataException);
        }
    }

    public List<HighRiskIndustryCode> getHighRiskIndustryCodes() {

        try {
            List<HighRiskIndustryCode> highRiskIndustryCodeList = new ArrayList<HighRiskIndustryCode>();

            highRiskIndustryCodeRepository.findAll().forEach(highRiskIndustryCodeList::add);

            if (util.isValidCollection(highRiskIndustryCodeList)) {
                return highRiskIndustryCodeList;
            }
            else {
                throw new ResourceNotFoundException(ServiceErrorCode.NOT_FOUND, "Unalble to load HRI codes.", null);
            }
        }
        catch (DataException dataException) {

            throw new BusinessServiceException(ServiceErrorCode.DB_ERROR, "Database Connection Error", dataException);
        }
    }

    public List<LegalEntityType> getLegalEntityTypes() {

        try {
            List<LegalEntityType> legalEntityTypeList = new ArrayList<LegalEntityType>();

            legalEntityTypeRepository.findAll().forEach(legalEntityTypeList::add);

            if (util.isValidCollection(legalEntityTypeList)) {
                return legalEntityTypeList;
            }
            else {
                throw new ResourceNotFoundException(ServiceErrorCode.NOT_FOUND, "Unalble to load legal entity types.",
                        null);
            }
        }
        catch (DataException dataException) {

            throw new BusinessServiceException(ServiceErrorCode.DB_ERROR, "Database Connection Error", dataException);
        }
    }

    public List<OwnershipStructType> getOwnershipStructTypes() {

        try {
            List<OwnershipStructType> ownershipStructTypeList = new ArrayList<OwnershipStructType>();

            ownershipStructTypeRepository.findAll().forEach(ownershipStructTypeList::add);

            if (util.isValidCollection(ownershipStructTypeList)) {
                return ownershipStructTypeList;
            }
            else {
                throw new ResourceNotFoundException(ServiceErrorCode.NOT_FOUND,
                        "Unalble to load ownership structure types.", null);
            }
        }
        catch (DataException dataException) {

            throw new BusinessServiceException(ServiceErrorCode.DB_ERROR, "Database Connection Error", dataException);
        }
    }

    public List<PhoneType> getPhoneTypes() {

        try {
            List<PhoneType> phoneTypeList = new ArrayList<PhoneType>();

            phoneTypeRepository.findAll().forEach(phoneTypeList::add);

            if (util.isValidCollection(phoneTypeList)) {
                return phoneTypeList;
            }
            else {
                throw new ResourceNotFoundException(ServiceErrorCode.NOT_FOUND, "Unalble to load phone types.", null);
            }
        }
        catch (DataException dataException) {

            throw new BusinessServiceException(ServiceErrorCode.DB_ERROR, "Database Connection Error", dataException);
        }
    }

    public List<TaxIdType> getTaxIdTypes() {

        try {
            List<TaxIdType> taxTypeList = new ArrayList<TaxIdType>();

            taxIdTypeRepository.findAll().forEach(taxTypeList::add);

            if (util.isValidCollection(taxTypeList)) {
                return taxTypeList;
            }
            else {
                throw new ResourceNotFoundException(ServiceErrorCode.NOT_FOUND, "Unalble to load address types.", null);
            }
        }
        catch (DataException dataException) {

            throw new BusinessServiceException(ServiceErrorCode.DB_ERROR, "Database Connection Error", dataException);
        }
    }

    public List<TrustAssetSource> getTrustAssetSources() {

        try {
            List<TrustAssetSource> trustAssetSourceList = new ArrayList<TrustAssetSource>();

            trustAssetSourceRepository.findAll().forEach(trustAssetSourceList::add);

            if (util.isValidCollection(trustAssetSourceList)) {
                return trustAssetSourceList;
            }
            else {
                throw new ResourceNotFoundException(ServiceErrorCode.NOT_FOUND, "Unalble to load trust asset sources.",
                        null);
            }
        }
        catch (DataException dataException) {

            throw new BusinessServiceException(ServiceErrorCode.DB_ERROR, "Database Connection Error", dataException);
        }
    }

    public List<TrustType> getTrustTypes() {

        try {
            List<TrustType> trustTypeList = new ArrayList<TrustType>();

            trustTypeRepository.findAll().forEach(trustTypeList::add);

            if (util.isValidCollection(trustTypeList)) {
                return trustTypeList;
            }
            else {
                throw new ResourceNotFoundException(ServiceErrorCode.NOT_FOUND, "Unalble to load trust types.", null);
            }
        }
        catch (DataException dataException) {

            throw new BusinessServiceException(ServiceErrorCode.DB_ERROR, "Database Connection Error", dataException);
        }
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
