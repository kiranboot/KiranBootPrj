package com.capitalone.api.nsb.business.identity.exception;

public class ResourceNotFoundException extends BusinessServiceException {

    private static final long serialVersionUID = 5883318911205825138L;

    public ResourceNotFoundException(ServiceErrorCode serviceErrorCode, String message, Throwable originalException) {
        super(serviceErrorCode, message, originalException);
    }

}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
