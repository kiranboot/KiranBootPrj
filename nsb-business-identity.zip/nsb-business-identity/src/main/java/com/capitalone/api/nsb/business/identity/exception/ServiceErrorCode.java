package com.capitalone.api.nsb.business.identity.exception;

public enum ServiceErrorCode {

    // TODO: Discuss and finalize list of error codes
    INPUT_VALIDATION_ERROR("400", 40001),
    NOT_FOUND("404", 40002),
    ALREADY_EXISTS("409", 40003),
    METHOD_NOT_ALLOWED("405", 40004),
    GENERAL_ERROR("500", 50001),
    API_ERROR("500", 50002),
    UNKNOWN_ERROR("@", 10001),
    DB_ERROR("500", 50003);

    private String errorCode;

    private int referenceNumber;

    ServiceErrorCode(String systemErrorCode, int referenceNumber) {
        this.errorCode = systemErrorCode;
        this.referenceNumber = referenceNumber;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public int getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(int referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    @Override
    public String toString() {
        return new StringBuilder().append(errorCode).append("-").append(referenceNumber).toString();
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
