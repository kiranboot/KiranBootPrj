package com.capitalone.api.nsb.business.identity.repository;

import java.math.BigInteger;

import org.springframework.data.repository.CrudRepository;

import com.capitalone.api.nsb.business.identity.domain.Business;

public interface BusinessRepository extends CrudRepository<Business, BigInteger> {

}
