package com.capitalone.api.nsb.business.identity.util;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

public enum OwnerControlTypeEnum {

    Direct("D"),
    Indirect("I");

    private static final Map<String, String> OWNERCONTROLTYPE = new HashMap<String, String>();

    static {
        for (OwnerControlTypeEnum ownerControlType : EnumSet.allOf(OwnerControlTypeEnum.class)) {
            OWNERCONTROLTYPE.put(StringUtils.upperCase(ownerControlType.name()),
                    ownerControlType.getOwnerControlTypeStr());
        }
    }

    private String ownerControlTypeStr;

    private OwnerControlTypeEnum(String ownerControlTypeStr) {
        this.ownerControlTypeStr = ownerControlTypeStr;
    }

    public String getOwnerControlTypeStr() {
        return ownerControlTypeStr;
    }

    public static String get(String ownerControlTypeStr) {
        return OWNERCONTROLTYPE.get(ownerControlTypeStr.toUpperCase());
    }

    public static String fromString(String value) {
        for (Entry<String, String> entry : OWNERCONTROLTYPE.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(value)) {
                return entry.getKey();
            }
        }
        return null;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
