package com.capitalone.api.nsb.business.identity.cache;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capitalone.api.nsb.business.identity.domain.cache.LegalEntityType;
import com.capitalone.api.nsb.business.identity.service.CacheService;
import com.capitalone.api.nsb.business.identity.util.Util;

@Component
public class LegalEntityTypeCacheHandler {

    private Cache<Integer, String> legalEntityTypeCache;

    @Autowired
    private BusinessIdentityCacheManager cacheManager;

    @Autowired
    private CacheService cacheService;

    private void initializeCache() {
        legalEntityTypeCache = cacheManager.initializeCache("legalEntityTypeCache", Integer.class, String.class);
    }

    private void refreshCache() {

        if (null == legalEntityTypeCache) {
            initializeCache();
        }

        legalEntityTypeCache.clear();

        List<LegalEntityType> legalEntityTypeList = cacheService.getLegalEntityTypes();

        legalEntityTypeList.forEach(legalEntityType -> {
            if (null != legalEntityType) {
                legalEntityTypeCache.put(legalEntityType.getLegalEntityTypeId(), legalEntityType.getLegalEntityTypeDescription());
            }
        });
    }

    public String getLegalEntityTypeDesc(int legalEntityTypeId) {

        if (!Util.isCacheLoaded(legalEntityTypeCache)) {
            refreshCache();
        }

        return legalEntityTypeCache.get(legalEntityTypeId);
    }

    public int getLegalEntityTypeId(String legalEntityTypeDesc) {

        int legalEntityTypeId = 0;

        if (StringUtils.isNotBlank(legalEntityTypeDesc)) {

            if (!Util.isCacheLoaded(legalEntityTypeCache)) {
                refreshCache();
            }

            for (Entry<Integer, String> legalEntityType : legalEntityTypeCache) {

                if (legalEntityTypeDesc.equalsIgnoreCase(legalEntityType.getValue())) {

                    legalEntityTypeId = legalEntityType.getKey();
                    break;
                }
            }
        }

        if (0 != legalEntityTypeId) {
            return legalEntityTypeId;
        }
        else {
            // TODO: Do NOT return anything. Throw exception here.
            return 0;
        }
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
