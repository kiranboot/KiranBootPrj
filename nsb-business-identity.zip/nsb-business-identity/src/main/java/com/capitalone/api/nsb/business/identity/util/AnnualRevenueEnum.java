package com.capitalone.api.nsb.business.identity.util;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

public enum AnnualRevenueEnum {

    RevenueUnder20000("Under $20,000"),
    Revenue20001To50000("$20,000 - $50,000"),
    Revenue50001To100000("$50,001 - $100,000"),
    Revenue100001To250000("$100,001 - $250,000"),
    Revenue250001To500000("$250,001-$500,000"),
    RevenueOver500000("over $500,000");
    
    private static final Map<String, String> ANNUALREVENUE = new HashMap<String, String>();

    static {
        for (AnnualRevenueEnum annualRevenue : EnumSet.allOf(AnnualRevenueEnum.class)) {
            ANNUALREVENUE.put(StringUtils.upperCase(annualRevenue.name()), annualRevenue.getAnnualRevenueStr());
        }
    }

    private String annualRevenueStr;

    private AnnualRevenueEnum(String annualRevenueStr) {
        this.annualRevenueStr = annualRevenueStr;
    }

    public String getAnnualRevenueStr() {
        return annualRevenueStr;
    }

    public static String get(String annualRevenueStr) {
        return ANNUALREVENUE.get(annualRevenueStr.toUpperCase());
    }

    public static String fromString(String value) {
        for (Entry<String, String> entry : ANNUALREVENUE.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(value)) {
                return entry.getKey();
            }
        }
        return null;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
