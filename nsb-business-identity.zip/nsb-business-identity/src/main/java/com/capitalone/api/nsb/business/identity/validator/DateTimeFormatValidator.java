package com.capitalone.api.nsb.business.identity.validator;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;

@Documented
@Retention(RUNTIME)
@Target({FIELD, PARAMETER, ANNOTATION_TYPE})
@Constraint(validatedBy = DateTimeFormatValidatorImpl.class)
@ReportAsSingleViolation
public @interface DateTimeFormatValidator {

    String message() default "Unsupported date format. Kindly use yyyy-MM-dd'T'HH:mm:ssZ format";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
