package com.capitalone.api.nsb.business.identity.validator;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capitalone.api.nsb.business.identity.cso.CreateBusinessDetailsRequest;
import com.capitalone.api.nsb.business.identity.cso.PhoneCSO;
import com.capitalone.api.nsb.business.identity.exception.RequestValidationException;
import com.capitalone.api.nsb.business.identity.exception.ServiceErrorCode;

@Component
public class RequestValidator {

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestValidator.class);

    @Autowired
    private PhoneValidator phoneValidator;

    /**
     * @param createBusinessDetailsRequest
     */
    public void validateCreateBusinessDetailsRequest(CreateBusinessDetailsRequest createBusinessDetailsRequest) {

        // validate phone number
        validatePhoneNumber(createBusinessDetailsRequest.getPhoneNumbers());
    }

    /**
     * Validate Phone numbers
     * 
     * @param phones
     */
    private void validatePhoneNumber(final List<PhoneCSO> phones) {
        for (PhoneCSO phone : phones) {
            if (phone != null && StringUtils.isNotBlank(phone.getTelephoneNumber())
                    && !phoneValidator.isValid(phone.getTelephoneNumber())) {
                LOGGER.error("Failed validation. Phone Number is Not Valid: ", phone.getTelephoneNumber());
                throw new RequestValidationException(ServiceErrorCode.INPUT_VALIDATION_ERROR,
                        "Phone Number is Not Valid : " + phone.getTelephoneNumber(), null);
            }
        }
    }
}

/*
 * Copyright 2016 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
