package com.capitalone.api.nsb.business.identity.validator;

import java.time.Instant;
import java.time.format.DateTimeParseException;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;

public class DateTimeFormatValidatorImpl implements ConstraintValidator<DateTimeFormatValidator, String> {

    @Override
    public void initialize(DateTimeFormatValidator constraintAnnotation) {

    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {

        if (null == value || (StringUtils.isNotBlank(value) && isValidDateTimeFormat(value))) {
            return true;
        }

        return false;
    }

    private boolean isValidDateTimeFormat(String value) {

        try {
            Instant.parse(value);
            return true;
        }
        catch (DateTimeParseException exception) {
            return false;
        }
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
