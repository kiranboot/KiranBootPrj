package com.capitalone.api.nsb.business.identity.cso;

import java.util.List;

import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

import com.capitalone.api.nsb.business.identity.util.AnnualRevenueEnum;
import com.capitalone.api.nsb.business.identity.util.BooleanDeserializer;
import com.capitalone.api.nsb.business.identity.util.CountryCodesEnum;
import com.capitalone.api.nsb.business.identity.util.LegalEntityTypeEnum;
import com.capitalone.api.nsb.business.identity.util.OwnerControlTypeEnum;
import com.capitalone.api.nsb.business.identity.util.OwnershipStructureTypeEnum;
import com.capitalone.api.nsb.business.identity.util.PurposeOfOrganizationEnum;
import com.capitalone.api.nsb.business.identity.util.StatusEnum;
import com.capitalone.api.nsb.business.identity.util.StatusSubtypeEnum;
import com.capitalone.api.nsb.business.identity.util.TaxIdTypeEnum;
import com.capitalone.api.nsb.business.identity.util.TaxStatusEnum;
import com.capitalone.api.nsb.business.identity.util.USStateCodesEnum;
import com.capitalone.api.nsb.business.identity.validator.NonRequiredFieldEnumValidator;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@XmlRootElement(name = "UpdateBusinessDetailsRequest")
public class UpdateBusinessDetailsRequest {

    @NonRequiredFieldEnumValidator(enumClazz = LegalEntityTypeEnum.class)
    private String legalEntityType;

    private String industryCode;

    private String taxIdToken;

    @NonRequiredFieldEnumValidator(enumClazz = TaxIdTypeEnum.class)
    private String taxIdType;

    private List<HighRiskIndustryCSO> associatedHighRiskIndustyCodes;

    @NonRequiredFieldEnumValidator(enumClazz = OwnerControlTypeEnum.class)
    private String ownerControlType;

    @NonRequiredFieldEnumValidator(enumClazz = OwnershipStructureTypeEnum.class)
    private String ownershipStructureType;

    private String businessName;

    private String doingBusinessAs;

    private String websiteAddress;

    @NonRequiredFieldEnumValidator(enumClazz = CountryCodesEnum.class)
    private String taxIdIssuingCountry;

    @NonRequiredFieldEnumValidator(enumClazz = CountryCodesEnum.class)
    private String countryOfHeadquarters;

    @NonRequiredFieldEnumValidator(enumClazz = CountryCodesEnum.class)
    private String countryOfLegalFormation;

    @NonRequiredFieldEnumValidator(enumClazz = USStateCodesEnum.class)
    private String stateOfFormation;

    @NonRequiredFieldEnumValidator(enumClazz = CountryCodesEnum.class)
    private String countryOfPrimaryOperations;

    @NonRequiredFieldEnumValidator(enumClazz = AnnualRevenueEnum.class)
    private String annualRevenue;

    private TrustInfoCSO trustInfo = new TrustInfoCSO();

    @JsonDeserialize(using = BooleanDeserializer.class)
    private Boolean isCharitableOrganization;

    @Size(min = 1, max = 5, message = "Requires {min} address(es).")
    private List<PhoneCSO> phoneNumbers;

    @NonRequiredFieldEnumValidator(enumClazz = PurposeOfOrganizationEnum.class)
    private String purposeOfOrganization;

    private String purposeOfOrganizationOther;

    @JsonDeserialize(using = BooleanDeserializer.class)
    private Boolean hasRepeatedInternationalActivity;

    private List<AddressCSO> addresses;

    @NonRequiredFieldEnumValidator(enumClazz = TaxStatusEnum.class)
    private String taxStatus;

    @NonRequiredFieldEnumValidator(enumClazz = StatusEnum.class)
    private String businessCustomerStatus;

    @NonRequiredFieldEnumValidator(enumClazz = StatusSubtypeEnum.class)
    private String businessCustomerStatusSubtype;

    private String businessCustomerSince;

    public String getStateOfFormation() {
        return stateOfFormation;
    }

    public void setStateOfFormation(String stateOfFormation) {
        this.stateOfFormation = stateOfFormation;
    }

    public String getTaxIdToken() {
        return taxIdToken;
    }

    public void setTaxIdToken(String taxIdToken) {
        this.taxIdToken = taxIdToken;
    }

    public List<PhoneCSO> getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(List<PhoneCSO> phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }

    public String getTaxIdType() {
        return taxIdType;
    }

    public void setTaxIdType(String taxIdType) {
        this.taxIdType = taxIdType;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String name) {
        this.businessName = name;
    }

    public String getLegalEntityType() {
        return legalEntityType;
    }

    public void setLegalEntityType(String legalEntityType) {
        this.legalEntityType = legalEntityType;
    }

    public String getIndustryCode() {
        return industryCode;
    }

    public void setIndustryCode(String industryCode) {
        this.industryCode = industryCode;
    }

    public List<HighRiskIndustryCSO> getHighRiskIndustries() {
        return associatedHighRiskIndustyCodes;
    }

    public void setHighRiskIndustries(List<HighRiskIndustryCSO> highRiskIndustryCSOs) {
        this.associatedHighRiskIndustyCodes = highRiskIndustryCSOs;
    }

    public String getOwnerControlType() {
        return ownerControlType;
    }

    public void setOwnerControlType(String ownerControlType) {
        this.ownerControlType = ownerControlType;
    }

    public String getOwnershipStructureType() {
        return ownershipStructureType;
    }

    public void setOwnershipStructureType(String ownershipStructureType) {
        this.ownershipStructureType = ownershipStructureType;
    }

    public String getDoingBusinessAs() {
        return doingBusinessAs;
    }

    public void setDoingBusinessAs(String doingBusinessAs) {
        this.doingBusinessAs = doingBusinessAs;
    }

    public String getWebsiteAddress() {
        return websiteAddress;
    }

    public void setWebsiteAddress(String websiteAddress) {
        this.websiteAddress = websiteAddress;
    }

    public String getTaxIdIssuingCountry() {
        return taxIdIssuingCountry;
    }

    public void setTaxIdIssuingCountry(String taxIdIssuingCountry) {
        this.taxIdIssuingCountry = taxIdIssuingCountry;
    }

    public String getCountryOfHeadquarters() {
        return countryOfHeadquarters;
    }

    public void setCountryOfHeadquarters(String countryOfHeadquarters) {
        this.countryOfHeadquarters = countryOfHeadquarters;
    }

    public String getCountryOfLegalFormation() {
        return countryOfLegalFormation;
    }

    public void setCountryOfLegalFormation(String countryOfLegalFormation) {
        this.countryOfLegalFormation = countryOfLegalFormation;
    }

    public String getCountryOfPrimaryOperations() {
        return countryOfPrimaryOperations;
    }

    public void setCountryOfPrimaryOperations(String countryOfPrimaryOperations) {
        this.countryOfPrimaryOperations = countryOfPrimaryOperations;
    }

    public String getAnnualRevenue() {
        return annualRevenue;
    }

    public void setAnnualRevenue(String annualRevenue) {
        this.annualRevenue = annualRevenue;
    }

    public TrustInfoCSO getTrustInfo() {
        return trustInfo;
    }

    public void setTrustInfo(TrustInfoCSO trustInfo) {
        this.trustInfo = trustInfo;
    }

    public Boolean isCharitableOrganization() {
        return isCharitableOrganization;
    }

    public void setCharitableOrganization(Boolean isCharitableOrganization) {
        this.isCharitableOrganization = isCharitableOrganization;
    }

    public String getPurposeOfOrganization() {
        return purposeOfOrganization;
    }

    public void setPurposeOfOrganization(String purposeOfOrganization) {
        this.purposeOfOrganization = purposeOfOrganization;
    }

    public String getPurposeOfOrganizationOther() {
        return purposeOfOrganizationOther;
    }

    public void setPurposeOfOrganizationOther(String purposeOfOrganizationOther) {
        this.purposeOfOrganizationOther = purposeOfOrganizationOther;
    }

    public Boolean isHasRepeatedInternationalActivity() {
        return hasRepeatedInternationalActivity;
    }

    public void setHasRepeatedInternationalActivity(Boolean repeatedInternationalActivity) {
        this.hasRepeatedInternationalActivity = repeatedInternationalActivity;
    }

    public List<AddressCSO> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<AddressCSO> addresses) {
        this.addresses = addresses;
    }

    public String getTaxStatus() {
        return taxStatus;
    }

    public void setTaxStatus(String taxStatus) {
        this.taxStatus = taxStatus;
    }

    public String getBusinessCustomerStatus() {
        return businessCustomerStatus;
    }

    public void setBusinessCustomerStatus(String status) {
        this.businessCustomerStatus = status;
    }

    public String getBusinessCustomerStatusSubtype() {
        return businessCustomerStatusSubtype;
    }

    public void setBusinessCustomerStatusSubtype(String statusSubtype) {
        this.businessCustomerStatusSubtype = statusSubtype;
    }

    public String getBusinessCustomerSince() {
        return businessCustomerSince;
    }

    public void setBusinessCustomerSince(String businessSince) {
        this.businessCustomerSince = businessSince;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
