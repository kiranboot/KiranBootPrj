package com.capitalone.api.nsb.business.identity.domain.cache;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "business.high_risk_industry_codes")
public class HighRiskIndustryCode {

    @Id
    @Column(name = "high_risk_industry_code")
    private Integer highRiskIndustryCode;

    @Column(name = "description")
    private String description;

    public Integer getHighRiskIndustryCode() {
        return highRiskIndustryCode;
    }

    public void setHighRiskIndustryCode(Integer highRiskIndustryCode) {
        this.highRiskIndustryCode = highRiskIndustryCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
