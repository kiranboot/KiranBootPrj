package com.capitalone.api.nsb.business.identity.exception;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonMappingException.Reference;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;

@ControllerAdvice
@RestController
public class RestExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(RestExceptionHandler.class);

    @ExceptionHandler(RequestValidationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ResponseWrapper handleRequestValidationException(HttpServletResponse response,
            RequestValidationException exception) {

        LOGGER.error("Error occured while processing the request.", exception);

        ResponseWrapper responseWrapper = new ResponseWrapper(exception.getErrorCode(), exception.getMessage());

        return responseWrapper;
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    ResponseWrapper handleResourceNotFoundException(HttpServletResponse response, ResourceNotFoundException exception) {

        LOGGER.error("Error occured while processing the request.", exception);

        ResponseWrapper responseWrapper = new ResponseWrapper(exception.getErrorCode(), exception.getMessage());

        return responseWrapper;
    }

    @ExceptionHandler(BusinessServiceException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    ResponseWrapper handleBusinessServiceException(HttpServletResponse response, BusinessServiceException exception) {

        LOGGER.error("Error occured while processing the request.", exception);

        ResponseWrapper responseWrapper = new ResponseWrapper(exception.getErrorCode(), exception.getMessage());

        return responseWrapper;
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ResponseWrapper handleMethodArgumentNotValidException(HttpServletResponse response,
            MethodArgumentNotValidException exception) {

        LOGGER.error("Error occured while processing the request.", exception);

        ResponseWrapper responseWrapper = new ResponseWrapper(
                ServiceErrorCode.INPUT_VALIDATION_ERROR.getReferenceNumber(), getDevText(exception));

        return responseWrapper;
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ResponseWrapper handleHttpMessageNotReadableException(HttpServletResponse response,
            HttpMessageNotReadableException exception) {

        LOGGER.error("Error occured while processing the request.", exception);

        ResponseWrapper responseWrapper = new ResponseWrapper(
                ServiceErrorCode.INPUT_VALIDATION_ERROR.getReferenceNumber(), getDevText(exception));

        return responseWrapper;
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    ResponseWrapper handleGenericException(HttpServletResponse response, Exception exception) {

        LOGGER.error("Error occured while processing the request.", exception);

        ResponseWrapper responseWrapper = new ResponseWrapper(ServiceErrorCode.UNKNOWN_ERROR.getReferenceNumber(),
                "Unknown error occured.");

        return responseWrapper;
    }

    private String getDevText(MethodArgumentNotValidException exception) {

        StringBuffer devText = new StringBuffer("Invalid input for ");

        if (1 == exception.getBindingResult().getFieldErrorCount()) {
            devText.append(exception.getBindingResult().getFieldError().getField()).append(" [")
                    .append(exception.getBindingResult().getFieldError().getRejectedValue()).append("]. ")
                    .append(exception.getBindingResult().getFieldError().getDefaultMessage());
        }
        else {

            devText.append("properties : ");

            exception.getBindingResult().getFieldErrors().forEach(fieldError -> {
                devText.append(fieldError.getField()).append(" [").append(fieldError.getRejectedValue()).append("]")
                        .append(", ");
            });

            devText.delete(devText.length() - 2, devText.length());
        }

        return devText.toString();
    }

    private String getDevText(HttpMessageNotReadableException exception) {

        if (exception.getCause() instanceof InvalidFormatException) {

            StringBuffer devText = new StringBuffer("Invalid input for ");

            InvalidFormatException invalidFormatException = (InvalidFormatException) exception.getCause();

            List<Reference> path = invalidFormatException.getPath();
            devText.append(path.get(path.size() - 1).getFieldName());
            devText.append(" [").append(invalidFormatException.getValue()).append("]");

            return devText.toString();
        }
        else {
            return exception.getRootCause().getMessage();
        }
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
