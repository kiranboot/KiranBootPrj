package com.capitalone.api.nsb.business.identity.cso;

import com.capitalone.api.nsb.business.identity.util.CountryCodesEnum;
import com.capitalone.api.nsb.business.identity.util.PhoneTypeEnum;
import com.capitalone.api.nsb.business.identity.validator.NonRequiredFieldEnumValidator;
import com.capitalone.api.nsb.business.identity.validator.RequiredFieldEnumValidator;

public class PhoneCSO {

    @RequiredFieldEnumValidator(enumClazz = PhoneTypeEnum.class)
    private String phoneType;

    @NonRequiredFieldEnumValidator(enumClazz = CountryCodesEnum.class)
    private String countryCode;

    private String telephoneNumber;

    private String extensionNumber;

    public String getPhoneType() {
        return phoneType;
    }

    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getExtensionNumber() {
        return extensionNumber;
    }

    public void setExtensionNumber(String extensionNumber) {
        this.extensionNumber = extensionNumber;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
