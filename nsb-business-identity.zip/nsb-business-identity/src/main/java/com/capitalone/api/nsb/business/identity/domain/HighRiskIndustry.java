package com.capitalone.api.nsb.business.identity.domain;

import java.math.BigInteger;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "business.high_risk_industry")
public class HighRiskIndustry {

    @Id
    @Column(name = "high_risk_industry_id", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "high_risk_industry_high_risk_industry_id_seq")
    @SequenceGenerator(sequenceName = "business.high_risk_industry_high_risk_industry_id_seq", allocationSize = 1, name = "high_risk_industry_high_risk_industry_id_seq")
    private BigInteger highRiskIndustryId;

    @Column(name = "high_risk_industry_code")
    private Integer highRiskIndustryCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "business_id")
    private Business business;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_date")
    private Timestamp createdDate;

    @Column(name = "modified_by")
    private String modifiedBy;

    @Column(name = "modified_date")
    private Timestamp modifiedDate;

    public BigInteger getHighRiskIndustryId() {
        return highRiskIndustryId;
    }

    public void setHighRiskIndustryId(BigInteger highRiskIndustryId) {
        this.highRiskIndustryId = highRiskIndustryId;
    }

    public Integer getHighRiskIndustryCode() {
        return highRiskIndustryCode;
    }

    public void setHighRiskIndustryCode(Integer highRiskIndustryCode) {
        this.highRiskIndustryCode = highRiskIndustryCode;
    }

    public Business getBusiness() {
        return business;
    }

    public void setBusiness(Business business) {
        this.business = business;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Timestamp getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Timestamp modifiedDate) {
        this.modifiedDate = modifiedDate;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
