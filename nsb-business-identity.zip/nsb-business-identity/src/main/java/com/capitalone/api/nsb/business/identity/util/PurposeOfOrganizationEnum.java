package com.capitalone.api.nsb.business.identity.util;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

public enum PurposeOfOrganizationEnum {
    
    LibrariesHistoricalSocietiesAndLandmarkPreservation("Libraries Historical Societies And Landmark Preservation"),
    EarlyChildhoodProgramsAndServices("Early Childhood Programs And Services"),
    EnvironmentalProtectionAndConservation("Environmental Protection And Conservation"),
    DiseasesDisordersAndDisciplines("Diseases Disorders And Disciplines"),
    AdvocacyAndEducation("Advocacy And Education"),
    CivicOrganizations("Civic Organizations"),
    ChildrensAndFamilyServices("Childrens And Family Services"),
    DevelopmentAndReliefServices("Development And Relief Services"),
    NonMedicalScienceAndTechnologyResearch("Non Medical Science And Technology Research"),
    ReligiousActivities("Religious Activities"),
    Other("Other");

    private static final Map<String, String> PURPOSEOFORGANIZATION = new HashMap<String, String>();

    static {
        for (PurposeOfOrganizationEnum purposeOfOrganization : EnumSet.allOf(PurposeOfOrganizationEnum.class)) {
            PURPOSEOFORGANIZATION.put(StringUtils.upperCase(purposeOfOrganization.name()),
                    purposeOfOrganization.getPurposeOfOrganizationStr());
        }
    }

    private String purposeOfOrganizationStr;

    private PurposeOfOrganizationEnum(String purposeOfOrganizationStr) {
        this.purposeOfOrganizationStr = purposeOfOrganizationStr;
    }

    public String getPurposeOfOrganizationStr() {
        return purposeOfOrganizationStr;
    }

    public static String get(String purposeOfOrganizationStr) {
        return PURPOSEOFORGANIZATION.get(purposeOfOrganizationStr.toUpperCase());
    }

    public static String fromString(String value) {
        for (Entry<String, String> entry : PURPOSEOFORGANIZATION.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(value)) {
                return entry.getKey();
            }
        }
        return null;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
