package com.capitalone.api.nsb.business.identity.service;

import java.math.BigInteger;

import org.hibernate.exception.DataException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capitalone.api.nsb.business.identity.converter.BusinessIdentityConverter;
import com.capitalone.api.nsb.business.identity.cso.CreateBusinessDetailsRequest;
import com.capitalone.api.nsb.business.identity.cso.CreateBusinessDetailsResponse;
import com.capitalone.api.nsb.business.identity.cso.Header;
import com.capitalone.api.nsb.business.identity.cso.RetrieveBusinessDetailsResponse;
import com.capitalone.api.nsb.business.identity.cso.UpdateBusinessDetailsRequest;
import com.capitalone.api.nsb.business.identity.domain.Business;
import com.capitalone.api.nsb.business.identity.exception.BusinessServiceException;
import com.capitalone.api.nsb.business.identity.exception.ResourceNotFoundException;
import com.capitalone.api.nsb.business.identity.exception.ServiceErrorCode;
import com.capitalone.api.nsb.business.identity.repository.BusinessRepository;
import com.capitalone.api.nsb.business.identity.validator.RequestValidator;

@Service
public class BusinessIdentityService {

    @Autowired
    private BusinessRepository businessRepository;

    @Autowired
    private BusinessIdentityConverter businessIdentityConverter;

    @Autowired
    private RequestValidator requestValidator;

    public CreateBusinessDetailsResponse addBusiness(CreateBusinessDetailsRequest createBusinessDetailsRequest,
            Header header) {

        // validate request
        requestValidator.validateCreateBusinessDetailsRequest(createBusinessDetailsRequest);

        // Map to response object
        CreateBusinessDetailsResponse createBusinessDetailsResponse = null;
        try {
            // Saving business details
            Business business = businessIdentityConverter.mapCreateBusiness(createBusinessDetailsRequest, header);
            Business businessRes = businessRepository.save(business);

            createBusinessDetailsResponse = new CreateBusinessDetailsResponse();
            createBusinessDetailsResponse.setBusinessReferenceid(businessRes.getBusinessReferenceId().toString());
        }
        catch (DataException dataException) {
            throw new BusinessServiceException(ServiceErrorCode.DB_ERROR, "DB Error", dataException);
        }

        return createBusinessDetailsResponse;
    }

    public RetrieveBusinessDetailsResponse getBusiness(BigInteger businessReferenceId) {

        try {

            // Retrieve basic business details
            Business business = businessRepository.findOne(businessReferenceId);

            if (null != business) {
                // Map to response object
                return businessIdentityConverter.mapRetreiveBusinessResponse(business);
            }
            else {
                throw new ResourceNotFoundException(ServiceErrorCode.NOT_FOUND, "Business record does not exist.",
                        null);
            }

        }
        catch (DataException dataException) {

            throw new BusinessServiceException(ServiceErrorCode.DB_ERROR, "Database Connection Error", dataException);
        }
    }

    public void updateBusiness(UpdateBusinessDetailsRequest updateBusinessDetailsRequest, BigInteger bigInteger,
            Header header) {

        // Retrieve Business
        try {

            // Retrieve basic business details
            Business business = businessRepository.findOne(bigInteger);

            if (null != business) {
                // Map Request
                business = businessIdentityConverter.mapUpdateBusiness(business, updateBusinessDetailsRequest, header);

                // Update business details
                businessRepository.save(business);
            }
            else {
                throw new ResourceNotFoundException(ServiceErrorCode.NOT_FOUND, "Business record does not exist.",
                        null);
            }
        }
        catch (DataException dataException) {

            throw new BusinessServiceException(ServiceErrorCode.DB_ERROR, "Database Connection Error", dataException);
        }
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */