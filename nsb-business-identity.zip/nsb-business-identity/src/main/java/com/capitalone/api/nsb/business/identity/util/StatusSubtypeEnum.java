package com.capitalone.api.nsb.business.identity.util;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

public enum StatusSubtypeEnum {

    IdTheft("ID_THEFT"),
    TrueName("TRUE_NAME"),
    AccountTakeOver("ACCOUNT_TAKE_OVER"),
    IdTheftUnVerified("ID_THEFT_UNVERIFIED");

    private static final Map<String, String> STATUSSUBTYPE = new HashMap<String, String>();

    static {
        for (StatusSubtypeEnum statusSubtype : EnumSet.allOf(StatusSubtypeEnum.class)) {
            STATUSSUBTYPE.put(StringUtils.upperCase(statusSubtype.name()), statusSubtype.getStatusSubtypeStr());
        }
    }

    private String statusSubtypeStr;

    private StatusSubtypeEnum(String statusSubtypeStr) {
        this.statusSubtypeStr = statusSubtypeStr;
    }

    public String getStatusSubtypeStr() {
        return statusSubtypeStr;
    }

    public static String get(String statusSubtypeStr) {
        return STATUSSUBTYPE.get(statusSubtypeStr.toUpperCase());
    }

    public static String fromString(String value) {
        for (Entry<String, String> entry : STATUSSUBTYPE.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(value)) {
                return entry.getKey();
            }
        }
        return null;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
