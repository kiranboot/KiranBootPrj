package com.capitalone.api.nsb.business.identity.validator;

import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

@Component
public class PhoneValidator {

    private static String validRegEx = "[2-9]{1}\\d{2}-[2-9]{1}\\d{2}-\\d{4}|[2-9]{1}\\d{2}[2-9]{1}\\d{6}";

    private static Pattern validPattern = Pattern.compile(validRegEx);

    public boolean isValid(final String value) {
        return validPattern.matcher(value).matches();
    }

}

/*
 * Copyright 2016 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
