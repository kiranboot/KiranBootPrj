package com.capitalone.api.nsb.business.identity.cache;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capitalone.api.nsb.business.identity.domain.cache.TaxIdType;
import com.capitalone.api.nsb.business.identity.service.CacheService;
import com.capitalone.api.nsb.business.identity.util.Util;

@Component
public class TaxIdTypeCacheHandler {

    private Cache<Integer, String> taxIdTypeCache;

    @Autowired
    private BusinessIdentityCacheManager cacheManager;

    @Autowired
    private CacheService cacheService;

    private void initializeCache() {
        taxIdTypeCache = cacheManager.initializeCache("taxIdTypeCache", Integer.class, String.class);
    }

    private void refreshCache() {

        if (null == taxIdTypeCache) {
            initializeCache();
        }

        taxIdTypeCache.clear();

        List<TaxIdType> taxTypeList = cacheService.getTaxIdTypes();

        taxTypeList.forEach(taxIdType -> {
            if (null != taxIdType) {
                taxIdTypeCache.put(taxIdType.getTaxTypeId(), taxIdType.getTaxTypeShortDesc());
            }
        });
    }

    public String getTaxIdTypeShortDesc(int taxTypeId) {

        if (!Util.isCacheLoaded(taxIdTypeCache)) {
            refreshCache();
        }

        return taxIdTypeCache.get(taxTypeId);
    }

    public int getTaxIdTypeId(String taxTypeShortDesc) {

        int taxTypeId = 0;

        if (StringUtils.isNotBlank(taxTypeShortDesc)) {

            if (!Util.isCacheLoaded(taxIdTypeCache)) {
                refreshCache();
            }

            for (Entry<Integer, String> taxType : taxIdTypeCache) {

                if (taxTypeShortDesc.equalsIgnoreCase(taxType.getValue())) {

                    taxTypeId = taxType.getKey();
                    break;
                }
            }
        }

        if (0 != taxTypeId) {
            return taxTypeId;
        }
        else {
            // TODO: Do NOT return anything. Throw exception here.
            return 0;
        }
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
