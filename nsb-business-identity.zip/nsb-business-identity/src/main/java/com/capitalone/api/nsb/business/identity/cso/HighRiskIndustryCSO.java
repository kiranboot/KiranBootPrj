package com.capitalone.api.nsb.business.identity.cso;

import com.capitalone.api.nsb.business.identity.validator.HighRiskIndustryValidator;

public class HighRiskIndustryCSO {
    /**
     * Six digit code for high risk industries. Allowed values are 950000, 951000, 952000, 953000, 970000, 930000,
     * 940000, 964000, 964100, 971000, 954000, 957000, 980000, 990000, 960000, 961000, 962000, 963000, 965000, 991000,
     * 993000, 994000, 995000, 997000
     */
    @HighRiskIndustryValidator
    private int highRiskIndustryCode;

    /**
     * High risk industry code description
     */
    private String description;

    public int getHighRiskIndustryCode() {
        return highRiskIndustryCode;
    }

    public void setHighRiskIndustryCode(int highRiskIndustryCode) {
        this.highRiskIndustryCode = highRiskIndustryCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
