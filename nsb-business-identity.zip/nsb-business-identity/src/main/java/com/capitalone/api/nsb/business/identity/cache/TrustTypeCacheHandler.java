package com.capitalone.api.nsb.business.identity.cache;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.ehcache.Cache;
import org.ehcache.Cache.Entry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capitalone.api.nsb.business.identity.domain.cache.TrustType;
import com.capitalone.api.nsb.business.identity.service.CacheService;
import com.capitalone.api.nsb.business.identity.util.Util;

@Component
public class TrustTypeCacheHandler {

    private Cache<Integer, String> trustTypeCache;

    @Autowired
    private BusinessIdentityCacheManager cacheManager;

    @Autowired
    private CacheService cacheService;

    private void initializeCache() {
        trustTypeCache = cacheManager.initializeCache("trustTypeCache", Integer.class, String.class);
    }

    private void refreshCache() {

        if (null == trustTypeCache) {
            initializeCache();
        }

        trustTypeCache.clear();

        List<TrustType> trustTypeList = cacheService.getTrustTypes();

        trustTypeList.forEach(trustType -> {
            if (null != trustType) {
                trustTypeCache.put(trustType.getTrustTypeId(), trustType.getTrustTypeDescription());
            }
        });
    }

    public String getTrustTypeDesc(int trustTypeId) {

        if (!Util.isCacheLoaded(trustTypeCache)) {
            refreshCache();
        }

        return trustTypeCache.get(trustTypeId);
    }

    public int getTrustTypeId(String trustTypeDesc) {

        int trustTypeId = 0;

        if (StringUtils.isNotBlank(trustTypeDesc)) {

            if (!Util.isCacheLoaded(trustTypeCache)) {
                refreshCache();
            }

            for (Entry<Integer, String> trustType : trustTypeCache) {

                if (trustTypeDesc.equalsIgnoreCase(trustType.getValue())) {

                    trustTypeId = trustType.getKey();
                    break;
                }
            }
        }

        if (0 != trustTypeId) {
            return trustTypeId;
        }
        else {
            // TODO: Do NOT return anything. Throw exception here.
            return 0;
        }
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
