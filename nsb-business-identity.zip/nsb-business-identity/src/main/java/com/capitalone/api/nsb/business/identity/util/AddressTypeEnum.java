package com.capitalone.api.nsb.business.identity.util;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

public enum AddressTypeEnum {

    Primary("Primary"),
    Mailing("Mailing");

    private static final Map<String, String> ADDRESSTYPE = new HashMap<String, String>();

    static {
        for (AddressTypeEnum addressType : EnumSet.allOf(AddressTypeEnum.class)) {
            ADDRESSTYPE.put(StringUtils.upperCase(addressType.name()), addressType.getAddressTypeStr());
        }
    }

    private String addressTypeStr;

    private AddressTypeEnum(String addressTypeStr) {
        this.addressTypeStr = addressTypeStr;
    }

    public String getAddressTypeStr() {
        return addressTypeStr;
    }

    public static String get(String addressTypeStr) {
        return ADDRESSTYPE.get(addressTypeStr.toUpperCase());
    }

    public static String fromString(String value) {
        for (Entry<String, String> entry : ADDRESSTYPE.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(value)) {
                return entry.getKey();
            }
        }
        return null;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
