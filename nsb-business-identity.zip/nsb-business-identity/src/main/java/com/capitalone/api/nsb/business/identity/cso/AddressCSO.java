package com.capitalone.api.nsb.business.identity.cso;

import javax.validation.constraints.NotNull;

import com.capitalone.api.nsb.business.identity.util.AddressTypeEnum;
import com.capitalone.api.nsb.business.identity.util.CountryCodesEnum;
import com.capitalone.api.nsb.business.identity.util.USStateCodesEnum;
import com.capitalone.api.nsb.business.identity.validator.RequiredFieldEnumValidator;

public class AddressCSO {

    @RequiredFieldEnumValidator(enumClazz = AddressTypeEnum.class)
    private String addressType;

    @NotNull
    private String addressLine1;

    private String addressLine2;

    private String addressLine3;

    private String addressLine4;

    @NotNull
    private String city;

    @RequiredFieldEnumValidator(enumClazz = USStateCodesEnum.class)
    private String stateCode;

    @NotNull
    private String postalCode;

    @RequiredFieldEnumValidator(enumClazz = CountryCodesEnum.class)
    private String countryCode;

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getAddressLine3() {
        return addressLine3;
    }

    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }

    public String getAddressLine4() {
        return addressLine4;
    }

    public void setAddressLine4(String addressLine4) {
        this.addressLine4 = addressLine4;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
