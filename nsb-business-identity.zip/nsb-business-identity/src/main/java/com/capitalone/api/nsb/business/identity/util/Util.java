package com.capitalone.api.nsb.business.identity.util;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.Collection;

import org.apache.commons.lang3.StringUtils;
import org.ehcache.Cache;
import org.springframework.stereotype.Component;

import com.capitalone.api.nsb.business.identity.constants.Constants;
import com.capitalone.api.nsb.business.identity.exception.RequestValidationException;
import com.capitalone.api.nsb.business.identity.exception.ServiceErrorCode;

@Component
public class Util {

    /**
     * Checks if collection is NOT null and NOT empty
     * 
     * @param Collection
     * @return boolean result of validation (TRUE if collection contains at least one element)
     */
    public <E> boolean isValidCollection(Collection<E> collection) {

        if (null != collection && !collection.isEmpty()) {
            return true;
        }

        return false;
    }

    /**
     * Converts character to boolean
     * 
     * @param Character
     * @return boolean - TRUE if Character value is 'Y', FALSE otherwise
     */
    public boolean getBooleanFromChar(Character charVal) {
        if (Constants.YES.equals(charVal)) {
            return true;
        }

        return false;
    }

    /**
     * Converts boolean to character
     * 
     * @param boolean
     * @return Character - 'Y' if Character value is TRUE, 'N" otherwise
     */
    public Character getCharFromBoolean(boolean booleanVal) {

        return booleanVal ? Constants.YES : Constants.NO;
    }

    /**
     * Converts String to Integer
     * 
     * @param String
     * @return Integer
     */
    public static Integer getInteger(String stringVal) {

        return Integer.parseInt(stringVal);
    }

    /**
     * Get Current Date and Time
     * 
     * @return TimeStamp in UTC TimeZone
     */
    public Timestamp getCurrentDateTime() {

        return (Timestamp.from(Instant.now()));
    }

    /**
     * Converts String to SQL Timestamp.
     * 
     * @param strTime - String representing a valid instant in UTC. This string must be in yyyy-MM-dd'T'HH:mm:ssZ format e.g. 2017-05-28T11:10:45Z
     * @return Timestamp
     */
    public Timestamp getSqlTimestampFromString(String strTime) {

        try {
            if (StringUtils.isNotBlank(strTime)) {

                Timestamp sqlTime = Timestamp.from(Instant.parse(strTime));

                return sqlTime;
            }

            return null;
        }
        catch (DateTimeParseException exception) {
            throw new RequestValidationException(ServiceErrorCode.INPUT_VALIDATION_ERROR,
                    "Unsupported date format. Kindly use yyyy-MM-dd'T'HH:mm:ssZ format", exception);
        }
    }

    /**
     * Converts SQL Timestamp to String.
     * 
     * @param sqlTime - time represented by java.sql.Timestamp
     * @return String representing time in yyyy-MM-dd'T'HH:mm:ssZ format e.g. 2017-05-28T11:10:45Z
     */
    public String getStringFromSqlTimestamp(Timestamp sqlTime) {

        String strTime = sqlTime.toInstant().toString();

        return strTime;
    }

    /**
     * Checks if cache is loaded with at least one element
     * 
     * @param cache - Cache instance to be checked
     * @return boolean - True if this instance of cache is initialized and has at least one element stored
     */
    public static <K, V> boolean isCacheLoaded(Cache<K, V> cache) {

        if (null != cache && cache.iterator().hasNext()) {

            return true;
        }

        return false;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
