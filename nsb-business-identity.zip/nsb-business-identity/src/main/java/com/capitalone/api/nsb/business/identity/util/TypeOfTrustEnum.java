package com.capitalone.api.nsb.business.identity.util;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

public enum TypeOfTrustEnum {
    
    Estate("Estate"),
    RevocableTrust("Revocable Trust"),
    IrrevocableTrust("Irrevocable Trust"),
    LivingTrust("Living Trust"),
    TestamentarySupplementalOrSpecialNeeds("Testamentary Supplemental/Special Needs"),
    Other("Other");
    
    private static final Map<String, String> TYPEOFTRUST = new HashMap<String, String>();

    static {
        for (TypeOfTrustEnum typeOfTrust : EnumSet.allOf(TypeOfTrustEnum.class)) {
            TYPEOFTRUST.put(StringUtils.upperCase(typeOfTrust.name()), typeOfTrust.getTypeOfTrustStr());
        }
    }

    private String typeOfTrustStr;

    private TypeOfTrustEnum(String typeOfTrustStr) {
        this.typeOfTrustStr = typeOfTrustStr;
    }

    public String getTypeOfTrustStr() {
        return typeOfTrustStr;
    }

    public static String get(String typeOfTrustStr) {
        return TYPEOFTRUST.get(typeOfTrustStr.toUpperCase());
    }

    public static String fromString(String value) {
        for (Entry<String, String> entry : TYPEOFTRUST.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(value)) {
                return entry.getKey();
            }
        }
        return null;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
