package com.capitalone.api.nsb.business.identity.controller;

import java.math.BigInteger;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.apache.commons.validator.routines.BigIntegerValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.capitalone.api.nsb.business.identity.constants.Constants;
import com.capitalone.api.nsb.business.identity.cso.CreateBusinessDetailsRequest;
import com.capitalone.api.nsb.business.identity.cso.CreateBusinessDetailsResponse;
import com.capitalone.api.nsb.business.identity.cso.Header;
import com.capitalone.api.nsb.business.identity.cso.RetrieveBusinessDetailsResponse;
import com.capitalone.api.nsb.business.identity.cso.UpdateBusinessDetailsRequest;
import com.capitalone.api.nsb.business.identity.exception.RequestValidationException;
import com.capitalone.api.nsb.business.identity.exception.ServiceErrorCode;
import com.capitalone.api.nsb.business.identity.service.BusinessIdentityService;

import io.swagger.annotations.ApiParam;

@Component
@RestController
@RequestMapping("/small-business/businesses")
public class BusinessIdentityResourceController {

    private static final Logger LOGGER = LoggerFactory.getLogger(BusinessIdentityResourceController.class);

    @Autowired
    private BusinessIdentityService businessIdentityService;
    
    public static final String LOG_REQUEST_HEADER = "Request headers API-KEY : {}, USERID : {}";

    @PostMapping
    public CreateBusinessDetailsResponse createBusinessDetails(
            @RequestBody @Valid CreateBusinessDetailsRequest createBusinessDetailsRequest,
            @NotNull @RequestHeader(value = Constants.USERID) String userId,
            @NotNull @RequestHeader(value = Constants.APIKEY) String apiKey) {

        LOGGER.info("Calling post operation in BusinessIdentityResourceController for a given Business : {}");
        LOGGER.info(LOG_REQUEST_HEADER, apiKey, userId);
        Header header = populateHeader(apiKey, userId);
        return businessIdentityService.addBusiness(createBusinessDetailsRequest, header);
    }

    @GetMapping("/{businessReferenceId}")
    public RetrieveBusinessDetailsResponse getBusinessDetails(
            @ApiParam(value = "The ID of the business to retrieve business information", name = "businessReferenceId", required = true, allowMultiple = false) @PathVariable("businessReferenceId") String businessReferenceId,
            @NotNull @RequestHeader(value = Constants.USERID) String userId,
            @NotNull @RequestHeader(value = Constants.APIKEY) String apiKey) {

        LOGGER.info("Calling get operation in BusinessIdentityResourceController for BIF : {}", businessReferenceId);
        LOGGER.info(LOG_REQUEST_HEADER, apiKey, userId);

        if (null != BigIntegerValidator.getInstance().validate(businessReferenceId)) {
            return businessIdentityService.getBusiness(new BigInteger(businessReferenceId));
        }
        else {
            throw new RequestValidationException(ServiceErrorCode.INPUT_VALIDATION_ERROR,
                    "Invalid Business Reference Id", null);
        }
    }

    @PostMapping("/{businessReferenceId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void updateBusinessDetails(
            @ApiParam(value = "The ID of the business to update business information", name = "businessReferenceId", required = true, allowMultiple = false) @PathVariable("businessReferenceId") String businessReferenceId,
            @RequestBody @Valid UpdateBusinessDetailsRequest updateBusinessDetailsRequest,
            @NotNull @RequestHeader(value = Constants.USERID) String userId,
            @NotNull @RequestHeader(value = Constants.APIKEY) String apiKey) {

        LOGGER.info("Calling post operation in BusinessIdentityResourceController for BIF : {}", businessReferenceId);
        LOGGER.info(LOG_REQUEST_HEADER, apiKey, userId);

        Header header = populateHeader(apiKey, userId);

        if (null != BigIntegerValidator.getInstance().validate(businessReferenceId)) {
            businessIdentityService.updateBusiness(updateBusinessDetailsRequest, new BigInteger(businessReferenceId),
                    header);
        }
        else {
            throw new RequestValidationException(ServiceErrorCode.INPUT_VALIDATION_ERROR,
                    "Invalid Business Reference Id", null);
        }
    }

    /**
     * Populates Header CSO with values received in request header.
     * 
     * @param apiKey
     * @param userId
     * @return
     */
    private Header populateHeader(String apiKey, String userId) {
        Header header = new Header();
        header.setApiKey(apiKey);
        header.setUserId(userId);
        return header;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
