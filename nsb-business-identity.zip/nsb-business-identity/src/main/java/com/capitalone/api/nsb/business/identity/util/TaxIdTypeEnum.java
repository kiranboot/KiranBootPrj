package com.capitalone.api.nsb.business.identity.util;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

public enum TaxIdTypeEnum {

    Ein("EIN"),
    Ssn("SSN");

    private static final Map<String, String> TAXIDTYPE = new HashMap<String, String>();

    static {
        for (TaxIdTypeEnum taxIdType : EnumSet.allOf(TaxIdTypeEnum.class)) {
            TAXIDTYPE.put(StringUtils.upperCase(taxIdType.name()), taxIdType.getTaxIdTypeStr());
        }
    }

    private String taxIdTypeStr;

    private TaxIdTypeEnum(String taxTypeStr) {
        this.taxIdTypeStr = taxTypeStr;
    }

    public String getTaxIdTypeStr() {
        return taxIdTypeStr;
    }

    public static String get(String taxIdTypeStr) {
        return TAXIDTYPE.get(taxIdTypeStr.toUpperCase());
    }

    public static String fromString(String value) {
        for (Entry<String, String> entry : TAXIDTYPE.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(value)) {
                return entry.getKey();
            }
        }
        return null;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
