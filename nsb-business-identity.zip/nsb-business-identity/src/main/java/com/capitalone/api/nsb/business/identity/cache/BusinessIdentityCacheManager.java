package com.capitalone.api.nsb.business.identity.cache;

import java.net.URL;

import javax.annotation.PreDestroy;

import org.ehcache.Cache;
import org.ehcache.CacheManager;
import org.ehcache.config.Configuration;
import org.ehcache.config.builders.CacheManagerBuilder;
import org.ehcache.xml.XmlConfiguration;
import org.springframework.stereotype.Component;

@Component
public class BusinessIdentityCacheManager {

    private CacheManager cacheManager;

    private BusinessIdentityCacheManager() {

        URL xmlLocation = getClass().getResource("/ehCache.xml");
        Configuration xmlConfig = new XmlConfiguration(xmlLocation);
        cacheManager = CacheManagerBuilder.newCacheManager(xmlConfig);

        cacheManager.init();
    }

    @PreDestroy
    private void closeCache() {
        if (null != cacheManager) {
            cacheManager.close();
        }
    }

    protected <K, V> Cache<K, V> initializeCache(String cacheName, Class<K> keyType, Class<V> valueType) {
        return cacheManager.getCache(cacheName, keyType, valueType);
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
