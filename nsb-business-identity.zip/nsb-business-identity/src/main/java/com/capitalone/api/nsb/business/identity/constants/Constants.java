package com.capitalone.api.nsb.business.identity.constants;

public final class Constants {

    public static final String TRUE = "true";

    public static final String FALSE = "false";

    public static final String NULL = "null";

    public static final String USERID = "User-Id";

    public static final String APIKEY = "Api-Key";

    public static final String HIGHRISK_INDUSTRY_CODE = "highrisk_industry_code";

    public static final Character YES = 'Y';

    public static final Character NO = 'N';
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */