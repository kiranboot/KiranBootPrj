package com.capitalone.api.nsb.business.identity.cso;

import com.capitalone.api.nsb.business.identity.util.BooleanDeserializer;
import com.capitalone.api.nsb.business.identity.util.TypeOfTrustEnum;
import com.capitalone.api.nsb.business.identity.util.WealthTrustAssetSourceEnum;
import com.capitalone.api.nsb.business.identity.validator.NonRequiredFieldEnumValidator;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class TrustInfoCSO {

    @NonRequiredFieldEnumValidator(enumClazz = TypeOfTrustEnum.class)
    private String typeOfTrust;

    private String typeOfTrustOther;

    @NonRequiredFieldEnumValidator(enumClazz = WealthTrustAssetSourceEnum.class)
    private String wealthTrustAssetSource;

    private String wealthTrustAssetSourceOther;

    @JsonDeserialize(using = BooleanDeserializer.class)
    private Boolean isTrustFundedFromOffshore;

    @JsonDeserialize(using = BooleanDeserializer.class)
    private Boolean doesTrustBenefitCharitableOrganizations;

    public String getTypeOfTrust() {
        return typeOfTrust;
    }

    public void setTypeOfTrust(String typeOfTrust) {
        this.typeOfTrust = typeOfTrust;
    }

    public String getTypeOfTrustOther() {
        return typeOfTrustOther;
    }

    public void setTypeOfTrustOther(String typeOfTrustOther) {
        this.typeOfTrustOther = typeOfTrustOther;
    }

    public String getWealthTrustAssetSource() {
        return wealthTrustAssetSource;
    }

    public void setWealthTrustAssetSource(String wealthTrustAssetSource) {
        this.wealthTrustAssetSource = wealthTrustAssetSource;
    }

    public String getWealthTrustAssetSourceOther() {
        return wealthTrustAssetSourceOther;
    }

    public void setWealthTrustAssetSourceOther(String wealthTrustAssetSourceOther) {
        this.wealthTrustAssetSourceOther = wealthTrustAssetSourceOther;
    }

    public Boolean getIsTrustFundedFromOffshore() {
        return isTrustFundedFromOffshore;
    }

    public void setIsTrustFundedFromOffshore(Boolean isTrustFundedFromOffshore) {
        this.isTrustFundedFromOffshore = isTrustFundedFromOffshore;
    }

    public Boolean getDoesTrustBenefitCharitableOrganizations() {
        return doesTrustBenefitCharitableOrganizations;
    }

    public void setDoesTrustBenefitCharitableOrganizations(Boolean doesTrustBenefitCharitableOrganizations) {
        this.doesTrustBenefitCharitableOrganizations = doesTrustBenefitCharitableOrganizations;
    }
}

/*
 * Copyright 2017 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It may not be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior written authorization from Capital One.
 */
